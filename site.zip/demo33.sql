-- MySQL dump 10.15  Distrib 10.0.37-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: demo33
-- ------------------------------------------------------
-- Server version	10.0.37-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `batches`
--

DROP TABLE IF EXISTS `batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `batches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `batchpm` varchar(55) NOT NULL,
  `m_operation_id` varchar(55) NOT NULL,
  `vremya` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `summa` float NOT NULL,
  `segodnya` varchar(12) NOT NULL,
  `frod` int(1) NOT NULL DEFAULT '0',
  `summa_rub` float NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `batches`
--

LOCK TABLES `batches` WRITE;
/*!40000 ALTER TABLE `batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `batches` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_competition`
--

DROP TABLE IF EXISTS `db_competition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_competition` (
  `id` int(11) NOT NULL,
  `1m` double NOT NULL DEFAULT '0',
  `2m` double NOT NULL DEFAULT '0',
  `3m` double NOT NULL DEFAULT '0',
  `user_1` varchar(10) NOT NULL,
  `user_2` varchar(10) NOT NULL,
  `user_3` varchar(10) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `date_add` int(11) NOT NULL DEFAULT '0',
  `date_end` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_competition`
--

LOCK TABLES `db_competition` WRITE;
/*!40000 ALTER TABLE `db_competition` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_competition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_competition_users`
--

DROP TABLE IF EXISTS `db_competition_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_competition_users` (
  `id` int(11) NOT NULL,
  `user` varchar(10) NOT NULL,
  `user_id` int(11) NOT NULL,
  `points` double NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_competition_users`
--

LOCK TABLES `db_competition_users` WRITE;
/*!40000 ALTER TABLE `db_competition_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_competition_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_payeer_insert`
--

DROP TABLE IF EXISTS `db_payeer_insert`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_payeer_insert` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `sum` double NOT NULL DEFAULT '0',
  `type` int(1) NOT NULL,
  `date_add` int(11) NOT NULL DEFAULT '0',
  `status` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=cp1251;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_payeer_insert`
--

LOCK TABLES `db_payeer_insert` WRITE;
/*!40000 ALTER TABLE `db_payeer_insert` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_payeer_insert` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_stat`
--

DROP TABLE IF EXISTS `db_stat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_stat` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `pays` decimal(10,2) NOT NULL,
  `outs` decimal(10,2) NOT NULL,
  `users` decimal(10,2) NOT NULL,
  `date` int(2) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `date` (`date`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_stat`
--

LOCK TABLES `db_stat` WRITE;
/*!40000 ALTER TABLE `db_stat` DISABLE KEYS */;
INSERT INTO `db_stat` VALUES (1,10.00,1.00,3.00,30),(2,82.00,8.20,10.00,31),(3,0.00,0.00,2.00,2),(4,0.00,0.00,1.00,4),(5,0.00,0.00,1.00,6),(6,10.00,1.00,2.00,7),(7,10.00,1.00,0.00,8),(8,0.00,0.00,2.00,14),(9,0.00,0.00,2.00,19),(10,0.00,0.00,1.00,27);
/*!40000 ALTER TABLE `db_stat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `db_video`
--

DROP TABLE IF EXISTS `db_video`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `db_video` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` char(10) NOT NULL,
  `iduser` int(11) NOT NULL,
  `comment` text CHARACTER SET cp1251 COLLATE cp1251_bin NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=cp1251;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `db_video`
--

LOCK TABLES `db_video` WRITE;
/*!40000 ALTER TABLE `db_video` DISABLE KEYS */;
/*!40000 ALTER TABLE `db_video` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `deposits`
--

DROP TABLE IF EXISTS `deposits`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `deposits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `curatorid` int(11) NOT NULL,
  `summa` double(10,2) NOT NULL,
  `psumma` decimal(10,2) NOT NULL,
  `unixtime` bigint(20) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '0',
  `fake` int(1) NOT NULL,
  `kol` int(4) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `deposits`
--

LOCK TABLES `deposits` WRITE;
/*!40000 ALTER TABLE `deposits` DISABLE KEYS */;
/*!40000 ALTER TABLE `deposits` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `log`
--

DROP TABLE IF EXISTS `log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `summa` float NOT NULL,
  `description` text NOT NULL,
  `comment` text NOT NULL,
  `type` int(11) NOT NULL COMMENT '0 - нейтрально (отладка), 1 - положительное действие (green), 2 - отрицательное (red)',
  `status` int(1) NOT NULL DEFAULT '0',
  `timeunix` int(22) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `log`
--

LOCK TABLES `log` WRITE;
/*!40000 ALTER TABLE `log` DISABLE KEYS */;
INSERT INTO `log` VALUES (1,1,1,'Oшибка авторизации на Payeer. Ответ Payeer:<br><pre></pre>Скорее всего не верно настроен конфиг, либо в аккаунте Payeer рабочего счета отключено API или неверно указана маска сети. Так же возможно был недоступен сайт payeer.com. <br>Непоступившие средства находятся на рабочем кошельке проекта.<br>Непоступившая сумма: 1','ERROR_WHT',2,0,1527682736),(2,3,5,'Oшибка авторизации на Payeer. Ответ Payeer:<br><pre></pre>Скорее всего не верно настроен конфиг, либо в аккаунте Payeer рабочего счета отключено API или неверно указана маска сети. Так же возможно был недоступен сайт payeer.com. <br>Непоступившие средства находятся на рабочем кошельке проекта.<br>Непоступившая сумма: 5','ERROR_WHT',2,0,1527737067),(3,1,1.2,'Oшибка авторизации на Payeer. Ответ Payeer:<br><pre></pre>Скорее всего не верно настроен конфиг, либо в аккаунте Payeer рабочего счета отключено API или неверно указана маска сети. Так же возможно был недоступен сайт payeer.com. <br>Непоступившие средства находятся на рабочем кошельке проекта.<br>Непоступившая сумма: 1.2','ERROR_WHT',2,0,1527753764),(4,1,1,'Oшибка авторизации на Payeer. Ответ Payeer:<br><pre></pre>Скорее всего не верно настроен конфиг, либо в аккаунте Payeer рабочего счета отключено API или неверно указана маска сети. Так же возможно был недоступен сайт payeer.com. <br>Непоступившие средства находятся на рабочем кошельке проекта.<br>Непоступившая сумма: 1','ERROR_WHT',2,0,1527766075),(5,1,1,'Oшибка авторизации на Payeer. Ответ Payeer:<br><pre></pre>Скорее всего не верно настроен конфиг, либо в аккаунте Payeer рабочего счета отключено API или неверно указана маска сети. Так же возможно был недоступен сайт payeer.com. <br>Непоступившие средства находятся на рабочем кошельке проекта.<br>Непоступившая сумма: 1','ERROR_WHT',2,0,1528387186);
/*!40000 ALTER TABLE `log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pay`
--

DROP TABLE IF EXISTS `pay`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pay` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `data` int(11) DEFAULT NULL,
  `summa` double(10,2) DEFAULT NULL,
  `wallet` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pay`
--

LOCK TABLES `pay` WRITE;
/*!40000 ALTER TABLE `pay` DISABLE KEYS */;
/*!40000 ALTER TABLE `pay` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `php_chat`
--

DROP TABLE IF EXISTS `php_chat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `php_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `mes` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `php_chat`
--

LOCK TABLES `php_chat` WRITE;
/*!40000 ALTER TABLE `php_chat` DISABLE KEYS */;
/*!40000 ALTER TABLE `php_chat` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `ss_users`
--

DROP TABLE IF EXISTS `ss_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `ss_users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user` varchar(15) NOT NULL DEFAULT 'Anonim',
  `email` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `wallet` varchar(30) NOT NULL,
  `curator` int(11) NOT NULL,
  `i_have_refs_as_curator` int(11) NOT NULL,
  `ip` varchar(20) NOT NULL COMMENT 'IP пользователя при регистрации',
  `last_ip` varchar(15) NOT NULL COMMENT 'IP пользователя при последнем входе в аккаунт',
  `came` varchar(50) NOT NULL COMMENT 'Откуда пришел',
  `act_1` int(1) NOT NULL DEFAULT '0',
  `reg_unix` bigint(20) NOT NULL,
  `avatar` varchar(255) DEFAULT 'no.png',
  `cursum` decimal(10,2) NOT NULL,
  `psum` decimal(10,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Таблица юзеров';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ss_users`
--

LOCK TABLES `ss_users` WRITE;
/*!40000 ALTER TABLE `ss_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `ss_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tb_online`
--

DROP TABLE IF EXISTS `tb_online`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tb_online` (
  `id` int(11) NOT NULL,
  `ip` varchar(55) NOT NULL,
  `date` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tb_online`
--

LOCK TABLES `tb_online` WRITE;
/*!40000 ALTER TABLE `tb_online` DISABLE KEYS */;
INSERT INTO `tb_online` VALUES (0,'157.55.39.31',1530811412);
/*!40000 ALTER TABLE `tb_online` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userstat`
--

DROP TABLE IF EXISTS `userstat`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userstat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userid` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `opisanie` text NOT NULL,
  `color` varchar(50) NOT NULL,
  `data` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `summa` float DEFAULT NULL,
  `comment` varchar(33) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userstat`
--

LOCK TABLES `userstat` WRITE;
/*!40000 ALTER TABLE `userstat` DISABLE KEYS */;
/*!40000 ALTER TABLE `userstat` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-05-07  0:41:38
