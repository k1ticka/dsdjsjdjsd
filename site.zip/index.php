<?php
session_start();
define('SCRIPT_BY_SIRGOFFAN',dirname(__FILE__));
include(dirname(__FILE__).'/core/ini.php');
include(dirname(__FILE__).'/core/cache.php');

# Старт сессии
@session_start();

# Старт буфера
@ob_start();

$page = $_GET['page'];
define( 'ROOT', 'https://'.$_SERVER['HTTP_HOST'] );
define( 'ROOT_DIR', $_SERVER['DOCUMENT_ROOT'] );

# Default
$_OPTIMIZATION = array();
$_OPTIMIZATION["title"] = "Инвестиционная платформа";
$_OPTIMIZATION["description"] = "";
$_OPTIMIZATION["keywords"] = "";


$page = $_GET['page'];
define( 'ROOT', 'https://'.$_SERVER['HTTP_HOST'] );
define( 'ROOT_DIR', $_SERVER['DOCUMENT_ROOT'] );

include('templ/main/head.php');
if(isset($page)){
if(file_exists(dirname(__FILE__)."/pages/".$page.".php")){
include(dirname(__FILE__)."/pages/".$page.'.php');
}else{
include(dirname(__FILE__).'/pages/404.php');
}
}else{
include(dirname(__FILE__).'/pages/main.php');
}
include('templ/main/foot.php');

# Заносим контент в переменную
$content = ob_get_contents();

# Очищаем буфер
ob_end_clean();
	
	# Заменяем данные
	$content = str_replace("{!TITLE!}",$_OPTIMIZATION["title"],$content);
	$content = str_replace('{!DESCRIPTION!}',$_OPTIMIZATION["description"],$content);
	$content = str_replace('{!KEYWORDS!}',$_OPTIMIZATION["keywords"],$content);
	
	
// Выводим контент
echo $content;
?>