<?
for($i=0 ; $i<12 ; $i++){
session_start();
define('SCRIPT_BY_SIRGOFFAN',dirname(__FILE__));
require_once('core/classes/safemysql.php');
require_once('core/config.php');
require_once('core/classes/competition.php');
require_once('core/functions.php');

include('core/classes/QiwiAPI.php');
$qiwi=new QiwiApi('47a8912ba14a292e0e39656fae80');
$arr=$qiwi->getHistory('+79244422967');
foreach ($arr as &$value) {
	
	if($value[status]=='SUCCESS' and $value[sum][currency]==643 and $value[provider][id]==7){
		$msum=intval($value[sum][amount]);

	if($msum>0 AND $msum>=$mindep AND $msum<=$maxdep){

	$id=intval($value[comment]);
	
	if(!empty($id)){
	$sql = $pdo->Query("SELECT * FROM db_payeer_insert WHERE id = '{$id}' and status=0 and type=2 and sum='$msum'")->fetch();
if(empty($sql[id])){ continue;}

$pdo->Query("UPDATE db_payeer_insert SET status = '1' WHERE id = '{$id}'");
$id=$sql[user_id];
$wallet=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i", $id);
if($wallet==$value[account]){
$competition = new competition($pdo);
$competition->UpdatePoints($id, $msum);
$referer=$db->getOne("SELECT curator FROM `ss_users` WHERE id=?i", $id);
if($msum >= 335000){
$proc=$msum+$msum*0.10;
}else{
$proc=$msum;
}

$pdo->Query("UPDATE ss_users SET psum = psum+'$proc' WHERE id = '".$id."'");
$db->query("INSERT INTO deposits (userid, curatorid, summa, unixtime) VALUES(?i,?i,?s,?s)", $id, $referer, $proc, time());

addpay($id, "Пополнение баланса", $msum);
allstat($msum,'pays');	
	echo $msum;
//Затем рефские.
$refererwallet=strtoupper($db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i", $referer));
$referersum=$msum*($refpercent/100);
if($referer>0 ){
$pdo->Query("UPDATE ss_users SET cursum = cursum+'$referersum' WHERE id = '".$referer."'");
whithdraw('Выплата партнерских от DOUBLER ONLINE!',$referer,$refererwallet,$referersum);		
addUserStat($referer, "<!--stat--><!--whithdraw--><!--fromreferal-->Выплата", "<!--stat--><!--whithdraw--><!--fromreferal-->Выплата реферальных  (".$referersum." руб.)");
addpay($referer, "Выплата реферальных", $referersum);
allstat($referersum,'outs');
}	
	}
	}
	}
	}
	
}
sleep(5);
}