<?
unset($_error);
//АНТИПОВТОРЯЛКА ПРИ ОБНОВЛЕНИИ СТРАНИЦЫ (при обновлении страницы, запрос не отправится повторно)
//if($_REQUEST['antipovtor']!=$_SESSION['antipovtor'] OR !isset($_REQUEST['antipovtor'])){
if(1==1){
$_SESSION['antipovtor']=$_REQUEST['antipovtor'];

if($id=='0' OR $id<0){
	?>
	<script type="text/javascript">
	location.replace("/exit");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/exit">
	</noscript>
<?
	exit();
}
if(isset($_POST['do']) && $_POST['do']=='tologin' && $itworks==1){
$_POST_user=IsLogin($_POST['user']);
$_POST_password=IsPassword($_POST['password']);


//Проверяем на корректность ввода логина 
if(empty($_POST_user)){ 
$_error="Логин должен состоять из 4 до 10 символов (только англ. символы и цифры)."; 
return;
}

//Проверяем на корректность ввода пароля 
if(empty($_POST_password)){ 
$_error="Пароль должен состоять из 6 до 20 символов (только англ. символы и цифры)."; 
return;
} 

$check=$db->getOne("SELECT id FROM `ss_users` WHERE user=?s",$_POST_user);
if(!empty($check)){ 
    $password=$db->getOne("SELECT password FROM `ss_users` WHERE id=?i",$check);
    if($_POST_password==$password){  

	$_SESSION['id']=$check;
	$_SESSION['user']=$_POST_user;
	
	?>
	<script type="text/javascript">
	location.replace("/deposits");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/deposits">
	</noscript>
<?
exit();
	}else{
	$_error="Введен неверный пароль!"; 
	}

}else{
$_error="Пользователь с логином $_POST_user не зарегистрирован в системе!"; 
return;

}



}
/*##// РЕГИСТРАЦИЯ - REGISTER do=reg //##*/

elseif(isset($_POST['do']) && $_POST['do']=='toaccount' && $itworks==1){

$stopit=0;
if($use_kapcha==1){
  if ( !empty($_POST['capcha']) )
  {
    $code = $_POST['capcha']; //Получаем переданную капчу

    if ( isset($_SESSION['capcha']) && strtoupper($_SESSION['capcha']) == strtoupper($code) ){ //сравниваем введенную капчу с сохраненной в переменной в сессии
	//Верно, скрипт регистрации не останавливается
     $stopit=0;
	  }
    else{
		if(empty($_SESSION['capcha'])){
	$_error="Непредвиденная ошибка. Возможно, у Вас отключены COOKIE";

	//Не верно, скрипт регистрации следует остановить
     $stopit=1;
		}else{
	$_error="Код с картинки введён не верно!";

	//Не верно, скрипт регистрации следует остановить
     $stopit=1;
		}
	}
  }else{
	$_error="Вы не ввели код с картинки!";

	//Не верно, скрипт регистрации следует остановить
     $stopit=1;
  }
    //Удаляем капчу из сессии
	$_SESSION['capcha']="delmepls";
    unset($_SESSION['capcha']);
}





//Фильтруем посты с логином и перфектом
$_POST_user=IsLogin($_POST['user']);
$_POST_wallet=strtoupper(trim(sf($_POST['wallet'])));
$_POST_email=IsMail($_POST['email']);
$_POST_password=IsPassword($_POST['password']);



//Чтобы убрать лишние запросы в БД смотрим введена ли капча верно:
if($stopit!=1){

if(!empty($_COOKIE['ref'])){
$referer=(int)$_COOKIE['ref'];
}





if($referer<=$adminid OR empty($referer)){$referer=1;}



//Проверяем не пуст ли он 
if(empty($_POST_user)){ 
$_error="Логин должен состоять из 4 до 10 символов (только англ. символы и цифры)."; 
return;
}

if(empty($_POST_email)){ 
$_error="Email имеет неверный формат!"; 
return;
} 

//Проверяем не пуст ли он

if(empty($_POST_wallet)){
	$_error="Вы не ввели кошелек";
	return;
}


//Простенькая валидация
if(preg_match('/^P[0-9]{7,15}+$/',$_POST_wallet)==false and preg_match('/^41001[0-9]+$/',$_POST_wallet)==false and preg_match('/^(?:[a-z0-9]+(?:[-_]?[a-z0-9\.\-\_]+)?@[a-z0-9]+(?:\.?[a-z0-9]+)?\.[a-z]{2,5})$/i',$_POST_wallet)==false and preg_match('/^[\+][0-9]{7,20}+$/',$_POST_wallet)==false){
	$_error="Номер кошелька должен быть в формате P*******!";
return;	
}

//Проверяем не пуст ли он 
if(empty($_POST_password)){ 
$_error="Пароль должен состоять из 6 до 20 символов (только англ. символы и цифры)."; 
return;
} 

$check_user=$db->getOne("SELECT id FROM `ss_users` WHERE user=?s",$_POST_user);
if(!empty($check_user)){ 
$_error="Пользователь с логином $_POST_user уже зарегистрирован в системе!"; 
return;
}

$check_email=$db->getOne("SELECT id FROM `ss_users` WHERE email=?s",$_POST_email);
if(!empty($check_email)){ 
$_error="Пользователь с email $_POST_email уже зарегистрирован в системе!"; 
return;
}


}
//Если нет ни одной ошибки, регаем юзера
if(empty($_error)){

$nofoot=1;$nohead=1;

$_POST_ip=getRealIP();

if(!empty($_COOKIE['ref'])){
$referer=intval($_COOKIE['ref']);
}else
if(!empty($_SESSION['ref'])){
$referer=intval($_SESSION['ref']);
}

$came=sf($_SESSION['came']);




if(toaccount($_POST_ip, $came, $referer, $_POST_email, $_POST_wallet, $_POST_user, $_POST_password)!==0)
{

?>
	<script type="text/javascript">
	location.replace("/deposits");
	</script>
	<noscript>
	<meta http-equiv="refresh" content="0; url=/deposits">
	</noscript>
<?
exit();
}else{
$_error="Регистрация с данного IP уже производилась!";
}
}
}else

if(isset($_POST['do']) && $_POST['do']=='payeer_pay'){

$m_amount = $_POST['m_amount'];
if($m_amount>0 AND $m_amount>=$mindep AND $m_amount<=$maxdep){


$m_amount = number_format($m_amount, 2, '.', '');
$db->query("INSERT INTO db_payeer_insert (user_id, sum, date_add) VALUES ('".$id."','".$m_amount."','".time()."')");

$m_desc = base64_encode($m_desc);
$m_orderid = $db->insertId();
//$m_curr='RUB';
$arHash = array(
	$m_shop,
	$m_orderid,
	$m_amount,
	$m_curr,
	$m_desc,
	$m_key
);


$sign = strtoupper(hash('sha256', implode(':', $arHash)));
?>
					<div style="display:none">
                        <form method="GET" id="payeer_form_real" action="//payeer.com/merchant/">
                        <input type="hidden" name="m_shop" value="<?=$m_shop?>">
                        <input type="hidden" name="m_orderid" value="<?=$m_orderid?>">
                        <input type="hidden" name="m_amount" value="<?=$m_amount?>">
                        <input type="hidden" name="m_curr" value="RUB">
                        <input type="hidden" name="m_desc" value="<?=$m_desc?>">
                        <input type="hidden" name="m_sign" value="<?=$sign?>">
                        <input type="submit" name="m_process"  value="Payeer" />
                        </form>
                    </div>

Redirecting...
<script>
document.getElementById('payeer_form_real').submit();
</script>


<?
$_success='Please wait...';

exit;
}else{
	if($m_amount<=0){
	$_error="Вы не указали сумму";
	}else{
	$_error="Вы указали неверную сумму";
	}
}
}


if(isset($_POST['do']) && $_POST['do']=='yandex_pay'){

$m_amount = $_POST['m_amount'];
if($m_amount>0 AND $m_amount>=$mindep AND $m_amount<=$maxdep){


$m_amount = number_format($m_amount, 2, '.', '');
$db->query("INSERT INTO db_payeer_insert (user_id, sum, date_add,type) VALUES ('".$id."','".$m_amount."','".time()."',1)");

$m_desc = base64_encode($m_desc);
$m_orderid = $db->insertId();

$arHash = array($m_orderid,$y_key,$m_amount);

$sign_hash = strtoupper(hash('sha1', implode('&', $arHash)));

?>
<div style="display:none">
<form id='yandex_form_real' action="https://money.yandex.ru/quickpay/confirm.xml" method="post">	
<input  name="receiver" value="<?=$y_wallet?>" type="hidden">
<input  name="targets" value="Пополнение счета на CRYPTO TRADING" type="hidden">
<input  name="successURL" value="https://crypto-trading.group/deposit" type="hidden">
<input  name="label" value="<?=$m_orderid?>.<?=$sign_hash?>" type="hidden">
<input  name="quickpay-form" value="shop" type="hidden">
<input  name="is-inner-form" value="true" type="hidden">
<input  name="referer" value="https://crypto-trading.group/deposit" type="hidden">
<input type="hidden" name="sum" value="<?=$m_amount?>">
                    </div>

Redirecting...
<script>
document.getElementById('yandex_form_real').submit();
</script>


<?
$_success='Please wait...';

exit;
}else{
	if($m_amount<=0){
	$_error="Вы не указали сумму";
	}else{
	$_error="Вы указали неверную сумму";
	}
}
}



if(isset($_POST['do']) && $_POST['do']=='qiwi_pay'){

$m_amount = intval($_POST['m_amount']);
if($m_amount>0 AND $m_amount>=$mindep AND $m_amount<=$maxdep){



$db->query("INSERT INTO db_payeer_insert (user_id, sum, date_add,type) VALUES ('".$id."','".$m_amount."','".time()."',2)");

$m_desc = base64_encode($m_desc);
$m_orderid = $db->insertId();

header("Location: https://qiwi.com/payment/form/99?extra%5B%27account%27%5D=$q_tel&amountInteger=$m_amount&extra%5B%27comment%27%5D=$m_orderid&currency=643");
$_success='Please wait...';
exit;
}else{
	if($m_amount<=0){
	$_error="Вы не указали сумму";
	}else{
	$_error="Вы указали неверную сумму";
	}
}
}

}//ЭТУ ФИГНЮ НЕ УДАЛЯТЬ!!!
?>
<?/*-------------------*//*
Script by e-proger
Web-site: e-proger.ru
*//*-------------------*/?>