<?php
include_once 'security.php';
$host = 'localhost'; //хост базы
$db = 'demo33';
$user = 'demo33';
$pass = '5L0o4F3v';
$charset = 'UTF8';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$opt = array( PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC );

$pdo = new PDO($dsn, $user, $pass, $opt);
$pdo->exec("set names utf8");


$db = new SafeMySQL(array('user' => $user, 'pass' => $pass, 'db' => $db, 'charset' => 'utf8'));


//Название проекта
$sitename="ASTEROID";
//Описание проекта
$description="Распределение денежного потока ASTEROID";
//Дата старта
$privetstvie='Распределение денежного потока ASTEROID'; //Тупо пишем текстом что нужно, например дату старта, как нравится
//Вкл/выкл капчи (1 - вкл, 0 - выкл)
$use_kapcha=0;
//Режим работы сайта. 1 - сайт работает, 0 - регистрация закрыта
$itworks=1;
//Тип соединения (http или https)
$http_s="https";


//Настройки PAYEER
//ПРИЕМ СРЕДСТВ (мерчант):
$m_shop = ''; //ID магазина в системе Payeer
$m_desc = 'Пополнение счета в '.$sitename; //Текст комментария к платежу
$m_key = '';
//ВЫПЛАТА (api):
$accountNumber = 'P32516477'; //Счет, с которого будут происходить выплаты
$apiId = '570973649'; //ID API
$apiKey = 'reth2373ijhdJ'; //Секретный ключ API
$m_curr='RUB';


//Настройки Yandex
//ПРИЕМ СРЕДСТВ (мерчант):
$y_wallet = ''; //кошелек
$y_key = ''; //секретный ключ

//приложение (api):
$appid='345345';
$appclient_secret='345345';
$apptoken='435345345';

//Настройки ADVCASH
//ПРИЕМ СРЕДСТВ (мерчант) SCI: 
$dvamail = '3123123'; //email акаунта
$dvaname = '213123'; //название магазина
$advakey = '21312312'; //ключ
//выплати (мерчант) API: 
$dvapiName = '12312312'; //НАЗВАНИЕ API
$dvaccountEmail = '123123123'; //Email пользователя в системе, который владеет API
$adauthenticationToken = '123123123'; //ключ


//Настройки QIwi
//Api
$q_tel = '+123123123123'; //номер телефона

//КОШЕЛЕК ПРОЕКТА
$koshelek_admina=''; //Кошелек админа

$adminmail="SUPPORT@kukusy"; //Почта админа

//Выплаты по крону? 0 - по крону, 1 - кешем
$nocron=0;

$mindep=10; //Минимальный размер депозита
$maxdep=50000; //Максимальный размер депозита

$refpercent=10; //Реф. процент
$admpercent=10; //Админский процент

$depperiod=24; //выплаты каждые * часов в течении установленного максимального срока
$percent_u = 50;  //на сколько процентов увеличиваем депозит

?>