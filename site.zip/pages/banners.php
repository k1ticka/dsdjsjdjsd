<section class="contactform" id="sendAMsg">
<?php 
$_OPTIMIZATION["title"] = "Промо материалы";
$_OPTIMIZATION["description"] = "";
if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
if(empty($id)){?>
<p style="height:100px; padding-top:50px; text-align:center;"><span class="style2">Для доступа к данному разделу Вам необходимо пройти авторизацию!</span><br>
</div>

<?}else{?>
<h2>Промо материалы</h2>
<div class="description_box" style="background: #fff;background: #FFF;-ms-box-shadow: 0 2px 4px rgba(0, 0, 0, .1);-o-box-shadow: 0 2px 4px rgba(0, 0, 0, .1);box-shadow: 0 2px 4px rgba(0, 0, 0, .1);padding: 10px;margin-bottom:20px;">
<p style="opacity: 1;transform: matrix(1, 0, 0, 1, 0, 0);margin: 0 auto;font-size: 15px;color: #343535;padding: 20px;">Приглашайте друзей, знакомых и зарабатывайте 10% от их пополнений. Выплаты партнерских отчислений моментальны! Список привлеченных партнеров можно посмотреть в разделе "Партнерская программа"</p>
<span class="descr_input_cabinet" style="font-family: 'Roboto', sans-serif;color: #272b2b;font-size: 18px;">Ваша реферальная ссылка -  <b><?=$http_s?>://<?=$host?>/?ref=<?=$id?></b></span>
<br><br>
</div>
</section>

<?}?>	