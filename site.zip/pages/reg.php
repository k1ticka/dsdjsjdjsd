<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Регистрация";
$_OPTIMIZATION["description"] = "";
?>
<section class="contactform" id="sendAMsg">
<h2>Создать аккаунт</h2>
<div class="description_box">
<div class="form">
<div class="gf_browser_chrome gform_wrapper" id="gform_wrapper_2">


<script>
	
    function reg(){
	 $('.stat').html('').fadeOut(); 

	if($('#user').val().search(/^[a-zA-Z0-9]{4,10}$/)=='-1'){
 $('.stat').html('Логин должен состоять из 4 до 10 символов <br>(только англ. символы и цифры).').fadeIn("slow"); 
return false;
}
if($('#password').val().search(/^[a-zA-Z0-9]{6,20}$/)=='-1'){
 $('.stat').html('Пароль должен состоять из 6 до 20 символов <br>(только англ. символы и цифры).').fadeIn("slow"); 
return false;
}

	$('#formreg').submit();
	}


  </script>

<div class="stat1" style="display: inline-block;font-size: 14px;color: #fff;z-index: 10;left: 0px;bottom: 0px;border: 1px solid rgba(255, 255, 255, 0);width: 98.7%;background: rgb(223, 31, 38);height: 45px;line-height: 3.42857143;margin-top: 10px;border-radius: 2px;font-weight: 400;float: left;margin-bottom: 10px;font-family: 'Roboto', sans-serif; <? if(!$_error){echo 'display: none;';}?>"><center><font><?=$_error?></font></center></div>

<br>
<form action="" method="post" id="formreg">	
<input type="hidden" name="do" value="toaccount">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<div class="gform_body">
<ul id="gform_fields_2" class="gform_fields top_label form_sublabel_below description_below">
<li id="field_2_3" class="gfield twoblock gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
<div class="ginput_container ginput_container_text">
<input autocomplete="off" name="user"  id="user1" value="" size="20" type="text" placeholder="Введите логин" aria-required="true" aria-invalid="false">
</div>
</li>
<li id="field_2_4" class="gfield twoblock gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
<div class="ginput_container ginput_container_text">
<input autocomplete="off" name="email"  id="email" value="" size="20" type="text" placeholder="Введите email"  aria-required="true" aria-invalid="false">
</div>
</li>
</ul>
</div>
<div class="gform_body">
<ul id="gform_fields_2" class="gform_fields top_label form_sublabel_below description_below">
<li id="field_2_3" class="gfield twoblock gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
<div class="ginput_container ginput_container_text">
<input autocomplete="off" name="wallet" id="wallet" value="" size="20" type="text" placeholder="Введите кошелек в формате P*******" aria-required="true" aria-invalid="false">
</div>
</li>
<li id="field_2_3" class="gfield twoblock gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
<div class="ginput_container ginput_container_text">
<input autocomplete="off" name="password" id="password" value="" size="20" type="password" placeholder="Введите пароль" aria-required="true" aria-invalid="false">
</div>
</li>
<li id="field_2_4" class="gfield twoblock gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible" style="width: 98.7%;">
<div class="ginput_container ginput_container_text">
<?
if(!empty($_COOKIE['ref'])){
$rref=intval($_COOKIE['ref']);
$sqlav = $db->query("SELECT avatar,user FROM `ss_users` WHERE id=?i",$rref);
$sqlav=$db->fetch($sqlav);
}
if(empty($sqlav['user'])){
$sqlav = $db->query("SELECT avatar,user FROM `ss_users` WHERE id='1'");
$sqlav=$db->fetch($sqlav);
}

echo '<input value="" size="20" type="text" placeholder="Вас пригласил: '.$sqlav[user].'" aria-required="true" aria-invalid="false" disabled style="text-align: center;">';
 
?>	
</div>
</li>
</ul>
</div>
<div class="gform_footer"><input type="submit" value="Регистрация" class="gform_button"></div>
</form>
<br>

</div>
</div></div>
</section>