<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
$_OPTIMIZATION["title"] = "Авторизация";
$_OPTIMIZATION["description"] = "";
?>
<section class="contactform" id="sendAMsg">
<h2>Вход в личный кабинет</h2>
<div class="description_box">
<div class="form">
<div class="gf_browser_chrome gform_wrapper" id="gform_wrapper_2">


<script>
	
    function login(){
	 $('.stat1').html('').fadeOut(); 

	if($('#user1').val().search(/^[a-zA-Z0-9]{4,10}$/)=='-1'){
 $('.stat').html('Некорректный логин.').fadeIn("slow"); 
return false;
}
if($('#password1').val().search(/^[a-zA-Z0-9]{6,20}$/)=='-1'){
 $('.stat1').html('Некорректный пароль.').fadeIn("slow"); 
return false;
}

	$('#formlogin').submit();
	}


  </script>

<div class="stat1" style="display: inline-block;font-size: 14px;color: #fff;z-index: 10;left: 0px;bottom: 0px;border: 1px solid rgba(255, 255, 255, 0);width: 98.7%;background: rgb(223, 31, 38);height: 45px;line-height: 3.42857143;margin-top: 10px;border-radius: 2px;font-weight: 400;float: left;margin-bottom: 10px;font-family: 'Roboto', sans-serif; <? if(!$_error){echo 'display: none;';}?>"><center><font><?=$_error?></font></center></div>

<br>
<form action="" method="post" id="formlogin">	
<input type="hidden" name="do" value="tologin">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<div class="gform_body">
<ul id="gform_fields_2" class="gform_fields top_label form_sublabel_below description_below">
<li id="field_2_3" class="gfield twoblock gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
<label class="gfield_label" for="username">Логин<span class="gfield_required">*</span></label>
<div class="ginput_container ginput_container_text">
<input name="user"  id="user1" value="" size="20" type="text" placeholder="Введите свой логин" aria-required="true" aria-invalid="false">
</div>
</li>
<li id="field_2_4" class="gfield twoblock gfield_contains_required field_sublabel_below field_description_below gfield_visibility_visible">
<label class="gfield_label" for="password">Пароль<span class="gfield_required">*</span></label>
<div class="ginput_container ginput_container_text">
<input name="password" id="password1" value="" size="20" type="password" placeholder="Введите свой пароль" aria-required="true" aria-invalid="false">
</div>
</li>
</ul>
</div>
<div class="gform_footer"><input type="submit" value="Войти" class="gform_button"></div>
</form>
<br>

</div>
</div></div>

</section>