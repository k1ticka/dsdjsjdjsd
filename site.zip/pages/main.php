<?php if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<div class="intro-about" id="home-page">
	<div class="container">
		<span class="triangulation">
			<div class="top" style="margin-left: -42px; margin-right: -42px; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"></div>
				<h1 style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">Инвестиционная платформа ASTEROID.CX<br>Зарабатывайте 150% за 24 часа</h1>
			<div class="bottom" style="margin-left: -42px; margin-right: -42px; opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);"></div>
		</span>
		<p style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0);">Финансовая система, основанная на принципе распределения денежного потока. Средства участников вложивших позже, распределяются между участниками, вложившими раньше. Участвовать может любой желающий достигший 18 лет.</p>
	</div>
	<svg class="glitch-wide" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 123.3 6.2"><path class="gdot100" d="M20 .2h6v6h-6z"></path><path class="gdot60" d="M10 .2h6v6h-6z"></path><path class="gdot30" d="M0 .2h6v6H0z"></path><path class="gbase" d="M82.1 0H41.2C37.4 0 35 6 35 6h53.3s-2.5-6-6.2-6z" data-svg-origin="61.650001525878906 3" style="opacity: 1; transform: matrix(1, 0, 0, 1, 0, 0); transform-origin: 0px 0px 0px;"></path><path class="gdot100" d="M97.3.2h6v6h-6z"></path><path class="gdot60" d="M107.3.2h6v6h-6z"></path><path class="gdot30" d="M117.3.2h6v6h-6z"></path></svg>	<svg class="galaxy" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 316.2 301.9"><circle class="blackhole form" cx="158.1" cy="150.9" r="31.8" data-svg-origin="158.10000228881836 150.8999900817871" style="transform: matrix3d(0.80761, 0, 0, 0, 0, 0.80761, 0, 0, 0, 0, 1, 0, 30.4168, 29.0316, 0, 1); transform-origin: 0px 0px 0px;"></circle><g class="inner-ring" data-svg-origin="154.19669555664063 151.31548309326172" style="transform: matrix3d(-0.0250626, -0.999686, 0, 0, 0.999686, -0.0250626, 0, 0, 0, 0, 1, 0, 6.79332, 309.256, 0, 1); transform-origin: 0px 0px 0px;"><path class="form" d="M117.6 85c29.4-17.6 67.9-14 93.6 11.1 30.5 29.8 31.1 78.7 1.3 109.2s-78.7 31.1-109.2 1.3c-14.6-14.3-22.3-32.9-23.2-51.8m2.5-23.9c1.7-6.1 4.1-12 7.3-17.6"></path><circle class="form" cx="102.9" cy="97.5" r="18.7"></circle></g><g class="outer-ring" data-svg-origin="158.10000610351562 150.95000839233398" style="transform: matrix3d(0.999799, 0.0200509, 0, 0, -0.0200509, 0.999799, 0, 0, 0, 0, 1, 0, 3.05846, -3.13969, 0, 1); transform-origin: 0px 0px 0px;"><path class="form" d="M230.9 251c-20.4 14.9-45.6 23.7-72.8 23.7-68.3 0-123.8-55.4-123.8-123.8S89.7 27.2 158.1 27.2s123.8 55.4 123.8 123.7c0 12.2-1.8 23.9-5 35m-9.5 23c-2.8 5.3-6 10.3-9.5 15.1"></path><circle class="form" cx="244.1" cy="237.8" r="18.7"></circle></g></svg>	<div class="vertical-line"></div>
	<div class="horizontal-line"></div>
	<div class="frame"></div>
</div>
<div class="services_box">
	
	
	<canvas id="starcanvas"></canvas>
	<div class="stars-background"></div>

	<div class="row web">
		<ul>
					<li class="services_cont">
				<a href="#" class="container">
					<div class="content blockfade1">
						<svg class="mainicon constellation-research" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 119.5 119.5"><circle class="st0" cx="30.4" cy="92.9" r="5.1"/><circle class="st0" cx="6.1" cy="6.1" r="5.1"/><circle class="st0" cx="113.4" cy="61" r="5.1"/><circle class="st0" cx="62.3" cy="113.4" r="5.1"/><circle class="smstar01" cx="26.5" cy="59.7" r="1.3"/><circle class="smstar02" cx="3.6" cy="108.3" r="1.3"/><circle class="smstar03" cx="115.9" cy="3.6" r="1.3"/><circle class="smstar04" cx="72.5" cy="17.6" r="1.3"/><circle class="smstar05" cx="107" cy="43.1" r="1.3"/><circle class="st0" cx="110.8" cy="110.8" r="7.7"/><circle class="st0" cx="55.9" cy="62.3" r="7.7"/><circle class="st0" cx="44.4" cy="17.6" r="7.7"/><path class="st0" d="M111.3 103.2l2.1-37.1m-10.2 45.4l-35.8 1.9m-5.7-5.1l-4.4-38.5m6.3-7.9l44.7-.9m-53.6-6.3l-6.5-30.5m-10.9-9.5L11 7.5"/></svg>						<div class="title">Отличный маркетинг</div>
						<svg class="glitch" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 83.2 6"><path class="gdot100" d="M18 0h6v6h-6z"/><path class="gdot60" d="M9 0h6v6H9z"/><path class="gdot30" d="M0 0h6v6H0z"/><path class="gbase" d="M83.2 6H29V0h48.1c3.7 0 6.1 6 6.1 6z"/></svg>						<p>Наша платформа является высокодоходной, зарабатывайте 150% за 24 часа. Партнерская программа 10% от пополнений.</p>
						
					</div>
					<div class="overlay"></div>
				</a>
			</li>
					<li class="services_cont">
				<a href="#" class="container">
					<div class="content blockfade2">
						<svg class="mainicon rocket-creative" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 167.1 124"><g class="rocket"><path d="M67.9 87.8c15.1-1 30.8-8 43.1-20.7 16.8-17.2 22.9-40.3 17.8-59.3-19.2-4.6-42 2.2-58.7 19.4-12.4 12.7-19 28.6-19.5 43.7"/><path d="M63.2 34.7s-9.7-1.3-18.2 5.1c0 0-9.1 6.5-18.4 30.4 0 0 17.1-4 23.7.4l17.6 17.1c4.6 6.4 1.1 23.7 1.1 23.7 23.7-10 29.9-19.3 29.9-19.3 6.1-8.7 4.6-18.3 4.6-18.3"/><path d="M79.2 37.5c-2.6 5.8-1.4 12.9 3.4 17.6 4.9 4.7 12 5.7 17.8 2.9-1.8-4.6-4.6-8.8-8.3-12.4-3.8-3.7-8.2-6.4-12.9-8.1z"/><path d="M104.6 32.6c-6.2-6.1-16.2-5.9-22.3.3-1.3 1.4-2.4 3-3.1 4.6 4.7 1.7 9.1 4.4 12.9 8.1 3.7 3.6 6.5 7.9 8.3 12.4 1.6-.8 3.1-1.8 4.4-3.2 6.2-6.2 6-16.2-.2-22.2zM67.4 87.3l-2.5 2.6c-.8.8-2 .8-2.8 0L48.9 77.1c-.8-.8-.8-2 0-2.8l2.5-2.6m2.4 22.5l-8.9-8.7c-.8-.8-.8-2 0-2.8l.2-.2c.8-.8 2-.8 2.8 0l8.9 8.7c.8.8.8 2 0 2.8l-.2.2c-.7.8-2 .8-2.8 0zM47.3 98l-6-5.8c-.4-.4-.4-1.1 0-1.6l.3-.3c.4-.4 1.1-.4 1.6 0l6 5.8c.4.4.4 1.1 0 1.6l-.3.3c-.4.4-1.1.4-1.6 0z"/><ellipse transform="rotate(-45.802 40.013 99.398)" class="st0" cx="40" cy="99.4" rx="1" ry="1"/></g><path class="planet" d="M41.1 43.9C44.1 19.7 64.7 1 89.7 1c27.1 0 49 21.9 49 49 0 21.1-13.3 39-32 46"/><path d="M55.9 105.6L38.5 123m3.6-49.8L15.4 99.9m-5.9 5.8L1 114.3m22.1 3.6l14.1-14.1m-1.9-5.4l-7.1 7.1" class="blast"/><circle class="moon" cx="159.1" cy="38.7" r="7"/><path d="M41.1 8v7m3.5-3.5h-7" class="star"/></svg>						<div class="title">Моментальные выплаты</div>
						<svg class="glitch" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 83.2 6"><path class="gdot100" d="M18 0h6v6h-6z"/><path class="gdot60" d="M9 0h6v6H9z"/><path class="gdot30" d="M0 0h6v6H0z"/><path class="gbase" d="M83.2 6H29V0h48.1c3.7 0 6.1 6 6.1 6z"/></svg>						<p>Проект полностью автоматизирован, выплаты поступают моментально на кошельки, указанные при регистрации!</p>
						
					</div>
					<div class="overlay"></div>
				</a>
			</li>
					<li class="services_cont">
				<a href="#" class="container">
					<div class="content blockfade3">
						<svg class="mainicon planet-rings" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 135.9 122.5"><ellipse transform="rotate(-15.099 66.539 69.414)" class="st0" cx="66.5" cy="69.4" rx="52.1" ry="52.1"/><path class="st0" d="M112.3 44.6c4.3.3 8 1 11.2 2 5.4 1.7 8.9 4.3 9.9 7.9 3.2 11.9-23.8 29.5-60.2 39.4S4.5 102 1.3 90.1C.4 86.8 1.8 83 5.2 79"/><circle class="st0" cx="123" cy="12.9" r="11.9"/><circle class="st0" cx="96.3" cy="5.5" r="4.5"/><path class="st0" d="M26.5 66.6c.2-2.2.5-4.3 1-6.4m4-10.3c5.1-9.1 13.7-16.3 24.6-19.2"/><path class="st0" d="M127.9 81.3c4.1 5.5 5.8 10.7 4.1 15-4.9 13.1-37.5 13-72.9-.3C23.7 82.9-1 61.5 3.8 48.5c2.1-5.7 9.6-8.9 20.3-9.6"/></svg>						<div class="title">Техническая поддержка</div>
						<svg class="glitch" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 83.2 6"><path class="gdot100" d="M18 0h6v6h-6z"/><path class="gdot60" d="M9 0h6v6H9z"/><path class="gdot30" d="M0 0h6v6H0z"/><path class="gbase" d="M83.2 6H29V0h48.1c3.7 0 6.1 6 6.1 6z"/></svg>						<p>Наша служба технической поддержки оказывает эффективную помощь в решении любых интересующих вас вопросов.</p>
						
					</div>
					<div class="overlay"></div>
				</a>
			</li>
				</ul>
	</div>

	
	
<section class="contactform last-events">
        
        <div class="description_box">
       <div class="container">
	   <div class="row-flex">
	   <div class="last-events__col">
	   <h3>Последние вклады</h3>
	   <ul class="last-events-list">
 <? 
$checkdeps=$db->getOne("SELECT * FROM `pay` WHERE type='Пополнение баланса' LIMIT 1"); 
if($checkdeps>0){ 
$depositsrow=$db->query("SELECT * FROM `pay` WHERE type='Пополнение баланса' ORDER BY id DESC LIMIT 10");
while($deposits=$db->fetch($depositsrow)){?>  
<?
if($deposits['userid']!=0){
$user=$db->getOne("SELECT user FROM `ss_users` WHERE id=?i",$deposits['userid']); 
$wallets=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']);
}else{
$wallets=$deposits['wallet'];
}
$wallet=substr($wallets, 0, -4); 
?> 
	   <li class="last-events-list__item"><span class="last-events-list__username"><?=$user?></span>
	   <? if(preg_match('/^[pP][0-9]{7,15}$/',$wallets)){ echo '<img src="/images/payeer.png" class="last-events-list__icon">'; }elseif(preg_match('/^41001[0-9]+$/',$wallets)){ echo '<img src="/img/yandex.png" style="width: 18px;">';} elseif(preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/',$wallets)) { echo '<img src="/img/advcash.png" style="width: 18px;">';} elseif(preg_match('/^\+\d{9,15}$/',$wallets)) { echo '<img src="/img/qiwi.png" style="width: 18px;">';}?>
      <span class="last-events-list__summ"><font style="color: #0f212f;margin-right: 30px;"><?=date('d.m.Y',$deposits['data'])?></font> <b><?=$deposits['summa']?></b> <small>RUB</small></span>
	   </li>
<?}}else{?> 
<font style="text-align: center;font-family: 'Roboto', sans-serif;font-size: 17px;">Нет данных по вкладам!</font>         
<?}?>
	   </ul></div>
	   
	   <div class="last-events__col">
	   <h3>Последние выплаты</h3>
	   <ul class="last-events-list">
<? 
$checkdeps=$db->getOne("SELECT * FROM `pay` WHERE type!='Пополнение баланса' LIMIT 1"); 
if($checkdeps>0){
$depositsrow=$db->query("SELECT * FROM `pay` WHERE type!='Пополнение баланса' ORDER BY id DESC LIMIT 10");
while($deposits=$db->fetch($depositsrow)){?>  
<?
if($deposits['userid']!=0){
$user=$db->getOne("SELECT user FROM `ss_users` WHERE id=?i",$deposits['userid']); 
$wallets=$db->getOne("SELECT wallet FROM `ss_users` WHERE id=?i",$deposits['userid']);
}else{
$wallets=$deposits['wallet'];
}
$wallet=substr($wallets, 0, -4); 
?> 	   
	   <li class="last-events-list__item"><span class="last-events-list__username"><?=$user?></span>
	   <? if(preg_match('/^[pP][0-9]{7,15}$/',$wallets)){ echo '<img src="/images/payeer.png" class="last-events-list__icon">'; }elseif(preg_match('/^41001[0-9]+$/',$wallets)){ echo '<img src="/img/yandex.png" style="width: 18px;">';} elseif(preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/',$wallets)) { echo '<img src="/img/advcash.png" style="width: 18px;">';} elseif(preg_match('/^\+\d{9,15}$/',$wallets)) { echo '<img src="/img/qiwi.png" style="width: 18px;">';}?>
        <span class="last-events-list__summ"><font style="color: #0f212f;margin-right: 30px;"><?=date('d.m.Y',$deposits['data'])?></font><b><?=$deposits['summa']?></b> <small>RUB</small></span>
	   </li>
<?}}else{?> 
<font style="text-align: center;font-family: 'Roboto', sans-serif;font-size: 17px;">Нет данных по выплатам!</font>         
<?}?>   
	   </ul></div></div></div>
			
			
            <div class="form">
                
                <div class="gf_browser_gecko gform_wrapper" id="gform_wrapper_6">
                    
                        <div class="gform_body">
                            <ul id="gform_fields_6" class="gform_fields top_label form_sublabel_below description_below">
                                
                                
                                <li id="field_6_16" class="gfield titile gfield_html gfield_html_formatted gfield_no_follows_desc field_sublabel_below field_description_below gfield_visibility_visible">
                                    
                                </li>
                                
                            </ul>
                        </div>
                        
                    
                </div>
 
            </div>
        </div>
    </section>
	
</main>