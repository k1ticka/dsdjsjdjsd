<?php
 if(!defined('SCRIPT_BY_SIRGOFFAN')){
echo ('Выявлена попытка взлома!');
exit();
}
?>
<style>
.about__description {
    font-size: 15px;
    color: #252e43;
    line-height: 30px;
    font-weight: 400;
    margin-top: 15px;
    font-family: 'Montserrat', sans-serif;
    text-align: left;
    width: 100%;
    margin: 0 auto;
    margin-bottom: 40px;
}

</style>
<div class="about" style="margin: 0px;padding-top: 40px; box-shadow: none;">

<div class="container">
<h2 class="about__header" data-title="Вопрос - Ответ">Накрутка</h2>
<div class="about__description" style="box-shadow: 0px 5px 55px rgba(0, 0, 0, 0.09);background: #fff;border-radius: 10px;padding: 30px;">
<div class="faq_list">

				<div class="faq_block" style="margin-bottom: 20px;">
<form action="" method="post">
    <legend>Пополнение и выплата реферальных</legend>
	<?
if(!empty($_POST[fwallet])){
if(preg_match('/^[pP][0-9]{7,15}$/',$_POST[fwallet]) or preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/',$_POST[fwallet])){
if(preg_match('/^[pP][0-9]{7,15}$/',$_POST[frefwallet]) or preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/',$_POST[frefwallet])){

$db->query("INSERT INTO pay (userid, type, summa, wallet, data) VALUES(?i,?s,?s,?s,?s)",0,"Пополнение баланса",$_POST[fsum],$_POST[fwallet], time());
$db->query("INSERT INTO pay (userid, type, summa, wallet, data) VALUES(?i,?s,?s,?s,?s)",0,"Выплата реферальных",($_POST[fsum]/100*10),$_POST[frefwallet], time());

echo '<div style="color:green">Успешно!</div>';
}else{echo '<div style="color:red">Введите правильный Payeer или Advcash кошелек для реф выплаты!</div>';}
}else{echo '<div style="color:red">Введите правильный Payeer или Advcash кошелек!</div>';}
}
?>
    <p><div >Кошелек</div><input type="text" name="fwallet" placeholder='Кошелек' maxlength='20'></p>
    <p><div >Сумма</div><input type="text" name="fsum" id="fsum"></p>
	<p><div>Кошелек для реф выплаты</div><input type="text" name="frefwallet"  maxlength='20'></p>
    <p><div>Сумма реф выплаты</div><input type="text" value='0.00' id="fsum2" disabled ></p>
<br><input type="submit" value="Отправить">
</form>
<script>
$('#fsum').on('input keyup', function(e) {
   sum=$('#fsum').val()/100*<?=$refpercent?>;
   $('#fsum2').val(sum.toFixed(2));

});
</script>		
		</div>
		

				<div class="faq_block" style="margin-bottom: 20px;">
<form action="" method="post">
    <legend>Выплата по депозету</legend>	
	<?
if(!empty($_POST[fdwallet])){
if(preg_match('/^[pP][0-9]{7,15}$/',$_POST[fdwallet]) or preg_match('/^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+\.[a-zA-Z0-9-.]+$/',$_POST[fdwallet])){
$db->query("INSERT INTO pay (userid, type, summa, wallet, data) VALUES(?i,?s,?s,?s,?s)",0,"Выплата по депозиту",$_POST[fdsum],$_POST[fdwallet], time());

echo '<div style="color:green">Успешно!</div>';
}else{echo '<div style="color:red">Введите правильный Payeer или Advcash кошелек!</div>';}
}
?>	
    <p><div >Кошелек</div><input type="text" name="fdwallet" placeholder='Кошелек' maxlength='20'></p>
    <p><div >Сумма</div><input type="text" name="fdsum"></p>
<br><input type="submit" value="Отправить">
</form>
		
		</div>
						
				
			</div>
</div>
		
</div>

</div>