
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="utf-8">
    <title>AdMatix</title>
    <meta name="csrf-param" content="_csrf-webmaster">
    <meta name="csrf-token" content="-fWwRNoTaCiqShaZ4HC0d_gIH21DXYDew5duGEWtXKOzpoginyYxWeYbf_XTBPokv15APzIq-r2spV0rL50Nlw==">
    <meta name="description" content="">
    <meta name="viewport"
          content="initial-scale=1, maximum-scale=1, target-densitydpi=device-dpi, width=device-width, user-scalable=no">
    <meta name="format-detection" content="telephone=no">
    <link rel="shortcut icon" href="../files/favicon-AdMatix.ico" type="image/x-icon" />

    <link href="assets/1df6f1f0/css/bootstrap.css" rel="stylesheet">
<link href="assets/7603687/media/css/jquery.dataTables.css" rel="stylesheet">
<link href="../ico/style.css" rel="stylesheet">
<link href="css/bootstrap.css" rel="stylesheet">
<link href="css/slick.css" rel="stylesheet">
<link href="fonts/style.css" rel="stylesheet">
<link href="css/dropdown.css" rel="stylesheet">
<link href="css/jquery.mCustomScrollbar.min.css" rel="stylesheet">
<link href="css/codemirror.css" rel="stylesheet">
<link href="css/all.css@v3.6" rel="stylesheet">
<link href="css/custom.css" rel="stylesheet">
<link href="css/font-awesome.css" rel="stylesheet">    <style>
        .logo {
            display: inline-block;
            background: url(../../images/logoNew1.png) no-repeat;
            width: 161px;
            height: 48px;
            text-indent: -9999px;
            background-size: 161px;
            overflow: hidden;
            margin: 0 0 0 62px;
            margin-top: 12px;
            -webkit-transition: all 300ms linear;
            -moz-transition: all 300ms linear;
            -ms-transition: all 300ms linear;
            -o-transition: all 300ms linear;
            transition: all 300ms linear;
        }
        .link-green2 {
            background: #8bc34a;
            color: #ffffff;
            text-decoration: none;
        }
        .holder-block {
            z-index: 99999;
        }
    </style>
</head>
<body>

    
        <div class="main-wrapper">
    <div id="wrapper">
        <header id="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="header-left">
                            <div class="holder-logo">
                                <strong class="logo"><a href="../default.htm">AdMatrix</a></strong>
                            </div>
                            <a class="btn-menu" href="#">
                                <i class="icon-menu-left-1-icon"></i>
                                <i class="icon-menu-right-1-icon"></i>
                            </a>
                        </div>
                        <div class="header-right">
                            <a href="support/tickets" class="notifications">
                                <span class="btn-notifications" href="#">
                                                                        <span class="hide-text">Уведомления</span>
                                </span>
                            </a>
                            <div class="balance">
                                <span class="btn-balance btn-item">
                                    Баланс:
                                    <a id="balance" class="balance-link" href="finance/payouts">0</a>                                    <span class="icon-currency"></span>
                                </span>


                            </div>

                            <div class="hild">
                                <span class="btn-hild btn-item">
                                   Холд:
                                    <a id="hold" class="hold-link" href="finance/payouts">0</a>                                    <span class="icon-currency"></span>
                                </span>
                            </div>
                                                        <div class="hild item-head">
                                <span class="btn-bonuses btn-item" >Бонусы: <a id="" href="finance/payouts">200</a> <i class="icon-arrow-down-1-icon"></i><i class="icon-arrow-up-1-icon"></i></span>
                            </div>
                                                        <div class="account item-head">
                                <span class="mail-account btn-item">
                                    vipsergey1997@mail.ru                                    <i class="icon-arrow-down-1-icon"></i>
                                    <i class="icon-arrow-up-1-icon"></i>
                                </span>
                                <ul class="header-drop">
                                    <li>
                                        <a href="profile/edit">
                                            <i class="icon-edit-icon"></i>
                                            Редактировать профиль                                        </a>
                                    </li>
                                    <li>
                                        <a href="logout">
                                            <i class="icon-exit-right-icon"></i>
                                            Выйти                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <a class="exit-cabinet" href="logout">
                                <i class="icon-exit-right-icon"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>


        <div id="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">


                        <div class="holder-nuv">
                            <nav id="nav">
                                <ul><li><a href="offers"><i class="icon icon-1"></i><span>Офферы</span></a></li>
<li><a href="statistic"><i class="icon icon-2"></i><span>Статистика</span></a></li>
<li><a href="offers/my-offers"><i class="icon icon-3"></i> <span>Мои офферы</span></a></li>
<li><a href="flows"><i class="icon icon-4"></i> <span>Потоки</span>
                                <span class="fa arrow"></span></a></li>
<li class="item-nav"><a class="heading-nav" href="#"><i class="icon icon-5"></i>
                                <span>Инструменты</span> <i class=" arrow icon-arrow-down-1-icon"></i></a><div class="expanded"><ul><li><a href="tools/api"><i class="icon-arrow-right-1-icon"></i>API</a></li>
<li><a href="tools/domains"><i class="icon-arrow-right-1-icon"></i>Парковка доменов</a></li></ul></div>
</li>
<li class="item-nav"><a class="heading-nav" href="#"><i class="icon icon-6"></i>
                                <span>Финансы</span> <i class=" arrow icon-arrow-down-1-icon"></i></a><div class="expanded"><ul><li><a href="finance/accounts"><i class="icon-arrow-right-1-icon"></i>Реквизиты</a></li>
<li><a href="finance/payouts"><i class="icon-arrow-right-1-icon"></i>Заказать выплату</a></li>
<li><a href="finance/course"><i class="icon-arrow-right-1-icon"></i>Курсы валют</a></li></ul></div>
</li>
<li><a href="prize" class="ticket-item"><i class="icon big-icon icon-grant-prize-n"></i><span>Гарант призы</span></a></li>
<li class="item-nav"><a class="heading-nav support" href="#"><i class="icon icon-9"></i><span>Поддержка</span><i class=" arrow icon-arrow-down-1-icon"></i></a><div class="expanded"><ul><li><a href="support/tickets" class="ticket-item"><i class="icon-arrow-right-1-icon"></i>Тикеты</a></li>
<li><a href="support/faq"><i class="icon-arrow-right-1-icon"></i>FAQ</a></li>
<li><a href="support/news"><i class="icon-arrow-right-1-icon"></i>Новости</a></li></ul></div>
</li></ul>                            </nav>

                            <!-- manager -->
                                                            <div class="holder-manager">
                                    <span class="title-manager">Support</span>
                                    <div class="holder-text">
                                        <p>
                                            <strong>telegram:</strong>
                                            <a href="tg_3A//resolve@domain=_40Admatix">@admatixcom</a>
                                        </p>
                                        <p>
                                            <strong>Skype:</strong> <a href="skype:info_40admatix.com@chat">info@admatix.com</a>
                                        </p>
                                        <a class="btn-question" href="support/tickets">Задать вопрос</a>
                                    </div>
                                </div>
                            

                        </div>
                        <div class="holder-content">
                            <div class="site-error">

    <h1>Not Found (#404)</h1>

    <div class="alert alert-danger">
        Страница не найдена.    </div>

    <p>
        The above error occurred while the Web server was processing your request.
    </p>
    <p>
        Please contact us if you think this is a server error. Thank you.
    </p>

</div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <footer id="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">
                        <span class="copyright">© Admatix.com - Партнерская программа с горячим конвертом. Все права защищены 2019 г.</span>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>
<script src="assets/16a0061d/jquery.js"></script>
<script src="assets/8c9caea8/yii.js"></script>
<script src="assets/7603687/media/js/jquery.dataTables.js"></script>
<script src="js/libs/jquery-ui.1.10.3.min.js"></script>
<script src="js/libs/jquery.ui.datepicker-ru.js"></script>
<script src="js/bootstrap.js"></script>
<script src="js/libs/slick.min.js"></script>
<script src="js/libs/Chart.bundle.min.js"></script>
<script src="js/libs/core.js"></script>
<script src="js/libs/dropdown.js"></script>
<script src="js/codemirror.js"></script>
<script src="js/jquery.matchHeight.js"></script>
<script src="js/jquery.mCustomScrollbar.min.js"></script>
<script src="../../cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js"></script>
<script src="js/jquery.main.js"></script>
<script src="js/custom.js"></script>
<script src="../../https@cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script type="text/javascript">        jQuery(document).ready(function () {
            $('.currency-check6').click(function(){
                $.ajax({
                    "url" : "site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=6"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check5').click(function(){
                $.ajax({
                    "url" : "site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=5"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check1').click(function(){
                $.ajax({
                    "url" : "site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=1"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check4').click(function(){
                $.ajax({
                    "url" : "site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=4"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check7').click(function(){
                $.ajax({
                    "url" : "site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=7"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check2').click(function(){
                $.ajax({
                    "url" : "site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=2"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });    jQuery(document).ready(function () {
        $('.lang-change').click(function(){
            t = $(this);
            $.ajax({
                "url" : "site/set-default-lang",
                "method" : "GET",
                "data" : {
                    lang: t.data("lang")
                },
                "success" : function(data) {
                  location.reload();
                }
            });
        });
    });</script>
<script>
    $.widget.bridge('uibutton', $.ui.button);
    $.widget.bridge('uitooltip', $.ui.tooltip);
</script>

<!-- ajax check messages -->
<script>
    // check new ticket messages
    function ajaxMessages() {
        $.ajax({
            // actionAjax in TicketsController
            url: 'tickets/ajax',
            success: function(data){
                // if admin answers & class "notice" exists add "new" class for animation and insert answers count
                // else create "notice" class element with "new" class and answers count
                if (data > 0 && $(".notice").length > 0) {
                    $(".notice").addClass('new').text(data);
                } else if (data > 0 && $("span").is('.notice') === false) {
                    $(".btn-notifications").append('<span class="notice new">' + data + '</span>');
                    $(".ticket-item").append('<span class="notice new">' + data + '</span>');
                    $(".support").append('<span class="notice new">' + data + '</span>');
                }
            }
        });
    }

    // delete class "new" for animate "notice" class again
    function animate() {
        $(".new").removeClass().addClass("notice");
    }

    setInterval(ajaxMessages, 30000); // 30 sec
    setInterval(animate, 35000); // 35 sec
</script>

</body>
    <script>
        $(document).ready(function () {
            $('#balance').html('0')

            $('#hold').html('0');
            $('.icon-currency').html('<i class="fa fa-rouble"></i>');
        });
    </script>

</html>
