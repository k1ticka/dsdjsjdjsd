/* script by ProVerstka */
$(document).ready(function(){
    /* инициализация функций */
    /* описание функций */

    initForm();
    initTabs();
    initTabsaside();

    

    


    $('.btn-save-files').on('click', function(){
        $('.holder-download-files').addClass('active');
        return false;
    });
    $(document).click(function(event) {
        if ($(event.target).closest('.holder-download-files').length) return;
        $('.holder-download-files').removeClass('active');
        event.stopPropagation();
    });


    $(".btn-menu").click(function(){
        $('body').toggleClass("expand");
        $('#nav li.item-nav.active').removeClass('active').find('> .expanded').hide();
        $('.holder-nuv').one('webkitTransitionEnd otransitionend oTransitionEnd msTransitionEnd transitionend',   
        function(e) {
            $(window).trigger('resize');
            setTimeout(function() {
                $(window).trigger('resize');
            }, 100);
            setTimeout(function() {
                $(window).trigger('resize');
            }, 200);
        });
        return false;
    });


    $(".item-head .btn-item").on('click', function(e){
        if(!$(this).closest('.item-head').hasClass('active')){
            $(".item-head").removeClass('active');
            $(this).closest('.item-head').addClass('active');
        }
        else{
            $(this).closest('.item-head').removeClass('active');
        }
        e.preventDefault();
    });

    $(document).click(function(event) {
        if ($(event.target).closest('.item-head').length) return;
        $('.item-head').removeClass('active');
        event.stopPropagation();
    });

    //list-select
    $(".list-select .link-select").on('click', function(e){
        if(!$(this).closest('.list-select li').hasClass('active')){
            $(".list-select li").removeClass('active');
            $(this).closest('.list-select li').addClass('active');
        }
        else{
            $(this).closest('.list-select li').removeClass('active');
        }
        e.preventDefault();
    });
    $(document).click(function(event) {
        if ($(event.target).closest('.list-select li').length
            || $(event.target).closest('.select2-container').length) return;
        $('.list-select li').removeClass('active');
        event.stopPropagation();
    });
    // end list-select

    $(".item-nav .heading-nav").on('click', function(e){
        $(this).siblings('.expanded').slideToggle(400,function(){
            $(this).closest('li').toggleClass('active');
        });
        $(this).closest('li').siblings("li.active").removeClass('active').find(".expanded").slideUp(400,function(){
            $(this).closest('li').removeClass('active');
        });
        e.preventDefault();
    });

    $('.slider-offerings').slick({
        dots: true,
        prevArrow: '<button class="slick-prev"><i class="icon-arrow-left-1-icon"></i></button>',
        nextArrow: '<button class="slick-next"><i class="icon-arrow-right-1-icon"></i></button>',
        speed: 300,
        slidesToShow: 1,
        slidesToScroll: 1


    });

    $(document).on('click', function(e){
        if($(e.target).closest('#nav').length) return;

        if($('.expand #nav .item-nav.active').length){
            $('#nav .item-nav.active > a').click();
        }
    });

    $(".item .heading").click(function(e){
        $(this).next().slideToggle(400,function(){
            $(this).parent().toggleClass('active');
        });
        $(this).parent().siblings(".active").children(".expanded").slideUp(400,function(){
            $(this).parent().removeClass('active');
        });
        e.preventDefault();
    })


    $('.slider-for').slick({
        slidesToShow: 1,
        slidesToScroll: 1,
        arrows: false,
        fade: true,
        asNavFor: '.slider-nav'
    });
    $('.slider-nav').slick({
        slidesToShow: 3,
        slidesToScroll: 1,
        asNavFor: '.slider-for',
        dots: false,
        arrows: false,
        centerMode: true,
        centerPadding: '0',
        focusOnSelect: true,
    });

// графики на главной

});
/* подключение плагинов */

function initForm() {

    if ($(".dropdown").length){
        $(".dropdown").dropdown({
            // cover: true
        });
    }


    $('.btn-clear').on('click mousedown touchstart', function(e){
        e.preventDefault();
        $(this).closest('.parameter-forms').find('.select_two').val('').change();
    });


    $('select').each(function(){
        if(!$(this).hasClass('select_two')){
            //$(this).selecter();
        }
    });
    $('select.select_two').each(function(){
        var placeholder = $(this).data('placeholder');
        $('select.select_two').select2({
            closeOnSelect: false,
            placeholder: placeholder
        });
    });
    $('select').on('select2:open', function (e) {
        $('.select2-results__options').mCustomScrollbar('destroy');
        setTimeout(function () {
        $('.select2-results__options').mCustomScrollbar();
        }, 0);
    });

    $(document).on('click', '.select2-container', function(){
        $(window).trigger('resize');
    });



};

function initTabsaside(){
    $('.aside-tab ul.tab-control li a').on('click', function(){
        var thisHold = $(this).closest(".aside-tab");
        var _ind = $(this).closest('li').index();
        thisHold.children('.tab-body').children(".tab").removeClass('active');
        thisHold.children('.tab-body').children("div.tab:eq("+_ind+")").addClass('active');
        $(this).closest("ul").find(".active").removeClass("active");
        $(this).parent().addClass("active");
        return false;
    });
};

