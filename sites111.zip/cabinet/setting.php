<?php
	$show_field = false;
	$pass_field_tru = false;
	$pass_field_bad = false;
	
if( isset( $_REQUEST['change_data'] ) && trim( $_REQUEST['change_data'] ) == 'Сохранить данные' )
	{
		if( 
			isset( $_REQUEST['old_password'] ) && trim( $_REQUEST['old_password'] ) != '' && 
			isset( $_REQUEST['new_password'] ) && trim( $_REQUEST['new_password'] ) != '' &&
			isset( $_REQUEST['retype_password'] ) && trim( $_REQUEST['retype_password'] ) != ''
		)
		{
			## Проверяем данные
			function decryptIt( $q ) {
				$cryptKey  = 'qJB0rGtIn5UB1xG03efyCp22';
				$qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
				return( $qDecoded );
			}
			
			$decrypted = decryptIt( trim( $_REQUEST['sec_data'] ) );
			
			$ulq = mysql_query("SELECT `pass` FROM `users` WHERE `login` LIKE '" . $decrypted . "'");
			$user_data_in_base = mysql_fetch_assoc( $ulq );
			$user_pass_db = trim( $user_data_in_base['pass'] );
			
			if ( md5( trim( $_REQUEST['old_password'] ) ) == $user_pass_db )
				{
					mysql_query( "UPDATE  `vipse162_777`.`users` SET  `pass` =  '" . md5( trim( $_REQUEST['new_password'] ) ) . "' WHERE  `users`.`login` = '". $decrypted ."';" );
					
					echo "<script> alert( 'Пароль успешно изменен' );</script>";
				}
			else
				{
					echo "<script> alert( 'Вы не верно указали старый пароль!' );</script>";
				}
		}
		
		if( isset( $_REQUEST['wmr_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`wmr` =  '" . trim( $_REQUEST['wmr_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['yandex_rub_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`yandex` =  '" . trim( $_REQUEST['yandex_rub_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['payeer_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`payeer` =  '" . trim( $_REQUEST['payeer_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
					if( isset( $_REQUEST['card_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`card` =  '" . trim( $_REQUEST['card_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
					if( isset( $_REQUEST['advcash_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`advcash` =  '" . trim( $_REQUEST['advcash_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['qiwi_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`qiwi` =  '" . trim( $_REQUEST['qiwi_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}					
		?>
		<script>
			var object = document.getElementById( 'save_ok' );
			object.style.display = 'block'; 
			window.setTimeout( function(){ object.style.display = 'none'} ,2000);

		</script>
		<?php
	}

	## данные пользователя
	$ulq = mysql_query("SELECT * FROM `users` WHERE `login` LIKE '" . $u_login . "'");
	$user_data_in_base = mysql_fetch_assoc( $ulq );
	
	$user_wmr		= ( trim( $user_data_in_base['wmr'] ) == '' )		? '': trim( $user_data_in_base['wmr'] );
	$user_yandex	= ( trim( $user_data_in_base['yandex'] ) == '' )	? '': trim( $user_data_in_base['yandex'] );
	$user_payeer	= ( trim( $user_data_in_base['payeer'] ) == '' )	? '': trim( $user_data_in_base['payeer'] );
	$user_qiwi		= ( trim( $user_data_in_base['qiwi'] ) == '' )		? '': trim( $user_data_in_base['qiwi'] );
	$user_card		= ( trim( $user_data_in_base['card'] ) == '' )		? '': trim( $user_data_in_base['card'] );	
	$user_advcash	= ( trim( $user_data_in_base['advcash'] ) == '' )		? '': trim( $user_data_in_base['advcash'] );	
	
	
function encryptIt( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp22';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
}

$secure_user_name = encryptIt( $u_login );
?>