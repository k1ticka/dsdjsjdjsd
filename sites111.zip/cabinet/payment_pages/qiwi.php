<script language="JavaScript">
	window.location.href = "https://qiwi.com/payment/form/99?amountFraction=00&extra%5B%27account%27%5D=79506747774&extra%5B%27comment%27%5D=<?php echo $u_login; ?>&amountInteger=<?php echo $_POST['sum']; ?>"
</script>