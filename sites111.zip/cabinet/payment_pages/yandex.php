 
        <form action="https://money.yandex.ru/quickpay/confirm.xml" method="POST" id="payment">
            <input type="hidden" name="receiver" value="410018997178975">
            <input type="hidden" name="formcomment" value="<?php echo $u_login; ?>"> 
            <input type="hidden" name="short-dest" value=" <?php echo $u_login; ?>">  
            <input type="hidden" name="quickpay-form" value="shop"> 
            <input type="hidden" name="targets" value="<?php echo $u_login; ?>"> 
            <input type="hidden" name="sum" value="<?php echo $_POST['sum']; ?>" data-type="number"> 
            <input type="hidden" name="comment" value="������������ <?php echo $u_login; ?>"> 
            <input type="hidden" name="label" value="<?php echo $u_login; ?>"> 
            <input type="hidden" name="need-fio" value="false">
            <input type="hidden" name="need-email" value="false"> 
            <input type="hidden" name="need-phone" value="false"> 
            <input type="hidden" name="need-address" value="false">
            <input type="hidden" name="need-phone" value="false"> 
            <input type="hidden" name="need-address" value="false">
            <input type="hidden" name="successURL" value="<?php echo $domain_data['url']; ?>success.html">
            <input type="radio" name="paymentType" id="control_01" value="PC" checked style="display: none">
            <center><button class="btn btn-primary">��������</button></center>
        </form>
        <script>
        setTimeout(document.getElementById('payment').submit(), 1000);    
        </script> 

