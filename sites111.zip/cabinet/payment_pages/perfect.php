<form action="https://perfectmoney.is/api/step1.asp" method="POST" id="payment">
    <input type="hidden" name="PAYMENT_AMOUNT" value="<?=$_POST['sum']?>">
    <input type="hidden" name="PAYEE_ACCOUNT" value="U6335391">
    <input type="hidden" name="PAYEE_NAME" value="BITNEX">
    <input type="hidden" name="PAYMENT_ID" value="<?php echo $u_login; ?>">
    <input type="hidden" name="PAYMENT_UNITS" value="USD">
    <input type="hidden" name="STATUS_URL" value="<?php echo $domain_data['url']; ?>perfect_money_success.php">
    <input type="hidden" name="PAYMENT_URL" value="<?php echo $domain_data['url']; ?>/success.html">
    <input type="hidden" name="PAYMENT_URL_METHOD" value="POST">
    <input type="hidden" name="NOPAYMENT_URL" value="<?php echo $domain_data['url']; ?>">
    <input type="hidden" name="NOPAYMENT_URL_METHOD" value="LINK">
    <center><button class="btn btn-primary">��������</button></center>
</form>
        <script>
        setTimeout(document.getElementById('payment').submit(), 1000);    
        </script> 