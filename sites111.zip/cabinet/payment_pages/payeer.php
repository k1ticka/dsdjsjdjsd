<?

$m_shop = '808484793';
$m_orderid = rand();
$m_amount = number_format($_POST['sum'], 2, '.', '');
$m_curr = 'RUB';
$m_desc = base64_encode('User Name: ' . trim( $u_login ). "_");
$m_key = 'dCUlf8787tyFbxgr';

$arHash = array(
    $m_shop,
    $m_orderid,
    $m_amount,
    $m_curr,
    $m_desc,
    $m_key
);
$sign = strtoupper(hash('sha256', implode(':', $arHash)));
?>
   
<form method="GET" action="https://payeer.com/merchant/" id="payment">
    <input type="hidden" name="m_shop" value="<?=$m_shop?>">
    <input type="hidden" name="m_orderid" value="<?=$m_orderid?>">
    <input type="hidden" name="m_amount" value="<?=$m_amount?>">
    <input type="hidden" name="m_curr" value="<?=$m_curr?>">
    <input type="hidden" name="m_desc" value="<?=$m_desc?>">
    <input type="hidden" name="m_sign" value="<?=$sign?>">
    <input type="hidden" name="login" value="<?=$u_login?>">
    <center><button class="btn btn-primary">��������</button></center>
</form> 
<script>
setTimeout(document.getElementById('payment').submit(), 1000);    
</script>