<!DOCTYPE html>
<html lang="en" class="loading">
<head>
     <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="��������� � �������� ����� � AXPREO ��� �����-���� �������� � ����� �������! ����������� ������ �� ����� ����� ������!">
    <meta name="keywords" content="�����, ����������, ���������, ������, ������ � ���������, ������ ��� �������, ����� �����, ��������� 2018">
    <meta name="author" content="PIXINVENT">
    <title>AXPREO - �������� ������ ����� ���������� �����</title>
    <link rel="apple-touch-icon" sizes="60x60" href="app-assets/img/ico/apple-icon-60.html">
    <link rel="apple-touch-icon" sizes="76x76" href="app-assets/img/ico/apple-icon-76.html">
    <link rel="apple-touch-icon" sizes="120x120" href="app-assets/img/ico/apple-icon-120.html">
    <link rel="apple-touch-icon" sizes="152x152" href="app-assets/img/ico/apple-icon-152.html">
    <link rel="shortcut icon" type="image/x-icon" href="app-assets/img/ico/favicon.ico">
    <link rel="shortcut icon" type="image/png" href="app-assets/img/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900|Montserrat:300,400,500,600,700,800,900" rel="stylesheet">
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/feather/style.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/simple-line-icons/style.css">
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/perfect-scrollbar.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/prism.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/css/app.css">
</head>
<body data-col="1-column" class=" 1-column  blank-page blank-page">
    <div class="wrapper">
      <div class="main-panel">
        <div class="main-content">
          <div class="content-wrapper"><!--Lock Screen Starts-->
            <section id="lock-screen">
                <div class="container-fluid gradient-crystal-clear">
                    <div class="row full-height-vh">
                        <div class="col-12 d-flex align-items-center justify-content-center">
                            <div class="card width-400">
                                <div class="row">
                                    <div class="col-sm-8">
                                        <div class="card-title font-medium-5 pt-2 ml-2">�������� ������</div>
                                    </div>
                                    <div class="col-sm-4">
                                        <div class="text-right card-img overlap">
                                            <img alt="avtar" class="mb-1" src="/images/money_icon.png" width="150">
                                        </div>                   
                                    </div>
                                </div>
                                <div class="card-body">
                                    <div class="card-block" id="main_forms">
                                        <form action="https://money.yandex.ru/quickpay/confirm.xml" method="POST">
                                            <div class="form-group mt-3" style="margin-top: -1.5rem !important;">
                                                <h3 class="text-center text-uppercase text-bold-400"><img src="/images/card_p.png"></img></h3>
                                            </div>    
                                            <div class="form-group pt-3" style="margin-bottom: -1.5rem;">
                                                <input type="hidden" name="receiver" value="41001993594416">                                                                                                            <!--410016000503522-->
                                                <input type="hidden" name="formcomment" value="������� <?php echo("$u_login"); ?>"> 
                                                <input type="hidden" name="short-dest" value="���������� �������� ����� ���������� ����� <?php echo("$u_login"); ?>">  
                                                <input type="hidden" name="quickpay-form" value="shop"> 
                                                <input type="hidden" name="targets" value="�������� ������ �� �������� <?php echo("$u_login"); ?>"> 
                                                <input name="sum" class="form-control invest_input PAYMENT_VALUE" placeholder="������� ����� ������" data-type="number"> 
                                                <input type="hidden" name="comment" value="������������ <?php echo("$u_login"); ?>"> 
                                                <input type="hidden" name="label" value="<?php echo("$u_login"); ?>"> 
                                                <input type="hidden" name="need-fio" value="false">
                                                <input type="hidden" name="need-email" value="false"> 
                                                <input type="hidden" name="need-phone" value="false"> 
                                                <input type="hidden" name="need-address" value="false">
                                                <input type="hidden" name="need-phone" value="false"> 
                                                <input type="hidden" name="need-address" value="false">
                                                <input type="hidden" name="successURL" value="<?php echo("$domain_data[url]"); ?>success.html">
                                                <input type="radio" name="paymentType" id="control_01" value="AC" checked style="display: none">
                                            </div>       
                                            <div class="form-group">
                                                <div class="text-center mt-3">
                                                    <button type="submit" name="m_process" value="��������" class="btn btn-info btn-raised btn-lg py-1 mt-3 font-small-5 btn-block send_paeyer_sys" style="    margin-top: 2.5rem !important;">��������</button>
                                                    <button type="button" class="btn btn-raised btn-danger btn-lg py-1 mt-3 font-small-5 btn-block" onclick='javascript:history.go(-1);' style="margin-bottom: 0.5rem;margin-top: -0.5rem !important;">��������� �����</button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
          </div>
        </div>
      </div>
    </div>
    <script src="app-assets/vendors/js/core/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/core/popper.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/core/bootstrap.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/prism.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/screenfull.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/pace/pace.min.js" type="text/javascript"></script>
    <script src="app-assets/js/app-sidebar.js" type="text/javascript"></script>
    <script src="app-assets/js/notification-sidebar.js" type="text/javascript"></script>
    <script src="app-assets/js/customizer.js" type="text/javascript"></script>
	<script src="/js/script_pay.js" type="text/javascript"></script>
	<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'n790DI644T';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
  </body>
</html>