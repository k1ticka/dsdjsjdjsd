

<!DOCTYPE html>
<html lang="en" class="loading">
  
<!-- Mirrored from pixinvent.com/apex-angular-4-bootstrap-admin-template/html-demo-1/lock-screen-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Jan 2018 20:32:20 GMT -->
<head>
     <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="description" content="Apex admin is super flexible, powerful, clean &amp; modern responsive bootstrap 4 admin template with unlimited possibilities.">
    <meta name="keywords" content="admin template, Apex admin template, dashboard template, flat admin template, responsive admin template, web app">
    <meta name="author" content="PIXINVENT">
    <title>AXPREO - �������� ������ ����� ��������� ������� VISA QIWI WALLET</title>
    <link rel="apple-touch-icon" sizes="60x60" href="app-assets/img/ico/apple-icon-60.html">
    <link rel="apple-touch-icon" sizes="76x76" href="app-assets/img/ico/apple-icon-76.html">
    <link rel="apple-touch-icon" sizes="120x120" href="app-assets/img/ico/apple-icon-120.html">
    <link rel="apple-touch-icon" sizes="152x152" href="app-assets/img/ico/apple-icon-152.html">
    <link rel="shortcut icon" type="image/x-icon" href="app-assets/img/ico/favicon.ico">
    <link rel="shortcut icon" type="image/png" href="app-assets/img/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900|Montserrat:300,400,500,600,700,800,900" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/feather/style.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/simple-line-icons/style.css">
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/perfect-scrollbar.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/prism.min.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN APEX CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/app.css">
    <!-- END APEX CSS-->
    <!-- BEGIN Page Level CSS-->
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <!-- END Custom CSS-->	
  </head>
  <body data-col="1-column" class=" 1-column  blank-page blank-page">
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    <div class="wrapper">
      <div class="main-panel">
        <div class="main-content">
          <div class="content-wrapper"><!--Lock Screen Starts-->
<section id="lock-screen">
    <div class="container-fluid gradient-crystal-clear">
        <div class="row full-height-vh">
            <div class="col-12 d-flex align-items-center justify-content-center">
                <div class="card width-400">
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="card-title font-medium-5 pt-2 ml-2">�������� ������</div>
                        </div>
                        <div class="col-sm-4">
                            <div class="text-right card-img overlap">
                                <img alt="avtar" class="mb-1" src="/images/money_icon.png" width="150">
                            </div>                   
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="card-block" id="main_forms">	
							<form id="invest_form" action="/?page=invest" method="POST" class="form" (ngSubmit)="onSubmit()">						
							<?php
if($d_vklad!=0){
echo '<div class="invest_stoped">���������� ������� ��������������</div>';
}
else{

$b_zam=0;

$depbtq=mysql_query("SELECT SUM(osum2) FROM operations WHERE ologin='$u_login' AND osum>0 AND otype=3 AND odate>'$time'");
$depbtm=mysql_fetch_row($depbtq);
$b_zam=$depbtm[0];


$can_dep='';

if(($d_max-$b_zam)>=$d_min){
$can_dep='�� '.$d_min.' �� '.($d_max-$b_zam);
}

if($can_dep==''){ echo '<div class="invest_lim_sum">��������� ����� ����� �������</div>'; }
else{
if($cpop==0){
echo '



';
}
}
}
?>
<?php
if($d_vklad==0){

$cpop=1;
$cnaq=mysql_query("SELECT * FROM operations WHERE ologin='$u_login' AND osum=0.00 AND osum2=0.00");
$cnam=mysql_num_rows($cnaq);

if($cnam>$lima-1){
$cpop=0;
}

if(!empty($_POST['batch']) && !empty($plan[$_POST['plan']])){

if($cpop==1){

$batch=preg_replace("#[^0-9a-z]+#i",'',$_POST['batch']);
$plan_id=$_POST['plan'];

if(strlen($batch)>5 && strlen($batch)<50){

$plusq=mysql_query("SELECT * FROM operations WHERE obatch='$batch'");
if(mysql_num_rows($plusq)==0){

$time2=$time+3600*$plan[$plan_id][1];
$operiod=$plan[$plan_id][0];
$oparts=$plan[$plan_id][1]/$plan[$plan_id][0];
$ohours=$plan[$plan_id][1];
$oproc=$plan[$plan_id][2];
$opproc=str_replace('.00','',number_format($oproc/$oparts,2,'.',''));

$orefrbp=0;
if($u_ref!=''){
$rq=mysql_query("SELECT refback FROM users WHERE login='$u_ref'");
if(mysql_num_rows($rq)==0){ die('refback not found'); }
$rm=mysql_fetch_row($rq);
$orefrbp=$rm[0];
}

mysql_query("INSERT INTO operations (ologin,otype,odate,odate2,oplan,operiod,oparts,ohours,opproc,oproc,oref,orefrbp,orefproc,obatch) VALUES ('$u_login','3','$time2','$time','$plan_id','$operiod','$oparts','$ohours','$opproc','$oproc','$u_ref','$orefrbp','$d_ref','$batch')") or die('inserting batch data error');
}
}

}

}

if($cpop==0){
echo '<div class="withdrawal_error"><div class="alert alert-dismissable alert-danger"><h3>�������� !</h3> �� �������� ����� ������, ����������� � ���������.<br>�������� �� ���������...
								  </div></div>';
}

if($can_dep!='' && $cpop==1){
?>
                                <div class="form-group mt-3" style="
    margin-top: -1.5rem !important;
">
                                    <h3 class="text-center text-uppercase text-bold-400"><img src="/icon/bitco.png"></img></h3>
									<h3 class="text-center text-uppercase text-bold-400" style="
    font-size: 17px;
">����������� ������� �� �����:</h3>
<h3 class="text-center text-uppercase text-bold-400" style="font-size: 29px;">1LnCK2MgyPE77L2YgXkhUU6CmLq4oU1Ctd</img></h3>
<h3 class="text-center text-uppercase text-bold-400" style="font-size: 13px;margin-bottom: 0.5rem;padding-top: 0rem !important;margin-top: 30px;">������� ���������� ������ ��������</h3>
                                </div>
<div class="form-group pt-3" style="
    margin-bottom: 0.5rem;
    padding-top: 0rem !important;
    margin-top: -15px;
">
  	  
   <input name="batch" type="text" maxlength="30"  class="form-control"  placeholder="������� ����������" ngModel required >    
<select id="deposits_plan" name="plan" onchange="dep_calc();"  style="
 margin-left: 5px;
 padding: 11px 6px;
 padding-top: 7px;
 border-radius: 2px;
 display: none;
">
<?php
foreach($plan as $pa1=>$pa2){
echo '<option value="'.$pa1.'">'.$pa2[2].'% '.$pname[$pa2[1]].'</option>';
}
?>
</select>   
                                </div>
					
						
                                <div class="form-group">
                                    <div class="text-center mt-3">
									<a href="javascript:with(document.getElementById('invest_form')){ submit(); }" class="btn btn-info btn-raised btn-lg py-1 mt-3 font-small-5 btn-block" >��������� �������</a>
										<button type="button" class="btn btn-raised btn-danger btn-lg py-1 mt-3 font-small-5 btn-block" onclick='javascript:history.go(-1);' style="
    margin-bottom: 0.5rem;
    margin-top: -0.5rem !important;
">��������� �����</button>
                                    </div>
                                </div>
                            </form>
							
							
<?php }} ?>
							
							
							
							
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--Lock Screen Ends-->
          </div>
        </div>
      </div>
    </div>
    <!-- ////////////////////////////////////////////////////////////////////////////-->

    <!-- BEGIN VENDOR JS-->	
    <script src="app-assets/vendors/js/core/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/core/popper.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/core/bootstrap.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/prism.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/screenfull.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/pace/pace.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN APEX JS-->
    <script src="app-assets/js/app-sidebar.js" type="text/javascript"></script>
    <script src="app-assets/js/notification-sidebar.js" type="text/javascript"></script>
    <script src="app-assets/js/customizer.js" type="text/javascript"></script>
	    <script src="/js/script_pay.js" type="text/javascript"></script>
    <!-- END APEX JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- END PAGE LEVEL JS-->
	<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'n790DI644T';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
  </body>

<!-- Mirrored from pixinvent.com/apex-angular-4-bootstrap-admin-template/html-demo-1/lock-screen-page.html by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 04 Jan 2018 20:32:21 GMT -->
</html>