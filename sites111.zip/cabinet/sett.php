 <?php
 
	$show_field = false;
	$pass_field_tru = false;
	$pass_field_bad = false;
	
if( isset( $_REQUEST['change_data'] ) && trim( $_REQUEST['change_data'] ) == '��������� ������' )
	{
		if( 
			isset( $_REQUEST['old_password'] ) && trim( $_REQUEST['old_password'] ) != '' && 
			isset( $_REQUEST['new_password'] ) && trim( $_REQUEST['new_password'] ) != '' &&
			isset( $_REQUEST['retype_password'] ) && trim( $_REQUEST['retype_password'] ) != ''
		)
		{
			## ��������� ������
			function decryptIt( $q ) {
				$cryptKey  = 'qJB0rGtIn5UB1xG03efyCp22';
				$qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
				return( $qDecoded );
			}
			
			$decrypted = decryptIt( trim( $_REQUEST['sec_data'] ) );
			
			$ulq = mysql_query("SELECT `pass` FROM `users` WHERE `login` LIKE '" . $decrypted . "'");
			$user_data_in_base = mysql_fetch_assoc( $ulq );
			$user_pass_db = trim( $user_data_in_base['pass'] );
			
			if ( md5( trim( $_REQUEST['old_password'] ) ) == $user_pass_db )
				{
					mysql_query( "UPDATE  `vipse382_coinmars`.`users` SET  `pass` =  '" . md5( trim( $_REQUEST['new_password'] ) ) . "' WHERE  `users`.`login` = '". $decrypted ."';" );
					
					echo "<script> alert( '������ ������� �������' );</script>";
				}
			else
				{
					echo "<script> alert( '�� �� ����� ������� ������ ������!' );</script>";
				}
		}
		
		if( isset( $_REQUEST['wmr_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse382_coinmars`.`users` 
									SET  
										`wmr` =  '" . trim( $_REQUEST['wmr_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['yandex_rub_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse382_coinmars`.`users` 
									SET  
										`yandex` =  '" . trim( $_REQUEST['yandex_rub_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['payeer_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse382_coinmars`.`users` 
									SET  
										`payeer` =  '" . trim( $_REQUEST['payeer_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
				if( isset( $_REQUEST['mastercard_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse382_coinmars`.`users` 
									SET  
										`mastercard` =  '" . trim( $_REQUEST['mastercard_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
			
			
		if( isset( $_REQUEST['qiwi_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse382_coinmars`.`users` 
									SET  
										`qiwi` =  '" . trim( $_REQUEST['qiwi_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}					
		?>
		<script>
			var object = document.getElementById( 'save_ok' );
			object.style.display = 'block'; 
			window.setTimeout( function(){ object.style.display = 'none'} ,2000);

		</script>
		<?php
	}

	## ������ ������������
	$ulq = mysql_query("SELECT * FROM `users` WHERE `login` LIKE '" . $u_login . "'");
	$user_data_in_base = mysql_fetch_assoc( $ulq );
	
	$user_wmr		= ( trim( $user_data_in_base['wmr'] ) == '' )		? '': trim( $user_data_in_base['wmr'] );
	$user_yandex	= ( trim( $user_data_in_base['yandex'] ) == '' )	? '': trim( $user_data_in_base['yandex'] );
	$user_payeer	= ( trim( $user_data_in_base['payeer'] ) == '' )	? '': trim( $user_data_in_base['payeer'] );
	$user_qiwi		= ( trim( $user_data_in_base['qiwi'] ) == '' )		? '': trim( $user_data_in_base['qiwi'] );	
	$user_mastercard		= ( trim( $user_data_in_base['mastercard'] ) == '' )		? '': trim( $user_data_in_base['mastercard'] );		
	
	
function encryptIt( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp22';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
}

$secure_user_name = encryptIt( $u_login );
?>
<?php


include $_SERVER['DOCUMENT_ROOT']."/head_cab.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>
 


        <div id="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">


         
              <?php


include $_SERVER['DOCUMENT_ROOT']."/menu.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>
<div class="holder-content">



                            <ul class="bread-crumbs">
    <li><a href="#">�������</a></li>
    <li>��������� ��������</li>
</ul>

 

 
			
			
			<div class="d-settings__holder">
    <div class="d-settings__holder-title">
        <h3>������������ ��������</h3>
    </div>
    <div class="d-settings__holder__content">
       <div class="row">
                                    <div class="col-12 col-md-4">
                                        <p class="text-bold-700 text-uppercase mb-0">��������� ����������</p>
                                      <span class="bal-title"><?php echo date("d.m.Y h:i:s", $user_data_in_base['last_seen']); ?></span>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <p class="text-bold-700 text-uppercase mb-0">��������� IP-�����</p>
                                      <span class="bal-title"><?php echo $user_data_in_base['ip']; ?></span>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <p class="text-bold-700 text-uppercase mb-0">��� IP-�����</p>
                                        <span class="bal-title"><?php echo $ip; ?></span>
                                    </div>
                                </div>
    </div>
</div>
			
			
 
<form action="" class="user_send_data" method="POST">
 <div class="group-content">
    <section id="content">
        <div class="holder-profile">
            <div class="d-settings__holder __no-margin">
                <div class="d-settings__holder-title __no-margin">
                    <h3>��������� ��������</h3>
                </div>
            </div>
            <div class="holder-white">
                
                    <fieldset>
                        <div class="group">
                            <div class="block-profile">
                                <span class="label-prof"><i class="fa fa-usd" aria-hidden="true"></i> ������ �� ���������:</span>
<!--                                -->                                <ul class="list-check">
                                                                        <li><label class="d-default-form__label d-default-form__label__no-bsh">
                                            <input type="radio" name="RUB" value="2" class="d-default-form__check" checked="">
                                            <span class="d-default-form__check-span"></span>
                                            <span class="d-default-form__check__text">RUB</span>
                                        </label>
                                    </li>
                                </ul>

                                <span class="label-prof"><i class="fa fa-flag" aria-hidden="true"></i>���� �������:</span>

								<div class="form-group field-users-language">

<div class="fs-dropdown fs-light " id="users-language-dropdown" tabindex="0" role="listbox" aria-haspopup="true" aria-live="polite" aria-labeledby="users-language-dropdown-selected">
<button type="button" class="fs-dropdown-selected" id="users-language-dropdown-selected" tabindex="-1">�������</button>
<div class="fs-dropdown-options">
<button type="button" class="fs-dropdown-item fs-dropdown-item_selected" data-value="RU" role="option" "aria-selected"="true">�������</button>
 
</div>
</div>

<div class="help-block"></div>
</div><!---->


 <span class="label-prof"><i class="fa fa-user-circle" aria-hidden="true"></i>���:</span>
                                <div class="holder-input">
                                    <div class="form-group field-forumprofile has-success">

<input type="text" value="<?php echo $u_name; ?>" class="d-default-form__form-control"  aria-invalid="false" <?php if ($u_name != '') {echo "disabled='disabled'";} else {echo "name='u_name'";} ?>>

<div class="help-block"></div>
</div>                                </div>


 <span class="label-prof"><i class="fa fa-user" aria-hidden="true"></i>�����:</span>
                                <div class="holder-input">
                                    <div class="form-group field-forumprofile has-success">

<input type="text" value="<?php echo $u_login; ?>" class="d-default-form__form-control"  aria-invalid="false" <?php if ($u_login != '') {echo "disabled='disabled'";} else {echo "name='u_login'";} ?>>

<div class="help-block"></div>
</div>                                </div>







                                <span class="label-prof"><i class="fa fa-envelope" aria-hidden="true"></i>Email:</span>
                                <div class="holder-input">
                                    <div class="form-group field-email has-success">

<input type="text"  class="d-default-form__form-control" value="<?php echo $u_email; ?>" readonly="" title="��� �������� email, ���������� � ��������������" placeholder="Email" aria-invalid="false" <?php if ($u_email != '') {echo "disabled='disabled'";} else {echo "name='u_email'";} ?>>

<div class="help-block"></div>
</div>                                </div>
   <span class="label-prof">�������� ������:</span>
                         <span class="label-prof"><i class="fa fa-key" aria-hidden="true"></i> ������ ������:</span>
                                <div class="holder-input">
                                    <input type="password" name="old_password" value=""  id="old-password" class="d-default-form__form-control old_password">
                                </div>

                              <span class="label-prof"><i class="fa fa-key" aria-hidden="true"></i> ����� ������:</span>
                                <div class="holder-input">
                                    <input type="password" name="new_password" type="password" value="" autocomplete="off" class="d-default-form__form-control retype_password" id="new-password" >
                                </div>

                               

                                <span class="label-prof"><i class="fa fa-key" aria-hidden="true"></i> ��������� ����� ������:</span>
                                <div class="holder-input">
                                    <input name="retype_password" value="" type="password" id="old-password4" autocomplete="off" class="d-default-form__form-control retype_password">
                              <input type="hidden" name="sec_data" value="<?php echo $secure_user_name; ?>" >
							  </div>

                            </div>
							
							  <?php

$sql_ref=mysql_fetch_row(mysql_query("SELECT COUNT(ref) FROM `users` WHERE `ref`='".$u_login."'"));

  ?>
							
                            <div class="block-profile">
                                <div class="number-pcs">
                                    <span>���������� ���������: <span class="pcs"><?php echo $sql_ref[0]; ?> ��.</span></span>
                                </div>
                                <span class="label-prof"><i class="fa fa-link" aria-hidden="true"></i> ��� ���������:</span>
                                <div class="d-default-form__group margin2 d-default-form__group__api">
                                    <label class="d-default-form__label d-default-form__label__no-bsh">
                                        <div class="d-default-form__bsh-box">
                                      <input type="text"value="<?php echo $u_ref; ?>" title="��� �������� ��������, ���������� � ��������������" class="d-default-form__form-control" aria-invalid="false" <?php if ($u_ref != '') {echo "disabled='disabled'";} else {echo "name='u_ref'";} ?>>
									  </div>
                                    </label>
                                </div>
								
								      <span class="label-prof"><i class="fa fa-link" aria-hidden="true"></i> ����������� ������:</span>
                                <div class="d-default-form__group margin2 d-default-form__group__api">
                                    <label class="d-default-form__label d-default-form__label__no-bsh">
                                        <div class="d-default-form__bsh-box">
                                            <input type="text" class="d-default-form__form-control __api" readonly="" value="https://<?php echo $site; ?>/?ref=<?php echo $u_login; ?>">
     
                                        </div>
                                    </label>
                                </div>
                                <span class="label-prof">��������� ���������:</span>

                                <span class="label-prof">VISA QIWI WALLET:<span style="color: #d00;"><?php
			if ( trim( $user_qiwi ) == '' )
				echo " (�� ��������)\n";
			?></span></span>
                                <div class="holder-input">
                                    <div class="form-group field-potback-create has-success">
	<input type="text" class="d-default-form__form-control" autocomplete="off" placeholder="QIWI �������" id="new-password66" aria-describedby="basic-addon4" value="<?php echo $user_qiwi; ?>" <?php if ($user_qiwi != '') {echo "disabled='disabled'";} else {echo "name='qiwi_number'";} ?>>
 

<div class="help-block"></div>
</div>                                </div>


              <span class="label-prof">VISA/MASTERCARD:<span style="color: #d00;"><?php
			if ( trim( $user_mastercard ) == '' )
				echo " (�� ��������)\n";
			?></span></span>
                                <div class="holder-input">
                                    <div class="form-group field-potback-create has-success">
	<input type="text" class="d-default-form__form-control" autocomplete="off" placeholder="VISA/MASTERCARD" id="new-password66" aria-describedby="basic-addon4" value="<?php echo $user_mastercard; ?>" <?php if ($user_mastercard != '') {echo "disabled='disabled'";} else {echo "name='mastercard_number'";} ?>>
 

<div class="help-block"></div>
</div>                                </div>

                                <span class="label-prof">������������: <span style="color: #d00;"><?php
			if ( trim( $user_yandex ) == '' )
				echo " (�� ��������)\n";
			?></span></span>
                                <div class="holder-input">
                                    <div class="form-group field-potback-approve has-success">
<input type="text" class="d-default-form__form-control"  autocomplete="off" placeholder="������ �������" id="new-password67" aria-describedby="basic-addon4" value="<?php echo $user_yandex; ?>" <?php if ($user_yandex != '') {echo "disabled='disabled'";} else {echo "name='yandex_rub_number'";} ?>>
 

<div class="help-block"></div>
</div>                                </div>

                                <span class="label-prof">Perfect Money: <span style="color: #d00;"><?php
		if ( trim( $user_wmr ) == '' )
			echo " (�� ��������)\n";
		?></span></span>
                                <div class="holder-input">
                                    <div class="form-group field-potback-reject has-success">
	<input type="text" class="d-default-form__form-control"  autocomplete="off" placeholder="Perfect Money �������" id="new-password68" aria-describedby="basic-addon4" value="<?php echo $user_wmr; ?>" <?php if ($user_wmr != '') {echo "disabled='disabled'";} else {echo "name='wmr_number'";} ?>>
 

<div class="help-block"></div>
</div>                                </div>
    <span class="label-prof">Payeer: <span style="color: #d00;"><?php
			if ( trim( $user_payeer ) == '' )
				echo " (�� ��������)\n";
			?></span></span>
                                <div class="holder-input">
                                    <div class="form-group field-potback-reject has-success">
						 <input type="text" class="d-default-form__form-control"  autocomplete="off" placeholder="Payeer �������" id="new-password69" aria-describedby="basic-addon4" value="<?php echo $user_payeer; ?>" <?php if ($user_payeer != '') {echo "disabled='disabled'";} else {echo "name='payeer_number'";} ?>>
						 

<div class="help-block"></div>
</div>                                </div>
   <input type="hidden" name="sec_data"  value="<?php echo $secure_user_name; ?>" >
   <input type="submit" name="change_data" class="btn btn-green d-btn-green save_settings" value="��������� ������">
 
                            </div>
                        </div>
<!--                        <span class="label-prof"><i class="fa fa-envelope" aria-hidden="true"></i> --><!--:</span>-->
<!---->
<!--                        <ul class="list-check">-->
<!--                            <li>-->
<!--                            --><!--                            </li>-->
<!--                            <li>-->
<!--                            --><!--                            </li>-->
<!--                            <li>-->
<!--                            --><!--                            </li>-->
<!--                            <li>-->
<!--                            --><!--                            </li>-->
<!--                            <li>-->
<!--                            --><!--                            </li>-->
<!--                        </ul>-->
                      
                    </fieldset>
                
            </div>
        </div>
    </section>
</div></form>




               </div>
			   
                    </div>
					
                </div>
				
            </div>
			
        </div>
		
ertert
   <div class="row">
                                    <div class="col-12 col-md-4">
                                        <p class="text-bold-700 text-uppercase mb-0">��������� ����������</p>
                                        <p class="mb-0"><?php echo date("d.m.Y h:i:s", $user_data_in_base['last_seen']); ?></p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <p class="text-bold-700 text-uppercase mb-0">��������� IP-�����</p>
                                        <p class="mb-0"><?php echo $user_data_in_base['ip']; ?></p>
                                    </div>
                                    <div class="col-12 col-md-4">
                                        <p class="text-bold-700 text-uppercase mb-0">��� IP-�����</p>
                                        <p class="mb-0"><?php echo $ip; ?></p>
                                    </div>
                                </div>
								567567

 
<?php


include $_SERVER['DOCUMENT_ROOT']."/cab_footer.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>