<?php
	$show_field = false;
	$pass_field_tru = false;
	$pass_field_bad = false;
	
if( isset( $_REQUEST['change_data'] ) && trim( $_REQUEST['change_data'] ) == 'Сохранить данные' )
	{
		if( 
			isset( $_REQUEST['old_password'] ) && trim( $_REQUEST['old_password'] ) != '' && 
			isset( $_REQUEST['new_password'] ) && trim( $_REQUEST['new_password'] ) != '' &&
			isset( $_REQUEST['retype_password'] ) && trim( $_REQUEST['retype_password'] ) != ''
		)
		{
			## Проверяем данные
			function decryptIt( $q ) {
				$cryptKey  = 'qJB0rGtIn5UB1xG03efyCp22';
				$qDecoded      = rtrim( mcrypt_decrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), base64_decode( $q ), MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ), "\0");
				return( $qDecoded );
			}
			
			$decrypted = decryptIt( trim( $_REQUEST['sec_data'] ) );
			
			$ulq = mysql_query("SELECT `pass` FROM `users` WHERE `login` LIKE '" . $decrypted . "'");
			$user_data_in_base = mysql_fetch_assoc( $ulq );
			$user_pass_db = trim( $user_data_in_base['pass'] );
			
			if ( md5( trim( $_REQUEST['old_password'] ) ) == $user_pass_db )
				{
					mysql_query( "UPDATE  `vipse162_777`.`users` SET  `pass` =  '" . md5( trim( $_REQUEST['new_password'] ) ) . "' WHERE  `users`.`login` = '". $decrypted ."';" );
					
					echo "<script> alert( 'Пароль успешно изменен' );</script>";
				}
			else
				{
					echo "<script> alert( 'Вы не верно указали старый пароль!' );</script>";
				}
		}
		
		if( isset( $_REQUEST['wmr_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`wmr` =  '" . trim( $_REQUEST['wmr_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['yandex_rub_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`yandex` =  '" . trim( $_REQUEST['yandex_rub_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['payeer_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`payeer` =  '" . trim( $_REQUEST['payeer_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
		if( isset( $_REQUEST['card_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`card` =  '" . trim( $_REQUEST['card_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
					if( isset( $_REQUEST['advcash_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`advcash` =  '" . trim( $_REQUEST['advcash_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}
			
		if( isset( $_REQUEST['qiwi_number'] ) )
			{
				mysql_query( 
								"UPDATE  
										`vipse162_777`.`users` 
									SET  
										`qiwi` =  '" . trim( $_REQUEST['qiwi_number'] ) . "' 
									WHERE  
										`users`.`login` = '". $u_login ."';" 
				);
			}					
		?>
		<script>
			var object = document.getElementById( 'save_ok' );
			object.style.display = 'block'; 
			window.setTimeout( function(){ object.style.display = 'none'} ,2000);

		</script>
		<?php
	}

	## данные пользователя
	$ulq = mysql_query("SELECT * FROM `users` WHERE `login` LIKE '" . $u_login . "'");
	$user_data_in_base = mysql_fetch_assoc( $ulq );
	
	$user_wmr		= ( trim( $user_data_in_base['wmr'] ) == '' )		? '': trim( $user_data_in_base['wmr'] );
	$user_yandex	= ( trim( $user_data_in_base['yandex'] ) == '' )	? '': trim( $user_data_in_base['yandex'] );
	$user_payeer	= ( trim( $user_data_in_base['payeer'] ) == '' )	? '': trim( $user_data_in_base['payeer'] );
	$user_qiwi		= ( trim( $user_data_in_base['qiwi'] ) == '' )		? '': trim( $user_data_in_base['qiwi'] );
	$user_card		= ( trim( $user_data_in_base['card'] ) == '' )		? '': trim( $user_data_in_base['card'] );	
	$user_advcash	= ( trim( $user_data_in_base['advcash'] ) == '' )		? '': trim( $user_data_in_base['advcash'] );	
	
	
function encryptIt( $q ) {
    $cryptKey  = 'qJB0rGtIn5UB1xG03efyCp22';
    $qEncoded      = base64_encode( mcrypt_encrypt( MCRYPT_RIJNDAEL_256, md5( $cryptKey ), $q, MCRYPT_MODE_CBC, md5( md5( $cryptKey ) ) ) );
    return( $qEncoded );
}

$secure_user_name = encryptIt( $u_login );
?>		 

		 <div aria-hidden="true" aria-labelledby="myLargeModalLabel" class="modal fade bd-example-modal-lg" role="dialog" tabindex="-1">
                                                                        <div class="modal-dialog modal-lg">
                                                                                <div class="modal-content">
                                                                                        
                                                                            
        <div class="element-wrapper">
                <div class="element-box">
                      
                                <div class="element-info">
                                        <div class="element-info-with-icon">
                                                <div class="element-info-icon">
                                                        <div class="os-icon os-icon-wallet-loaded"></div>
                                                </div>
                                                <div class="element-info-text">
                                                        <h5 class="element-inner-header">Настройка профиля</h5>
                                                        <div class="element-inner-desc">
                                                                Настройки личного профиля, смена пароля и привязка электронных платежных систем.
                                                        </div>
                                                </div>
                                        </div>
                                </div>
                              
                         <fieldset class="form-group">
                                        <legend><span>Смена аватара</span></legend>
											    <form class="form row" action="avatar_uploader.php" enctype="multipart/form-data" class="user_send_data" method="POST">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">        
                                                            <div class="file-upload">   
                                                                <label>         
                                                                    <input type="file" name="avatar">          
                                                                    <span>Выберите файл с компьютера</span>     
                                                                </label> 
                                                            </div>
                                                            <input type="hidden" class="btn btn-info no-radius btn-lg" name="go">
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <center><button value="Загрузить аватар" class="mr-2 mb-2 btn btn-primary">Загрузить изображение</button></center>
                                                        </div>              
                                                    </div>
                                                </form>
                                            
												<form class="form" action="" class="user_send_data" method="POST">
                                                    <legend style="margin-bottom: 1.5rem;"><span>Смена пароля</span></legend>
                                                <div class="row">
                                                    <div class="col-sm-4">
                                                    <div class="form-group">
                                                                <label for="">Укажите старый пароль</label>
																<input type="password" name="old_password" value="" class="form-control old_password" data-error="Пожалуйста укажите старый пароль" placeholder="Введите старый пароль"
                                                                 type="text">
                                                                <div class="help-block form-text with-errors form-control-feedback old_password_error"></div>
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-4">
                                                          <div class="form-group">
                                                                <label for="">Укажите новый пароль</label>
																<input type="password" name="new_password" value="" class="form-control retype_password" data-error="Пожалуйста введите новый пароль" placeholder="Введите новый пароль"
                                                                 type="text">
                                                                <div class="help-block form-text with-errors form-control-feedback new_password_error"></div>
                                                        </div>             
                                                    </div>
													       <div class="col-sm-4">
                                                          <div class="form-group">
                                                                <label for="">Повторите новый пароль</label>
																<input class="form-control" name="retype_password" value="" type="password" data-error="Пожалуйста повторите новый пароль" placeholder="Повторите новый пароль" type="text">
                                                                <div class="help-block form-text with-errors form-control-feedback retype_password_error"></div>
                                                        </div>             
                                                    </div>
                                                </div>
                                        <legend style="margin-bottom: 1.5rem;"><span>Привязка платежных систем</span></legend>
                                        <div class="row">
                                                <div class="col-sm-6">
                                                        <div class="form-group  ">
                                                                <label for="">Платежная система Perfect Money</label>
																<input class="form-control" data-error="Your email address is invalid" name="wmr_number" placeholder="U1111111" autocomplete="off" required="required" type="text" value="<?php echo $user_wmr; ?>">
                                                                <div class="help-block form-text with-errors form-control-feedback"><ul class="list-unstyled"><li style="
    color: #e65252;
"><?php
		if ( trim( $user_wmr ) == '' )
			echo ' Платежная система Perfect Money не указана!';
		?></li></ul></div>
                                                        </div>
                                                </div>
                                                <div class="col-sm-6">
                                                     <div class="form-group  ">
                                                                <label for="">Платежная система Payeer</label>
																<input class="form-control" data-error="Your email address is invalid" name="payeer_number" placeholder="Pxxxxxxx" type="text" autocomplete="off" required="required" value="<?php echo $user_payeer; ?>">
                                                                <div class="help-block form-text with-errors form-control-feedback"><ul class="list-unstyled"><li style="
    color: #e65252;
"><?php
			if ( trim( $user_payeer ) == '' )
				echo ' Платежная система Payeer не указана!';
			?>
		
		</li></ul></div>
                                                        </div>
                                                </div>
                                        </div>
                                        <div class="row">
                                                <div class="col-sm-6">
                                                       <div class="form-group  ">
                                                                <label for="">Платежная система ЯндексДеньги</label>
																<input class="form-control" data-error="Your email address is invalid" name="yandex_rub_number" placeholder="4111111111" autocomplete="off" required="required" type="text" value="<?php echo $user_yandex; ?>">
                                                                <div class="help-block form-text with-errors form-control-feedback"><ul class="list-unstyled"><li style="
    color: #e65252;
"> 
		<?php
			if ( trim( $user_yandex ) == '' )
				echo 'Платежная система ЯндексДеньги не указана!';
			?>
		</li></ul></div>
                                                        </div>
                                                </div>
                                                <div class="col-sm-6">
                                                      <div class="form-group  ">
                                                                <label for="">Платежная система VISA QIWI WALLET </label>
																<input class="form-control" data-error="Your email address is invalid"  placeholder="+71111111111" required="required" type="text" autocomplete="off" name="qiwi_number" value="<?php echo $user_qiwi; ?>">
                                                                <div class="help-block form-text with-errors form-control-feedback"><ul class="list-unstyled"><li style="
    color: #e65252;
">
		<?php
			if ( trim( $user_qiwi ) == '' )
				echo'Платежная система VISA QIWI WALLET не указана!';
			?></li></ul></div>
                                                        </div>
                                                </div>
                                        </div>
                                         
                                        
                                </fieldset>
                            
                                <div class="form-buttons-w form-actions">
								<input type="hidden" name="sec_data" value="<?php echo $secure_user_name; ?>" >   
								<button class="btn btn-primary save_settings" name="change_data" type="submit" value="Сохранить данные">Сохранить настройки</button>
                                         <button class="btn btn-secondary" data-dismiss="modal" type="button">Закрыть окно</button> 
                                </div>
                        
                </div>
        </div>

                                                                                        </form>
                                                                                </div>
                                                                        </div>
                                                                </div>
<style> .file-upload {  
margin-left: 20%;   
    font-family: "Avenir Next W01","Proxima Nova W01","Rubik",-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif;
position: relative;
    overflow: hidden;
    background-image: -webkit-linear-gradient(45deg, #047bf8, #047bf8);
    border-radius: 6px;
    padding: 7px 28px 19px 28px;
    color: #fff;
    text-align: center;
    line-height: 34px;
    width: 60%; } 
    .file-upload:hover {    
    background-image: -webkit-linear-gradient(45deg, #035dbc, #035dbc); } 
	.file-upload .label:focus {    
        outline: 0;
		box-shadow: 0 0 0 2px rgba(4,123,248,0.5);
		
		
		} 
    .file-upload input[type="file"]{     display: none; /* Обязательно скрываем настоящий Input File */ } 
    .file-upload label {      /* Растягиваем label на всю возможную площадь блока .file-upload */   display: block;   position: absolute;      top: 0;      left: 0;      width: 100%;      height: 100%;    
    cursor: pointer; } 
    .file-upload span {        line-height: 25px;
    color: #fff; /* Делаем вертикальное выравнивание текста, который написан на кнопке */ }
</style> 