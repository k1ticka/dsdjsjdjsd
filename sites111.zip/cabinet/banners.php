<?php $banner1 = $domain_data['url']."banners/728x90.gif";
$banner2 = $domain_data['url']."banners/240x400.gif";
$banner3 = $domain_data['url']."banners/200x200.gif";
$banner4 = $domain_data['url']."banners/banner468x60.gif";
$ref_url = $domain_data['url']."?ref=".$u_login;?>
<div class="banner1">	
<div style="width: 728px; height: 90px; margin: 0 auto; padding-top: 1%;" >		
<img src='<?php echo $banner1; ?>'>	</div><br>
<br>	<center>
<input type="text" value="<a href='<?php echo $ref_url; ?>'><img src='<?php echo $banner1; ?>'></a>" style="width: 800px" disabled>
</center></div><br><center>
<div class="banner1">	<div style="margin: 0 auto; padding-top: 1% color: #22425a;    font-size: 22px;    font-weight: bold;">	
<img src='<?php echo $banner4; ?>'>	</div><br>	<center><input type="text" value="<a href='<?php echo $ref_url; ?>'>


<img src='<?php echo $banner4; ?>'></a>" style="width: 800px" disabled></center></div></center><br>
<center>
<div class="banner2">	

<div style="width: 240px; height: 400px; margin: 0 auto; ">	
<img src='<?php echo $banner2; ?>'></div>	
<br>
<input type="text" value="<a href='<?php echo $ref_url; ?>'><img src='<?php echo $banner2; ?>'></a>" style="width: 800px" disabled></div></center>

<br><center><div class="banner3">	
<div style="width: 200px; height: 200px; margin: 0 auto;">	
<img src='<?php echo $banner3; ?>'></div>	<br>
<input type="text" value="<a href='<?php echo $ref_url; ?>'><img src='<?php echo $banner3; ?>'></a>" style="width: 800px" disabled></div></center>
<br>
<br>
<br>
<br>