<!DOCTYPE html>
<html lang="en" class="loading">
  
<head>
 <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">

    <meta name="description" content="��������� � �������� ����� � AXPREO ��� �����-���� �������� � ����� �������! ����������� ������ �� ����� ����� ������!">

    <meta name="keywords" content="�����, ����������, ���������, ������, ������ � ���������, ������ ��� �������, ����� �����, ��������� 2018">
    <meta name="author" content="PIXINVENT">
    <title>AXPREO - ���������� ������ �������</title>
    <link rel="apple-touch-icon" sizes="60x60" href="app-assets/img/ico/apple-icon-60.html">
    <link rel="apple-touch-icon" sizes="76x76" href="app-assets/img/ico/apple-icon-76.html">
    <link rel="apple-touch-icon" sizes="120x120" href="app-assets/img/ico/apple-icon-120.html">
    <link rel="apple-touch-icon" sizes="152x152" href="app-assets/img/ico/apple-icon-152.html">
    <link rel="shortcut icon" type="image/x-icon" href="app-assets/img/ico/favicon.ico">
    <link rel="shortcut icon" type="image/png" href="app-assets/img/ico/favicon-32.png">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="apple-touch-fullscreen" content="yes">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <link href="https://fonts.googleapis.com/css?family=Rubik:300,400,500,700,900|Montserrat:300,400,500,600,700,800,900" rel="stylesheet">
    <!-- BEGIN VENDOR CSS-->
    <!-- font icons-->
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/feather/style.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/simple-line-icons/style.css">
    <link rel="stylesheet" type="text/css" href="app-assets/fonts/font-awesome/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/perfect-scrollbar.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/prism.min.css">
    <link rel="stylesheet" type="text/css" href="app-assets/vendors/css/chartist.min.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN APEX CSS-->
    <link rel="stylesheet" type="text/css" href="app-assets/css/app.css">
  <script src="/js/progressbar.js" type="text/javascript" ></script>
  <script src="/js.js" type="text/javascript" ></script>
    <!-- END APEX CSS-->
    <!-- BEGIN Page Level CSS-->
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <!-- END Custom CSS-->
  </head>
  <body data-col="2-columns" class=" 2-columns ">
    <!-- ////////////////////////////////////////////////////////////////////////////-->
    <div class="wrapper">


      <!-- main menu-->
      <!--.main-menu(class="#{menuColor} #{menuOpenType}", class=(menuShadow == true ? 'menu-shadow' : ''))-->
      <div data-active-color="white" data-background-color="man-of-steel" data-image="app-assets/img/sidebar-bg/01.jpg" class="app-sidebar">
        <!-- main menu header-->
        <!-- Sidebar Header starts-->
        <div class="sidebar-header">
          <div class="logo clearfix"><a href="/" class="logo-text float-left">
              <div class="logo-img"><img src="app-assets/img/logo.png"/></div><span class="text align-middle">AXPREO</span></a><a id="sidebarToggle" href="javascript:;" class="nav-toggle d-none d-sm-none d-md-none d-lg-block"><i data-toggle="expanded" class="ft-toggle-right toggle-icon"></i></a><a id="sidebarClose" href="javascript:;" class="nav-close d-block d-md-block d-lg-none d-xl-none"><i class="ft-x"></i></a></div>
        </div>
        <!-- Sidebar Header Ends-->
        <!-- / main menu header-->
        <!-- main menu content-->
        <div class="sidebar-content">
          <div class="nav-container">
            <ul id="main-menu-navigation" data-menu="menu-navigation" class="navigation navigation-main">
              
        
        <li><a href="/?page=deposits"><i class="icon-briefcase"></i><span data-i18n="" class="menu-title">��� ��������</span></a>
              </li>
        
              <li class=" nav-item"><a href="/?page=invest"><i class="icon-wallet"></i><span data-i18n="" class="menu-title">��������� ������</span></a>
              </li>
              <li class=" nav-item"><a href="/?page=withdrawal"><i class="icon-credit-card"></i><span data-i18n="" class="menu-title">������� ��������</span></a>
              </li>
              <li class=" nav-item"><a href="/?page=refs"><i class="icon-users"></i><span data-i18n="" class="menu-title">�����������</span></a>
              </li>
			  <li class=" nav-item"><a href="/?page=settings"><i class="icon-settings"></i><span data-i18n="" class="menu-title">���������</span></a>

              </li>
              <li class=" nav-item"><a href="/logout.php"><i class="icon-logout"></i><span data-i18n="" class="menu-title">�����</span></a>
              </li>
      <br>


              <li class="active"><a href="/?page=reviews_cab"><i class="icon-bubbles"></i><span data-i18n="" class="menu-title">������</span></a>
              </li>
              <li class=" nav-item"><a href="/?page=contact_cab"><i class="ft-life-buoy"></i><span data-i18n="" class="menu-title">���������</span></a>
              </li>
            </ul>
          </div>
        </div>
        <!-- main menu content-->
        <div class="sidebar-background"></div>
        <!-- main menu footer-->
        <!-- include includes/menu-footer-->
        <!-- main menu footer-->
      </div>
      <!-- / main menu-->

      <div class="main-panel">

        <!-- Navbar (Header) Starts-->
        <nav class="navbar navbar-expand-lg navbar-light bg-faded">
          <div class="container-fluid">
            <div class="navbar-header">
                    <button type="button" data-toggle="collapse" class="navbar-toggle d-lg-none float-left"><span class="sr-only">Toggle navigation</span><span class="icon-bar"></span><span class="icon-bar"></span><span class="icon-bar"></span></button>
            <h4 class="card-title" style="
    margin-top: 20px;
    font-size: 22px;
">���������� �������</h4>
            </div>
            <div class="navbar-container">
              <div id="navbarSupportedContent" class="collapse navbar-collapse">
        
       <div class="media mb-3" style="
">


  <? if($_SESSION['avatar'] != ""): ?>
          
        
          <img alt="96x96" class="media-object d-flex mr-3 align-self-center bg-success height-50 rounded-circle" src="images/avatars/<?=$_SESSION['avatar'];?>" alt="avatar" style="margin-top: 2px;">
          
        <?php elseif( $_SESSION['avatar'] == '' && USER_LOGGED ): ?>
  <img alt="96x96" class="media-object d-flex mr-3 align-self-center bg-success height-50 rounded-circle" src="/app-assets/img/portrait/avatars/avatar-08.png" alt="avatar" style="margin-top: 2px;">
    
        <? endif; ?>
        

                        
                        <div class="media-body">
                            <h4 class="font-medium-1 mt-2 mb-0" style="
    padding-top: 10px;
    margin-right: 23px;
"><?php echo $u_login; ?></h4>
                        </div>
                   
                    </div>
                <ul class="navbar-nav">
                  <li class="nav-item mr-2"><a id="navbar-fullscreen" href="javascript:;" class="nav-link apptogglefullscreen"><i class="ft-maximize font-medium-3 blue-grey darken-4"></i>
                      <p class="d-none">������ �����</p></a></li>
               
               
                  <li class="dropdown nav-item">
          <a id="dropdownBasic3" href="#" data-toggle="dropdown" class="nav-link position-relative dropdown-toggle">
          <i class="ft-user font-medium-3 blue-grey darken-4"></i>
                      <p class="d-none">������� ������������</p></a>
                    <div ngbdropdownmenu="" aria-labelledby="dropdownBasic3" class="dropdown-menu dropdown-menu-right">
          <a href="/?page=settings" class="dropdown-item py-1"><i class="ft-settings mr-2"></i><span>���������</span></a>
        
      
                      <div class="dropdown-divider"></div><a href="/logout.php" class="dropdown-item"><i class="ft-power mr-2"></i><span>�����</span></a>
                    </div>
                  </li>
                  
                </ul>
              </div>
            </div>
          </div>
        </nav>
        <!-- Navbar (Header) Ends-->

        <div class="main-content">
          <div class="content-wrapper"><!--Statistics cards Starts-->
<div class="row" id="auto_statistic_cab" ids="<?php $databasecode = base64_encode($u_login); echo $databasecode; ?>">
  <div class="col-xl-3 col-lg-6 col-md-6 col-12">
    <div class="card gradient-blackberry">
      <div class="card-body">
        <div class="card-block pt-2 pb-0">
          <div class="media">
            <div class="media-body white text-left">
            <span>��� ������� ����</span>
              <h3 class="font-large-1 mb-0"><?php echo number_format($b_tot,2,'.',','); ?> &#8381;</h3>
              
            </div>
            <div class="media-right white text-right">
              <i class="icon-wallet font-large-1"></i>
            </div>
          </div>
        </div>
        <div id="Widget-line-chart" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">         
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-lg-6 col-md-6 col-12">
    <div class="card gradient-ibiza-sunset">
      <div class="card-body">
        <div class="card-block pt-2 pb-0">
          <div class="media">
            <div class="media-body white text-left">
            <span>�������� �� ��������</span>
              <h3 class="font-large-1 mb-0"><?php echo str_replace('.00','',number_format($b_activ,2,'.',',')); ?> &#8381;</h3>
              
            </div>
            <div class="media-right white text-right">
              <i class="icon-speedometer font-large-1"></i>
            </div>
          </div>
        </div>
        <div id="Widget-line-chart1" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">          
        </div>

      </div>
    </div>
  </div>
  
  <div class="col-xl-3 col-lg-6 col-md-6 col-12">
    <div class="card gradient-green-tea">
      <div class="card-body">
        <div class="card-block pt-2 pb-0">
          <div class="media">
            <div class="media-body white text-left">
            <span>�������� � �������</span>
              <h3 class="font-large-1 mb-0"><?php echo str_replace('.00','',number_format($b_withed,2,'.',',')); ?> &#8381;</h3>
              
            </div>
            <div class="media-right white text-right">
              <i class="icon-credit-card font-large-1"></i>
            </div>
          </div>
        </div>
        <div id="Widget-line-chart2" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">        
        </div>
      </div>
    </div>
  </div>
  <div class="col-xl-3 col-lg-6 col-md-6 col-12">
    <div class="card gradient-pomegranate">
      <div class="card-body">
        <div class="card-block pt-2 pb-0">
          <div class="media">
            <div class="media-body white text-left">
            <span>��������� �������</span>
              <h3 class="font-large-1 mb-0"><?php echo str_replace('.00','',number_format($b_earned,2,'.',',')); ?> &#8381;</h3>
              
            </div>
            <div class="media-right white text-right">
            <i class="icon-pie-chart font-large-1"></i>
              
            </div>
          </div>
        </div>
        <div id="Widget-line-chart3" class="height-75 WidgetlineChart WidgetlineChartshadow mb-2">          
        </div>
      </div>
    </div>
  </div>
</div>
<!--Statistics cards Ends-->
        <div>				<div class="row">	<div class="col-sm-12">		<div class="card">		<div class="card-block">		<div class="card-header">				<h4 class="card-title">������ ����� ��������</h4>							</div><section id="minimal-statistics">
<?php
if(USER_LOGGED){

$can_post=0;
if($reviews_c==1){
$roq=mysql_query("SELECT oid FROM operations WHERE ologin='$u_login' LIMIT 1");
if(mysql_num_rows($roq)>0){
$can_post=1;
}
}
else{
$can_post=1;
}

if($u_login=='Avenger' or $u_login =='serezhka1997'){
$can_post=1;
}

// ��Ȩ� ������

if($can_post==1 && !empty($_POST['review']) && $d_reviews_mode!=2 && $_SESSION['can_review']>$time){
echo '<div class="alert alert-dismissable alert-danger">
                                 <center>��������� ����� ����� �������� �����<strong>'.($_SESSION['can_review']-$time).' ������</strong></center>
                              </div>';
}
if($can_post==1 && !empty($_POST['review']) && $d_reviews_mode!=2 && $_SESSION['can_review']<$time){
$_SESSION['can_review']=$time+$reviews_t;
$review=$_POST['review'];
$review=str_replace("\r\n", ' ',$review);
$review=str_replace("\n", ' ',$review);
$review=preg_replace('#[^a-zA-Z�-��-���\ \!\-\_\%\@\#\$\:\;\.\,\?\=\<\>\+\(\)\{\}\[\]\'\"\*0-9\/]+#m','',$review);
$review=str_replace('<', '&lt;',$review);
$review=str_replace('>', '&gt;',$review);
$review=str_replace("'",'&quot;',$review);
$review=str_replace('"','&quot;',$review);
$review=preg_replace('# +#',' ',$review);
$review=trim($review);
$review=substr($review,0,499);
if(strlen($review)>5){
$rfq=mysql_query("SELECT rid FROM reviews WHERE rlogin='".$u_login."' AND rpost='".$review."'");
if(mysql_num_rows($rfq)==0){
mysql_query("INSERT INTO reviews (rlogin,rpost,rdate,rcan) VALUES ('$u_login','$review','$time','$d_reviews_mode')");
if($d_reviews_mode!=1){
mysql_query("UPDATE data SET reviews_count=(SELECT COUNT(rid) FROM reviews WHERE rcan!=1)");
}
$review_show=0;
}
}
}

}

//  ��������� �������

$r_links='';
$sc_f=1;
if(isset($_GET['pn'])){
$_GET['pn']=preg_replace('#[^0-9]+#','',$_GET['pn']);
$_GET['pn']=preg_replace('#^[0]+#','',$_GET['pn']);
if($_GET['pn']>0 && $_GET['pn']<2000){
$sc_f=$_GET['pn'];
}
}
$reviewsq=mysql_query("SELECT * FROM reviews WHERE rcan!=1");
$sc_lim=(mysql_num_rows($reviewsq))/$reviews_pp;
if($sc_lim>1){
for($n=0;$n<$sc_lim;$n++){
if($sc_f==($n+1)){ $r_links.='<a class="page-numbers" style="
    background-color: #f1f5fd;
    border-top: 0;
    border-bottom: 0;
    color: #7a88a1;
">'.($n+1).'</a> &nbsp;'; }
else{ $r_links.='<a class="page-numbers" href="/?page=reviews_cab&pn='.($n+1).'">'.($n+1).'</a> &nbsp;'; }
}
}

?>
<?php
if($d_reviews_mode!=2){

if(!USER_LOGGED){ echo '<center><p class="bg-danger logged-out col-md-12" id="sign-in-or-register" style="
    padding: 21px 10px 20px 10px;
    color: #FFF;
    background-color: #820030;
    font-weight: bold;
    border-radius: 7px;
    font-size: 17px;
">��������� ������ ����� ������ �������������� ������������</p></center><br><br><br>'; }

if(USER_LOGGED && $can_post==0){ echo '<center>
<div class="alert alert-dismissable alert-danger">
                                 <button type="button" class="close" data-dismiss="alert">X</button>
                                 <strong>����� �������� �����,</strong> � ��� ������ ���� ���� �� ���� ��������</div></center>'; }

if(USER_LOGGED && $can_post==1){
?>
<ul class="page-numbers">
<?php if(isset($review_show) && $d_reviews_mode==1){
  echo '
  <div class="alert alert-amber alert-dismissible mb-2" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">x</span>
                                    </button>
                                    <h4 class="alert-heading mb-2">��� ����� ��� ��������� �� ��������!</h4>
                                    <p>�� � ����������� ����� ������ ������, ������� �� ��� �����, ���� ������ ����� ��� ���! </p>
									<p>��� ����� ����� �������� ����� ��������� ������������ ������� AXPREO</p>
                                </div>'; } ?>
                  
<?php if(isset($review_show) && $d_reviews_mode==0){ echo '

<div class="alert alert-success border-0 alert-dismissible mb-2" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">x</span>
                                    </button>
                                    <h4 class="alert-heading mb-2">��� ����� ������� ��������!</h4>
                                   <p class="mb-0">�� � ����������� ����� ������ ������, ������� �� ��� �����, ���� ������ ����� ��� ���! </p>
                                </div>
'; }
?>
</ul><br>

<form id="reviews_form" style="margin:0;padding:0" action="/?page=reviews_cab" method="POST">	<div class="col-xl-12 col-lg-8 col-md-8">		                                <fieldset class="form-group">		                                    <label for="basicTextarea">���������� ����� ������� � ������� </label>		                                    <textarea class="form-control" id="reviews_textarea" name="review"  style="margin-top: 0px; margin-bottom: 0px; height: 78px;" placeholder="����� �� ����� 5 ��������" maxlength="500"></textarea>		                                </fieldset>                                		                            
<a class="btn btn-raised btn-success btn-min-width mr-1 mb-1" href="javascript:with(document.getElementById('reviews_form')){ submit(); }">�������� ���� �����</a>
<div style="clear:both;"></div></div>
</form>

<?php
}
}
else{
echo '<div class="reviews_offed">������� ���������� ������� ��������������</div>';
}
?>
<?php
if(!empty($_GET['pn'])){
$r_start=preg_replace('#[^0-9]+#','',$_GET['pn']);
$r_start=preg_replace('#^[0]+#','',$r_start);
if($r_start>1 && $r_start<2000){
$r_start=$r_start*$reviews_pp-$reviews_pp;
$reviewsq=mysql_query("SELECT rlogin,rdate,rpost FROM reviews WHERE rcan!=1 ORDER BY rdate DESC LIMIT $r_start,$reviews_pp");
if(mysql_num_rows($reviewsq)==0){
$reviewsq=mysql_query("SELECT rlogin,rdate,rpost FROM reviews WHERE rcan!=1 ORDER BY rdate DESC LIMIT $reviews_pp");
}
}
else {
$reviewsq=mysql_query("SELECT rlogin,rdate,rpost FROM reviews WHERE rcan!=1 ORDER BY rdate DESC LIMIT $reviews_pp");
}
}
else{
$reviewsq=mysql_query("SELECT rlogin,rdate,rpost FROM reviews WHERE rcan!=1 ORDER BY rdate DESC LIMIT $reviews_pp");
}
while($reviewsm=mysql_fetch_row($reviewsq)){ 
// ������ �� ������
$get_avatar_img  = "SELECT `avatar` FROM `users` WHERE `login` = '" . trim( $reviewsm[0] ) . "'";
$get_avatar_img = mysql_query( $get_avatar_img ); 
$get_avatar_img = mysql_fetch_row( $get_avatar_img );
$get_avatar_img = $get_avatar_img[0];
?>

                  <div class="row">	<div class="col-sm-12">	<div class="card" style="    box-shadow: 0 6px 0 0 rgba(0, 0, 0, 0.01), 0 15px 32px 0 rgba(0, 0, 0, 0.06);    border: 0;    margin: 18px 0;"><section id="minimal-statistics">
        <div id="headingCollapse2" class="card-header p-0">
          <a data-toggle="collapse" href="#collapse2" aria-expanded="true" aria-controls="collapse2" class="email-app-sender list-group-item list-group-item-action no-border">
            <div class="media">
              <span class="avatar avatar-md mr-2">
                <?php if( trim( $get_avatar_img ) == '' ) { ?>
                  <img src="/app-assets/img/portrait/avatars/avatar-08.png" class="media-object rounded-circle width-50" >
                <?php } else { ?>                                                                  
                  <img src="images/avatars/<?php echo trim( $get_avatar_img );?>" class="media-object rounded-circle width-50">
                <?php } ?>     
              </span>                                
              <div class="media-body">
                <h6 class="list-group-item-heading"><?php echo $reviewsm[0]; ?></h6>
                <p class="list-group-item-text">
                  <span><?php $rew=$reviewsm[2];echo $rew;?></span>
                  <span class="float-right"><?php echo date('j ',$reviewsm[1]).$mdate[date('n',$reviewsm[1])-1].date(' H:i',$reviewsm[1]); ?></span>
                </p>
              </div>
            </div>
          </a>
        </div>		</section>				</div></div></div>
<?php } ?></div>
<center><ul class="page-numbers"><?php if(!empty($r_links)){ echo '  <a class="page-numbers">'.$r_links.'</a>'; } ?></ul></center>
</section>		</div></div></div></div>     <style>
.text-links_content a {
    background: #e3f0f7 none repeat scroll 0 0;
    border: 1px solid rgba(255,255,255,.4);
    border-radius: 3px;
    display: inline-block;
    line-height: 10px;
    margin: 2px;
    padding: 8px;
    text-decoration: none;
      color: #000;
}

.text-links_content a:hover {
    background: #ecf2ff none repeat scroll 0 0;
    border: 1px solid rgb(202, 213, 237);
    color: #305069;
}
.l-landings .text-links .text-links_content a:hover {
    color: #000;
}
.l-landings .text-links .text-links_content a {
    color: #305069;
}
  </style>
</div>
</div>
        <footer class="footer footer-static footer-light">
          <p class="clearfix text-muted text-sm-center px-2"><span>Copyright  &copy; 2018 AXPREO.COM, All rights reserved. </span></p>
        </footer>
</div>
</div>
    <script src="app-assets/vendors/js/core/jquery-3.2.1.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/core/popper.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/core/bootstrap.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/perfect-scrollbar.jquery.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/prism.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/jquery.matchHeight-min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/screenfull.min.js" type="text/javascript"></script>
    <script src="app-assets/vendors/js/pace/pace.min.js" type="text/javascript"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="app-assets/vendors/js/chartist.min.js" type="text/javascript"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN APEX JS-->
    <script src="app-assets/js/app-sidebar.js" type="text/javascript"></script>
    <script src="app-assets/js/notification-sidebar.js" type="text/javascript"></script>
    <script src="app-assets/js/customizer.js" type="text/javascript"></script>
    <!-- END APEX JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <script src="app-assets/js/dashboard1.js" type="text/javascript"></script>
    <script type="text/javascript" src="js/ajax.js"></script>
	<!-- BEGIN JIVOSITE CODE {literal} -->
<script type='text/javascript'>
(function(){ var widget_id = 'n790DI644T';var d=document;var w=window;function l(){
var s = document.createElement('script'); s.type = 'text/javascript'; s.async = true; s.src = '//code.jivosite.com/script/widget/'+widget_id; var ss = document.getElementsByTagName('script')[0]; ss.parentNode.insertBefore(s, ss);}if(d.readyState=='complete'){l();}else{if(w.attachEvent){w.attachEvent('onload',l);}else{w.addEventListener('load',l,false);}}})();</script>
<!-- {/literal} END JIVOSITE CODE -->
</body>
</html>