 <?php
$b_plus_q=0;
$b_plus_b=0;
$b_withed=0;
$b_pended=0;
$b_refsum=0;
$b_refback=0;
$b_refs=0;
$b_activ=0;
$b_earned=0;
$b_acta=0;
$b_tot=0;
$b_otn=0;
$b_refbonus=0;

$reflist=array();

$depbtq=mysql_query("SELECT ologin,otype,osum,osum2,odate,odate2,operiod,oparts,ohours,opproc,oprofit,orefsum,orefback,obatch FROM operations WHERE (ologin='$u_login' AND osum>0 AND oback='') OR (oref='$u_login' AND osum>0  AND oback='')");
while($depbtm=mysql_fetch_row($depbtq)){

if($depbtm[0]!=$u_login && $depbtm[1]==3 && $depbtm[13]!=''){
if(!in_array($depbtm[0],$reflist)){
$b_refs++;
$reflist[]=$depbtm[0];
}
$b_refsum+=$depbtm[11];
}

if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[13]!=''){ $b_plus_q+=$depbtm[3]; $b_refback+=$depbtm[12]; }
if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[13]==''){ $b_plus_b+=$depbtm[3]; }

if($depbtm[0]==$u_login && $depbtm[1]==2 && $depbtm[5]!=''){ $b_withed+=$depbtm[2]; }
if($depbtm[0]==$u_login && $depbtm[1]==2 && $depbtm[5]==''){ $b_pended+=$depbtm[2]; }

if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[4]>$time){
$b_activ+=$depbtm[3];
$b_acta++;
$b_col=floor(($time-$depbtm[5])/($depbtm[6]*3600));
$b_earned+=$b_col*$depbtm[10];
}

if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[4]<=$time){
$b_earned+=$depbtm[2];
$b_otn+=$depbtm[3];
}

}


$b_tot=$b_refsum+$b_refback+$b_plus_q+$b_earned-$b_otn-$b_withed-$b_pended-$b_activ;

$b_tot=number_format($b_tot,2,'.','');

if(!empty($d_refbonus)){
foreach($d_refbonus as $rbon){
if($b_refs>=$rbon[0] && $b_refs<=$rbon[1]){
$b_refbonus=$rbon[2];
}
}
}

if($d_vklad==0){
// ====================================== �������� ����������� ==========================================

  if($b_tot<0) { echo "Balance error!!! $b_tot"; exit; }

  if(!empty($_POST['sum']) && !empty($_POST['payment_type'])){

  $depo=$_POST['sum'];
  $depo=preg_replace("#[^0-9\.]+#",'',$depo);
  $depo=preg_replace("#\.+#",'.',$depo);
  $payment_type=$_POST['payment_type'];

  if(empty($depo)){ $depo=0; }


  if(!is_numeric($depo)){ $d_e='<div class="alert bg-danger alert-dismissible mb-2" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">x</span>
                                    </button>
                                  <center> ������� ���������� �����.</center>
                                </div>'; }
  $depo=number_format($depo,2,'.','');
  if($b_acta>$d_acts-1){ $d_e='��������� �� ����� '.$d_acts.'��������� �������.'; }
  if(empty($d_e) && $depo<10){ $d_e='<div class="alert bg-danger alert-dismissible mb-2" role="alert">
                                    <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                        <span aria-hidden="true">x</span>
                                    </button>
                                  <center> ����������� ����� ������ '.$d_min.' ������</center>
                                </div>
								.'; }
  if(empty($d_e) && ($b_activ+$depo)>$d_max){ $d_e='����� ������������ ������� �� ������ ����������'.$d_max.' ������.'; }

  if ($_POST['payment_type'] == 'qiwi' && empty($d_e)) {
      require 'cabinet/payment_pages/qiwi.php';
      exit;
  }
  if ($_POST['payment_type'] == 'card' && empty($d_e)) {
      require 'cabinet/payment_pages/card.php';
      exit;
  }
  if ($_POST['payment_type'] == 'yandex' && empty($d_e)) {
      require 'cabinet/payment_pages/yandex.php';
      exit;
  }
  if ($_POST['payment_type'] == 'payeer' && empty($d_e)) {
      require 'cabinet/payment_pages/payeer.php';
      exit;
  }
  if ($_POST['payment_type'] == 'wm' && empty($d_e)) {
      require 'cabinet/payment_pages/perfect.php';
      exit;
  }
  if ($_POST['payment_type'] == 'reinvest' && empty($d_e)) {
    if(empty($d_e) && $depo>$b_tot){ $d_e='�� ����� ������� ������������ ������� ��� ������.'; }
  }


  if(empty($d_e)){

  $odate=$time+3600*$plan[$plan_id][1];
  $operiod=$plan[$plan_id][0];
  $oparts=$plan[$plan_id][1]/$plan[$plan_id][0];
  $ohours=$plan[$plan_id][1];
  $oproc=$plan[$plan_id][2];
  $opproc=str_replace('.00','',number_format($oproc/$oparts,2,'.',''));
  $oprofit=$depo*($opproc/100);

  $sum=number_format($depo*($oproc/100),2,'.','');


  mysql_query("INSERT INTO operations (ologin,otype,osum,osum2,odate,odate2,oplan,operiod,oparts,ohours,opproc,oproc,oprofit) VALUES ('$u_login','3','$sum','$depo','$odate','$time','$plan_id','$operiod','$oparts','$ohours','$opproc','$oproc','$oprofit')") or die('inserting batch data error');

  $b_tot-=$depo;
  $b_activ+=$depo;

  // ���������� ����� ��������� � ������ �������

  $resumq=mysql_query("SELECT SUM(osum2) FROM operations WHERE otype=3 AND osum2>0 AND obatch='' AND oback=''");
  $resumm=mysql_fetch_row($resumq);

  mysql_query("UPDATE data SET reinvest='$resumm[0]'") or die('cant insert reinvest sum');

  if($reinv_inc==1){
  $invreq=mysql_query("SELECT ologin,osum2 FROM operations WHERE otype=3 AND osum2>0 AND oback='' ORDER BY odate2 DESC LIMIT 10");
  $invren='';
  while($invrem=mysql_fetch_row($invreq)){
  $invrez=$reinv_s;
  $invrez=str_replace('#LOGIN#',$invrem[0],$invrez);
  $invrez=str_replace('#SUM#',$invrem[1],$invrez);
  $invren.=$invrez;
  }
  mysql_query("UPDATE data SET plus_n='$invren'") or die(mysql_error());
  }


// �����


}

}

}

if($u_ref!=''){
$rq=mysql_query("SELECT refback FROM users WHERE login='$u_ref'");
if(mysql_num_rows($rq)==0){ die('refback not found'); }
$rm=mysql_fetch_row($rq);
$orefrbp=$rm[0];
}

?>

<?php


include $_SERVER['DOCUMENT_ROOT']."/head_cab.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>







        <div id="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">


              <?php


include $_SERVER['DOCUMENT_ROOT']."/menu.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>
                      <div class="holder-content">
                            <style>
    .d-default-form {
        padding: 0!important;
    }
</style>
<ul class="bread-crumbs">
    <li><a href="#">�������</a></li>
    <li><a href="#">�������</a></li>
    <li>����� �������</li>
</ul>
<div class="invoice-error"></div>

<style>
    .dropdown_custom_wrap select {
        font-weight: 500;
        font-size: 15px;
        line-height: 45px;
        color: #3c3c3c;
        width: 100%;
        border: solid 1px rgba(143, 143, 158, 0.3);
        position: relative;
        background: transparent;
        cursor: pointer;
        display: block;
        height: 45px;
        margin: 0;
        overflow: hidden;
        padding: 0 28px 0 13px;
        text-align: left;
        text-overflow: clip;
        z-index: 2;
        border-radius: 4px;
        -webkit-border-radius: 4px;
        -moz-border-radius: 4px;
        background: #fff;
    }

    .d-requisites-holder__check-row {
        margin-top: -5px;
    }

    button#fs-dropdown__1-dropdown-selected {
        background: #fff;
    }

    button#invoices-currency-dropdown-selected {
        background: #fff;
    }

    input.form-control {
        font-weight: 500;
        font-size: 15px;
        line-height: 45px;
        color: #3c3c3c;
        width: 100%;
        border: solid 1px rgba(143, 143, 158, 0.3);
        position: relative;
        background: transparent;
        cursor: pointer;
        display: block;
        height: 45px;
        margin: 0;
        overflow: hidden;
        padding: 0 28px 0 13px;
        text-align: left;
        text-overflow: clip;
        z-index: 2;
        border-radius: 4px;
        -webkit-border-radius: 4px;
        -moz-border-radius: 4px;
        background: #fff;
    }

    button#invoices-type-dropdown-selected {
        display: block;
        position: absolute;
        top: 0;
    }
</style>

<div class="group-content">
    <section id="content">
<?php
if($d_vyvod!=0){
echo '<div class="withdrawal_error"><div class="alert alert-dismissable alert-danger">
									 <button type="button" class="close" data-dismiss="alert">x</button>
									<h3>������!</h3> ����� �������� �� �������� �������� ����������� ������!
								  </div></div>';
}
else{
 
}
?>
<?php
if(!empty($w_e)){ echo '<div class="withdrawal_error">'.$w_e.'</div>'; }
if(!empty($w_s)){ echo '<div class="deposits_can"><div class="bs-example">
                        <div class="alert alert-dismissable alert-warning" style="color: #34322e;background-color: #daffec;border-color: #89d8ac;">
                                    <button type="button" class="close" data-dismiss="alert">x</button>
                                    <h4 style="
">������ �� ����� '.$sum.' ������ ������� � ���������!</h4>
                                    <p>�������� ������ ������� � ������� 5 �����.������� �� ��������� ���������!</p>
                                 </div>
                              </div></div>'; }
?>
 <?php if($d_vyvod==0){ ?>
	
       	 <form id="withdrawal" method="POST" onsubmit="return false" class="d-default-form form">
	 
 
       <fieldset>
            <div class="d-settings__holder __no-margin">
                <div class="d-settings__holder-title __no-margin">
                    <h3>����� ������� � ������� �����</h3>
                </div>
            </div>
            <div class="d-requisites-holder">
                
                <!--                <div class="d-requisites-holder__check-row">-->
                <!--                    <ul class="list-check">-->
                <!--                        -->                <!--                    </ul>-->
                <!--                </div>-->
                <div class="d-requisites-holder__inner-row">


                    <div class="d-requisites-holder__inner-row__select-box">

                       
                            <span class="default-form__descr_text style2">��������� �������:</span>
							<div class="fs-dropdown fs-light" id="invoices-type-dropdown" tabindex="0" role="listbox" aria-haspopup="true" aria-live="polite" aria-labeledby="invoices-type-dropdown-selected">

 


                        	<select id="payment_type" class="dropdown fs-dropdown-element type_payments" name="type_payments" aria-required="true" required="" tabindex="-1">
 <option value="yandex">������.������</option>
                <option value="payeer">Payeer</option>
                <option value="qiwi">Qiwi Wallet</option>
                <option value="wm">PerfectMoney</option> 
</select>
                         </div>
                    </div>

                    <div class="d-requisites-holder__inner-row__select-box">
                        <div class="form-group field-invoices-name required">

<div class="help-block"></div>
</div>                        <div id="invoices-props">    <!--    <div class="form-group">-->
        <span class="default-form__descr_text style2" for="prop3">�����:</span>
		 
		
		
		
    <input id="withdrawal_input" name="sum" required="" type="text" class="d-default-form__form-control withdrawal_input">
	<input name="type" type="hidden" value="withdrawal">
<!--    </div>-->
 
 </div>
                    </div>

                    <div class="d-requisites-holder__inner-row__btn-box">
					
					 <a onclick="send('withdrawal')" class="d-default-form__btn green btn-green">������� ��������</a>
				 
                                        </div>

                </div>
            </div>
</fieldset></form>
<?php }  ?>

</section></div> 

<div class="d-settings__holder">
    <div class="d-table-holder requisites">
        <div class="grid-view">
		<table class="d-default-table">
		<thead>
<tr>
   <th>���</th>
                                    <th>����</th>
                                    <th>������</th>
									<th>�������</th>
									  <th>�����</th>
									<th>����� ������</th>
</tr>
</thead>

 
                             
                       
			

<?php
$statsq=mysql_query("SELECT osum,odate,odate2,obatch,o_type FROM operations WHERE otype=2 AND ologin='$u_login' ORDER BY odate DESC");
while($statsm=mysql_fetch_row($statsq)){ ?>


<tbody>
                                  <tr>
<?php
if($statsm[2]==''){ echo '<td >  �����</td>'; }
else{ echo '<td > �����</td>'; }                                                            

?>

 
                                    
														
														
               <td><?php echo date('j '.$mdate[date('n',$statsm[1])-1].' H:i',$statsm[1]); ?></td>
<?php
if($statsm[2]==''){ echo '<td>��������</td>'; }
else{ echo '<td>�������</td>'; }
 $type_transaction=$statsm[4];                                                               
if($type_transaction == 'qiwi') { $media_payment = '/ico/qiwi.png'; }
    else {
        if ($type_transaction == 'wm') {
            $media_payment = '/ico/perfect.png';
        }
        else {
            if ($type_transaction == 'yandex') {
                $media_payment = '/ico/yandex.png';
            }
            else {
                if ($type_transaction == 'payeer') {
                    $media_payment = '/ico/payeer.png';
                }
                else {
                   if ($type_transaction == 'card') {
                        $media_payment = '/ico/visam.png';
                   }
                   else {
                        $media_payment = '����������';
                        }
                    }
                   }                    
            }
       } ?>
								
								
								
                            <td>
                                   <img alt="" src="<?php echo $media_payment; ?>" style="width: 47%;">
                                </td>
							<td>- <?php echo str_replace('.00','',number_format($statsm[0],2,'.',',')); ?> RUB</td>
                                <td><?php echo $statsm[3]; ?></td>
                      
                            </tr>
</tbody>

    
            
                <?php } ?>

</table>

</div>    </div>
</div>


 
</div>
                    </div>
                </div>
            </div>
        </div>
		

<?php


include $_SERVER['DOCUMENT_ROOT']."/cab_footer.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>