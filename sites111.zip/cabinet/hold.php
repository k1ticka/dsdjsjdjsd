    <?php
$b_plus_q=0;
$b_plus_b=0;
$b_withed=0;
$b_pended=0;
$b_refsum=0;
$b_refback=0;
$b_refs=0;
$b_activ=0;
$b_earned=0;
$b_acta=0;
$b_tot=0;
$b_otn=0;
$b_refbonus=0;

$reflist=array();

$depbtq=mysql_query("SELECT ologin,otype,osum,osum2,odate,odate2,operiod,oparts,ohours,opproc,oprofit,orefsum,orefback,obatch FROM operations WHERE (ologin='$u_login' AND osum>0 AND oback='') OR (oref='$u_login' AND osum>0  AND oback='')");
while($depbtm=mysql_fetch_row($depbtq)){

if($depbtm[0]!=$u_login && $depbtm[1]==3 && $depbtm[13]!=''){
if(!in_array($depbtm[0],$reflist)){
$b_refs++;
$reflist[]=$depbtm[0];
}
$b_refsum+=$depbtm[11];
}

if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[13]!=''){ $b_plus_q+=$depbtm[3]; $b_refback+=$depbtm[12]; }
if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[13]==''){ $b_plus_b+=$depbtm[3]; }

if($depbtm[0]==$u_login && $depbtm[1]==2 && $depbtm[5]!=''){ $b_withed+=$depbtm[2]; }
if($depbtm[0]==$u_login && $depbtm[1]==2 && $depbtm[5]==''){ $b_pended+=$depbtm[2]; }

if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[4]>$time){
$b_activ+=$depbtm[3];
$b_acta++;
$b_col=floor(($time-$depbtm[5])/($depbtm[6]*3600));
$b_earned+=$b_col*$depbtm[10];
}

if($depbtm[0]==$u_login && $depbtm[1]==3 && $depbtm[4]<=$time){
$b_earned+=$depbtm[2];
$b_otn+=$depbtm[3];
}

}


$b_tot=$b_refsum+$b_refback+$b_plus_q+$b_earned-$b_otn-$b_withed-$b_pended-$b_activ;

$b_tot=number_format($b_tot,2,'.','');

if(!empty($d_refbonus)){
foreach($d_refbonus as $rbon){
if($b_refs>=$rbon[0] && $b_refs<=$rbon[1]){
$b_refbonus=$rbon[2];
}
}
}

if($d_vklad==0){

// ====================================== �������� ����������� ==========================================

if($b_tot<0) { echo "Balance error!!! $b_tot"; exit; }

if(isset($_POST['depo']) && !empty($plan[$_POST['plan']])){

$depo=$_POST['depo'];
$depo=preg_replace("#[^0-9\.]+#",'',$depo);
$depo=preg_replace("#\.+#",'.',$depo);
$plan_id=$_POST['plan'];

if(empty($depo)){ $depo=0; }

$depo=number_format($depo,2,'.','');

if(!is_numeric($depo)){ $d_e='
                                    <strong>��������!</strong>  ������� ���������� �����
                              
								
 

							  
							  
							  
							  '; }
if($b_acta>$d_acts-1){ $d_e=' 
                                    <strong>��������!</strong>  ��������� �� ����� <strong>'.$d_acts.'</strong>��������� �������
                              
							  
							 
							  
							  '; }
if(empty($d_e) && $depo<$d_min){ $d_e='

                                    <strong>��������!</strong>  ����������� ����� ������ <strong>'.$d_min.'</strong> ������
                              

							    
							  
							  '; }
if(empty($d_e) && $depo>$b_tot){ $d_e='

                                    <strong>��������!</strong>  �� ����� ������� ������������ ������� ��� ������
                              

							  
							  '; }
if(empty($d_e) && ($b_activ+$depo)>$d_max){ $d_e='

							
                                    <strong>��������!</strong>  ����� ������������ ������� �� ������ ���������� <strong>'.$d_max.'</strong> ������
                            
 
							  '; }

if(empty($d_e)){

$odate=$time+3600*$plan[$plan_id][1];
$operiod=$plan[$plan_id][0];
$oparts=$plan[$plan_id][1]/$plan[$plan_id][0];
$ohours=$plan[$plan_id][1];
$oproc=$plan[$plan_id][2];
$opproc=str_replace('.00','',number_format($oproc/$oparts,2,'.',''));
$oprofit=$depo*($opproc/100);

$sum=number_format($depo*($oproc/100),2,'.','');


mysql_query("INSERT INTO operations (ologin,otype,osum,osum2,odate,odate2,oplan,operiod,oparts,ohours,opproc,oproc,oprofit,out_type) VALUES ('$u_login','3','$sum','$depo','$odate','$time','$plan_id','$operiod','$oparts','$ohours','$opproc','$oproc','$oprofit','reinvestin')") or die('inserting batch data error');

$b_tot-=$depo;
$b_activ+=$depo;

// ���������� ����� ��������� � ������ �������

$resumq=mysql_query("SELECT SUM(osum2) FROM operations WHERE otype=3 AND osum2>0 AND obatch='' AND oback=''");
$resumm=mysql_fetch_row($resumq);

mysql_query("UPDATE data SET reinvest='$resumm[0]'") or die('cant insert reinvest sum');

if($reinv_inc==1){
$invreq=mysql_query("SELECT ologin,osum2 FROM operations WHERE otype=3 AND osum2>0 AND oback='' ORDER BY odate2 DESC LIMIT 10");
$invren='';
while($invrem=mysql_fetch_row($invreq)){
$invrez=$reinv_s;
$invrez=str_replace('#LOGIN#',$invrem[0],$invrez);
$invrez=str_replace('#SUM#',$invrem[1],$invrez);
$invren.=$invrez;
}
mysql_query("UPDATE data SET plus_n='$invren'") or die(mysql_error());
}


// �����


}

}

}

if($u_ref!=''){
$rq=mysql_query("SELECT refback FROM users WHERE login='$u_ref'");
if(mysql_num_rows($rq)==0){ die('refback not found'); }
$rm=mysql_fetch_row($rq);
$orefrbp=$rm[0];
}

?>

<?php


include $_SERVER['DOCUMENT_ROOT']."/head_cab.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>



        <div id="main">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">


              <?php


include $_SERVER['DOCUMENT_ROOT']."/menu.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>
                        <div class="holder-content">
                            <style>
    .holder-img {
        object-fit: cover;
        width: 240px;
        height: 108px;
    }
    img {
        object-fit: cover;
    }
    span.method {
        height: 50px;
        overflow: hidden;
    }





    /*.offerings {*/
    /*overflow: hidden;*/
    /*background: #ffffff;*/
    /*box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.08);*/
    /*}*/
    .offerings .list {
        margin: 0 0 20px;
        background: #ffffff;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.08);
    }
    .list {
        position: relative;
        display: block;
        overflow: hidden;
        margin: 0;
        padding: 0;
    }
    .slider-offerings .slide {
        padding-top: 15px;
    }
    .initialized .slide {
        display: block;
        margin-top: 20px;
    }
    .slide {
        float: left;
        height: 100%;
        min-height: 1px;
    }
</style>
<ul class="bread-crumbs">
    <li>�������</li>
</ul>
<div class="group-content">
    <aside id="sidebar">
        <div class="offerings">
            <div class="holder-offerings">
                <h3 class="title-border">��������� ������</h3>
            </div>
            <div class="slider-offerings">

<?php 

$q = mysql_query( "SELECT ologin, osum, osum2, out_type, odate2  FROM `operations` WHERE odate2>0 and osum>0 and otype=3 ORDER BY oid DESC LIMIT 5;" );

$news = array();
while( $row = mysql_fetch_assoc( $q ) ){
    $news[] = $row;
}
if ( $news )
    {
        foreach( $news as $news_value )
            {
                $type_transaction = $news_value['out_type'];

                ?>	
				
				<div>
    <div class="holder-img">
       <center> <img src="/images/noavatar.png" alt="img" style="  max-width: 44%;  border-radius: 50%;"></center>
    </div>
    <div class="holder-text">
        <h3><?php echo $news_value['ologin']; ?></h3>
        <span class="method"><center><?php    if ($type_transaction == 'qiwi') {
       echo "<img src='/ico/qiwi.png' style='max-width: 35%;'>";
   }
   else {
        if ($type_transaction == 'wm') {
            echo "<img src='/ico/perfect.png'>";
        }
        else {
            if ($type_transaction == 'yandex') {
                echo "<img src='/ico/yandex.png' style='max-width: 35%;'>";
            }
            else {
                if ($type_transaction == 'payeer') {
                    echo "<img src='/ico/payeer.png'>";
                }
                else {
                   if ($type_transaction == 'advcash') {
                       echo "<img src='/icon/advcash.png' style='max-width: 35%;'>";
                   }
                   else {
                       if ($type_transaction == 'card') {
                            echo "<img src='/ico/visam.png' style='max-width: 35%;'>";
                       }
                       else {
                            if ($type_transaction == 'bitcoin') {
                                echo "<img src='/icon/btc.png' style='max-width: 35%;'>";
                            }
                            else {
                                if ($type_transaction == 'reinvestin') {
                                    echo "<img src='/icon/revest.png' style='max-width: 35%;'>";
                                }
                                else
                                    echo "����������";
                            }
                        }
                   }                    
                }
            }
        }
    } ?></center></span>
        <span class="payments">�����:
            <span><?php echo $news_value['osum2']; ?> <i class="fa fa-rouble"></i>
                                                </span>
        </span>
        <a class="btn-green" href="/?p=add">������� �����</a>
    </div>
</div>
				
				
				
   	  <?php } } else { ?>

                            <div class="row">
                            <div class="container">
   <div class="alert alert-danger col-md-offset-12 col-md-12" style="color: #b575a7;background-color: #ffe5f8;border-color: #efb7e3;text-align: -webkit-center;">���������� ��� ������ �����������.</div>
            </div>
            </div>
            
                <?php } ?>
					 


                


           </div>
        </div>

<!--        <div class="offerings">-->
<!--            <div class="holder-offerings">-->
<!--                <h3 class="title-border" style="font-size: 18px;">���������� �������!</h3>-->
<!--            </div>-->
<!--            <div class="offerings initialized" role="toolbar">-->
<!---->
<!--                <div aria-live="polite" class="list draggable">-->
<!--                    <div class="slide cloned" data-slick-index="-1" aria-hidden="true" tabindex="-1"-->
<!--                         style="width: 270px;">-->
<!--                        <div class="holder-img">-->
<!--                            <img src="/webmaster/images/may.jpg"-->
<!--                                 alt="img">-->
<!--                        </div>-->
<!--                        <div class="holder-text">-->
<!--                            <span style="font-weight: 700;font-size: 15px;">-->
<!--                                ����� � 1 �� 10 ��� � �������� �������������� ������� �� ������ ������-->
<!--                            </span>-->
<!--                            <span style="height: 10px;display: block;"></span>-->
<!--                            <span class="payments">-->
<!--            <span> +25<i class="fa fa-rouble"></i> </span>-->
<!--            <span> +50<i class="fa fa-rouble"></i> </span>-->
<!--            <span> +100<i class="fa fa-rouble"></i> </span>-->
<!--        </span>-->
<!--                            <a class="btn-green" href="/webmaster/support/news-view?id=172" tabindex="-1" target="_blank">���������</a>-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--            </div>-->
<!--        </div>-->





        <div class="promo-aside">
            <script type="text/javascript" src="//vk.com/js/api/openapi.js?152"></script>

            <!-- VK Widget -->
            <div id="vk_groups"></div>
            <script type="text/javascript">
                VK.Widgets.Group("vk_groups", {mode: 3, no_cover: 1, width: "270"}, 63028191);
            </script>
        </div>
    </aside>
<section id="content">

        <div class="holder-white holder-search">
            <div class="indentation">
                <h3>���������������� �������</h3>
            </div>
             
        </div>
        <div id="w0" class="list-view"><div data-key="346">
<div class="holder-white">
  <?php if($d_vklad==0){

$can_dep='��������� ����� ����� ��������������';
if(($d_max-$b_activ)>=$d_min){
$can_dep='
<div class="grey-fon" style="
    background-color: #ffd7d7;
    padding: 10px 30px 10px;
">
        <p></p><p style="color: #9e0000 !important;font-weight: 500;">����� �������������� �������� �� '.$d_min.' ������ �� '.($d_max-$b_activ).' ������</p><p></p>    </div>

';
$canmd=1;
}
?>



<?php if($d_vklad!=0){ ?>
<div class="grey-fon" style="
    background-color: #ffd7d7;
    padding: 10px 30px 10px;
">
        <p></p><p style="color: #9e0000 !important;font-weight: 500;">�������� ������� �������� ���������������</p><p></p>    </div>
<?php } ?>

<?php if(!empty($canmd)){ ?>



		
		
		 <?php if(!empty($d_e)){ echo '<div class="grey-fon" style="
    background-color: #ffd7d7;
    padding: 10px 30px 10px;
">
        <p></p><p style="color: #9e0000 !important;font-weight: 500;">'.$d_e.'</p><p></p>    </div>';} ?>
    <div class="offers">
        <div class="indentation">
            <div class="holder-control">
            
				<form id="deposits_form" action="/?p=hold" method="post" class="form">

 
							<div class="col-md-12 col-12"><div class="form-body">
								
								<div class="row">
									<div class="col-md-4">
										<div class="form-group">
											<label for="projectinput1">����� ������</label>
											<input class="d-default-form__form-control" id="deposits_sum" onkeyup="dep_calc();" name="depo" type="text"  autocomplete="off">
										</div>
									</div>
									<div class="col-md-4">
										<div class="form-group">
											<label for="projectinput2">��������</label>
											<input class="d-default-form__form-control" type="text" id="deposits_out" autocomplete="off">
										</div>
									</div>
										<script type="text/javascript">
var plan=new Array();
<?php
foreach($plan as $pa1=>$pa2){
echo 'plan['.$pa1.']='.$pa2[2].';';
}
?>
</script>
<select id="deposits_plan" name="plan" onchange="dep_calc();" style="
 margin-left: 5px;
 padding: 11px 6px;
 padding-top: 7px;
 border-radius: 2px;
 display: none;
">
<?php
foreach($plan as $pa1=>$pa2){
echo '<option value="'.$pa1.'">'.$pa2[2].'% '.$pname[$pa2[1]].'</option>';
}
?>
</select>
              <div class="col-md-4">
              <div class="form-group">
              <label for="projectinput2">��������</label>
              <a href="javascript:with(document.getElementById('deposits_form')){ submit(); }" class="btn btn-green d-btn-green" style="color: #FFFFFF !important;">���������������</a>
             </div>
             </div>
								</div>
							
							</div></div>
						</form>
            </div>
         
        </div>
    </div>
    
</div>
</div></div>

<?php } } ?>

								  									<?php
$depn=1;
$depz_t=array();
$depzq=mysql_query("SELECT osum,osum2,odate,odate2,oplan,operiod,oparts,ohours,opproc,oproc,oprofit,oid FROM operations WHERE otype=3 AND odate>$time AND ologin='$u_login'  AND oid!=''  AND osum>0 ORDER BY odate2 DESC");
$deptot=mysql_num_rows($depzq);
while($depzm=mysql_fetch_row($depzq)){

$depz_t[]=$depzm[3]+(floor(($time-$depzm[3])/($depzm[5]*3600)))*$depzm[5]*3600+$depzm[5]*3600;
$progress = (($time-$depzm[3])/($depzm[5]*3600)*100);
echo ' 

        <div class="holder-white holder-search">
            <div class="indentation">
                <h3>����� �����</h3> 
            </div>
             
        </div>
        <div id="w0" class="list-view"><div data-key="346">
<div class="holder-white">
    <div class="offers">
        <div class="indentation">
            <div class="holder-control">
           
                    <h4>� ����� ������ #'.$depzm[11].' �</h4>
                 
                <div class="holder-btn">
                    <div class="see-btn" >
                     ��������  <!--- <i class="fa fa-eye" aria-hidden="true"></i> --->
                    </div>

                                          <a class="link-green link-green2"  style="
    background: #ff9f4a;
    color: #ffffff;
    text-decoration: none;
    border: solid 2px #f38f36;
">
                          <i class="icon-clock-icon"></i>  <font style="display:none">'.(($time-$depzm[3])/($depzm[5]*3600)).'/'.$depzm[6].'</font>    <strong class="mb-0 success" id="zam_'.$depn.'">� ��������</strong>
                        </a>
                    
                </div>
            </div>
            <div class="group">
                <div class="holder-img">
                    <img src="/images/d3.gif">
                </div>

                <div class="holder-text offer-info">
                    <ul class="list-th">
                        <li>
                            <strong>����� ������</strong>
                            <span style="max-width: 90px; display: block;">'.str_replace('.00','',number_format($depzm[1],2,'.',',')).' &#8381;</span>
                        </li>
                        <li>
                            <strong>� ���������</strong>
                            <span>
                               <!-- <span class="icon"><img src="/webmaster/images/svg-4.svg"></span>--->
                                '.str_replace('.00','',$depzm[10]).' &#8381;                           </span>
                        </li>
                        <li>
                            <strong>����� ������</strong>
                            <span>'.date('j '.$mdate[date('n',$depzm[3])-1].'���⠠ H:i',$depzm[3]).'                           </span>
                        </li>
                        <li>
                            <strong>����� ����������</strong>
                            <span>'.date('j '.$mdate[date('n',$depzm[2])-1].'���⠠ H:i',$depzm[2]).'                           </span>
                        </li>
                  
                    </ul>
             
                </div>
            </div>
        </div>
    </div>

</div>
</div></div>

';

$depn++;
}




echo '<script type="text/javascript">';
$n=0;
foreach($depz_t as $dz_time){
$n++;
echo 'var a'.$n.'='.($dz_time-$time+1).';
function c'.$n.'(){
if(a'.$n.'>=1){
var h'.$n.'=(parseInt(a'.$n.'/3600));
if(h'.$n.'<10){h'.$n.'="0"+h'.$n.'};
var sl'.$n.'=a'.$n.'-h'.$n.'*3600;
var m'.$n.'=(parseInt(sl'.$n.'/60));
if(m'.$n.'<10){m'.$n.'="0"+m'.$n.'};
var ls'.$n.'=sl'.$n.'-m'.$n.'*60;
if(ls'.$n.'<10){ls'.$n.'="0"+ls'.$n.';}
document.getElementById("zam_'.$n.'").innerHTML=h'.$n.'+":"+m'.$n.'+":"+ls'.$n.';
a'.$n.'--;
setTimeout("c'.$n.'()",1010);
}
else{
location.href=location.href;
}
}
c'.$n.'();';
}
echo '</script>';


?>


<?php
$deprq=mysql_query("SELECT odate2,osum2,osum,odate,oid FROM operations WHERE otype=3 AND odate<=$time AND osum>0 AND ologin='$u_login' AND oid!='' ORDER BY odate DESC");
$deptot=mysql_num_rows($deprq);
while($deprm=mysql_fetch_row($deprq)){

echo '

        <div class="holder-white holder-search">
            <div class="indentation">
                <h3>����������� �����</h3> 
            </div>
             
        </div>
        <div id="w0" class="list-view"><div data-key="346">
<div class="holder-white">
    <div class="offers">
        <div class="indentation">
            <div class="holder-control">
           
                    <h4>� ����� ������ #'.$deprm[4].' �</h4>
                 
                <div class="holder-btn">
                  

                                          <a class="link-green link-green2">
                          <i class="icon-clock-icon"></i> ��������!
                        </a>
                    
                </div>
            </div>
            <div class="group">
                <div class="holder-img">
                    <img src="/images/d3.jpg">
                </div>

                <div class="holder-text offer-info">
                    <ul class="list-th">
                        <li>
                            <strong>����� ������</strong>
                            <span style="max-width: 90px; display: block;">'.str_replace('.00','',number_format($deprm[1],2,'.',',')).' &#8381;</span>
                        </li>
                        <li>
                            <strong>��������</strong>
                            <span>
                          <!-- <span class="icon"><img src="/webmaster/images/svg-4.svg"></span>--->
                               '.str_replace('.00','',number_format($deprm[2],2,'.',',')).' &#8381;                           </span>
                        </li>
                        <li>
                            <strong>����� ������</strong>
                            <span>'.date('j '.$mdate[date('n',$deprm[0])-1].' H:i',$deprm[0]).'                           </span>
                        </li>
                        <li>
                            <strong>����� ����������</strong>
                            <span>           '.date('j '.$mdate[date('n',$deprm[3])-1].' H:i',$deprm[3]).'              </span>
                        </li>
                  
                    </ul>
             
                </div>
            </div>
        </div>
    </div>

</div>
</div></div>


';

}

?>  </tbody>
                        </table>
						
						
		 



    </section>
</div>                        </div>
                    </div>
                </div>
            </div>
        </div>
		
		
		


<?php


include $_SERVER['DOCUMENT_ROOT']."/cab_footer.php"; // $_SERVER['DOCUMENT_ROOT'] - ��������� �������� ���������� �����

?>