<?php include 'dashboard/header.php';
if ($_POST['id_transaction'])  {
    $user = trim($_POST['user_name_qiwi']);
    $vaucher = trim($_POST['id_transaction']);
    $time = time();
    $datetime = date('Y-m-d H:i:s', $time);
    $sql = "INSERT INTO `qiwi_vaucher` ( 
                                        `login`, 
                                        `date`,
                                        `vaucher`
                    ) VALUES (
                                        '" .$user. "',
                                        '".$datetime."',
                                        '" . $vaucher . "'
                    )
    ";
    $Row = mysql_query( $sql );
    if ($Row == true) {
        $msg = "<h2 class='head-stats'>Ваучер принят! В ближайшее время средства на ваш счет будут зачислены!</h2>";
    }
    else {
        $msg = "<h2 class='head-stats'>Произошла ошибка! Обратитесь в службу поддержки.</h2>";
    }
}
?>
<style type="text/css">
    .send_paeyer_sys {color: #FFF;font-size: 20px;}
    .PAYMENT_AMOUNT{height: 44px;font-size: 25px;border-radius: 0px;}
    .min_summ_pay{font-size:30px;color: rgb(71, 71, 71); text-align: center;}
    .bottom{margin-bottom: 10px;}
</style> 
<style>
input {    padding: 5px;    border: 2px solid #999;    border-radius: 3px;    box-shadow: 0 0 1px 1px rgba(0,0,0,0);    transition: .17s linear;}
input:focus {    outline: none;    box-shadow: 0 0 2px 0px rgb(33, 150, 243);    border: 2px solid #2196f3;}
input:focus::-moz-placeholder {  color: transparent;}input:focus::-webkit-input-placeholder {  color: transparent;}
</style>
<div class="main__container">
    <header class="main__title" style="text-align: center;">
        <?php if(isset($msg)) { echo $msg; } ?>
        <h2 class="head-stats">Создание вклада</h2>
        <small>Пополнения счета через ваучер QIWI</small>
    </header> 
    <div class="send_present">

    <center>
            <img src="/images/vqiwi.png" style="max-width: 75%;">
    </center>
        <div class="row">
            <form id="invest_form" action="/?page=qiwi" method="POST" style="margin:0;padding:0">
                <div class="col-md-12 bottom">
                    <div class="min_summ_pay">Ваучер (<a href="/?page=vaucher">как получить ваучер?</a>):</div>
                </div>
                <div class="col-md-12 bottom">
                    <input class="invest_input" type="text" name="id_transaction" placeholder="Ваучер" maxlength="50" style="font-size: 25px; width: 100%">
                    <input class="invest_input" type="hidden" name="user_name_qiwi" value="<?php echo $u_login; ?>">
                </div>
                <div class="col-md-12 bottom">
                    <a class="btn btn-primary" style="font-size: 25px; width: 100%" href="javascript:with(document.getElementById('invest_form')){ submit(); }">Отправить ваучер</a>
                </div>
            </form>
        </div>
    </div>
</div>          
</section>
</main>