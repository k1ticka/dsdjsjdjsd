<?php
$bsta='login';
if(USER_LOGGED){ $bsta=$u_login; }
?>

<div class="standard_top">�������</div>

<div class="standard_center">

<font class="advert_text">������ 468*60</font>

<br><img src="/img/banners/banner_1.gif">
<div class="advert_banner_text" colspan="2">
&lt;a href="http://<?php echo $site; ?>/?ref=<b><?php echo $bsta; ?></b>"&gt;&lt;img src="http://<?php echo $site; ?>/img/banners/banner_1.gif" width="468px" height="60px" /&gt;&lt;/a&gt;
</div>
<br><font class="advert_text">������ 728*90</font>
<br><img width="665px" src="/img/banners/banner_3.gif">
<div class="advert_banner_text" colspan="2">
&lt;a href="http://<?php echo $site; ?>/?ref=<b><?php echo $bsta; ?></b>"&gt;&lt;img src="http://<?php echo $site; ?>/img/banners/banner_3.gif" width="728px" height="90px" /&gt;&lt;/a&gt;
</div>

</div>

<div class="standard_bottom"></div>
