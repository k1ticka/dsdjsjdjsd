<div class="standard_top_simple">�������</div>

<br>

<?php

if($withed_no==0){

//  ��������� �������

$w_links='';
$sc_f=1;
if(isset($_GET['pn'])){
$_GET['pn']=preg_replace('#[^0-9]+#','',$_GET['pn']);
$_GET['pn']=preg_replace('#^[0]+#','',$_GET['pn']);
if($_GET['pn']>0 && $_GET['pn']<2000){
$sc_f=$_GET['pn'];
}
}

$withedq=mysql_query("SELECT oid FROM operations WHERE otype=2 AND odate2!=''");
$sc_lim=(mysql_num_rows($withedq))/$withed_pp;
if($sc_lim>1){
for($n=0;$n<$sc_lim;$n++){
if($sc_f==($n+1)){ $w_links.='<font class="withed_link_a">'.($n+1).'</font> &nbsp;'; }
else{ $w_links.='<a class="withed_link_b" href="/?page=withed&pn='.($n+1).'">'.($n+1).'</a> &nbsp;'; }
}
}

}
?>

<?php if(!empty($w_links)){ echo '<div class="withed_links">'.$w_links.'</div>'; } ?>

<table class="withed_table" cellpadding="0px" cellspacing="0px">
<tr>
<td width="210px"style="padding-left:20px;">�����</td>
<td width="220px">�����</td>
<td width="270px">����</td>
</tr>
</table>

<?php
if(!empty($_GET['pn']) && $withed_no==0){
$w_start=preg_replace('#[^0-9]+#','',$_GET['pn']);
$w_start=preg_replace('#^[0]+#','',$w_start);
if($w_start>1 && $w_start<2000){
$w_start=$w_start*$withed_pp-$withed_pp;
$withedq=mysql_query("SELECT ologin,osum,odate2 FROM operations WHERE otype=2 AND odate2!='' ORDER BY odate2 DESC LIMIT $w_start,$withed_pp");
if(mysql_num_rows($withedq)==0){
$withedq=mysql_query("SELECT ologin,osum,odate2 FROM operations WHERE otype=2 AND odate2!='' ORDER BY odate2 DESC LIMIT $withed_pp");
}
}
else {
$withedq=mysql_query("SELECT ologin,osum,odate2 FROM operations WHERE otype=2 AND odate2!='' ORDER BY odate2 DESC LIMIT $withed_pp");
}
}
else{
$withedq=mysql_query("SELECT ologin,osum,odate2 FROM operations WHERE otype=2 AND odate2!='' ORDER BY odate2 DESC LIMIT $withed_pp");
}

while($withedm=mysql_fetch_row($withedq)){ ?>

<table class="withed_table_2" cellpadding="0px" cellspacing="0px">
<tr>
<td class="withed_login"><?php echo $withedm[0]; ?></td>
<td class="withed_sum"><?php echo str_replace('.00','',$withedm[1]); ?> ���.</td>
<td class="withed_date"><?php echo date('j ',$withedm[2]).$mdate[date('n',$withedm[2])-1].date(' H:i',$withedm[2]); ?></td>
</tr>
</table>


<?php } ?>


<?php if(!empty($w_links)){ echo '<div class="withed_links">'.$w_links.'</div>'; } ?>
