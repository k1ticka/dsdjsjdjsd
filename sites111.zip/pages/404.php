<img src="404.png" alt="404">
<a class="btn btn-danger" href="/" style="margin-top: 5px;margin-left: 6px; margin-top: 5px;margin-left: 6px;width: 100%;color: #fff;background-color: #0023a0;border-color: #0023a0;">The End</a>
<a href="http://script-money.ru"><img width="100" height="25" src="http://script-money.ru/wp-content/uploads/2019/06/money-1.png"></a>