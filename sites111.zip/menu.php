          <div class="holder-nuv">
                            <nav id="nav">
                                <ul>
			 
				 
								<li><a href="/?p=hold"><i class="icon icon-2"></i><span>��� ������</span></a></li>
								<li><a href="/?p=add"><i class="icon icon-ok-circle-icon"></i><span>������� �����</span></a></li>
								<li><a href="/?p=withdrawal"><i class="icon icon-6"></i><span>������� ��������</span></a></li>
								<li><a href="/?p=pr"><i class="icon icon-4"></i><span>��� ��������</span></a></li>
								<li><a href="/?p=sett"><i class="icon icon-settings-1-icon"></i><span>���������</span></a></li>
								<li><a href="/logout.php"><i class="icon icon-exit-right-icon"></i><span>�����</span></a></li>
								
</ul>                            </nav>

                            <!-- manager -->
                                                            <div class="holder-manager">
                                    <span class="title-manager">���������</span>
                                    <div class="holder-text">
                                        <p>
                                            <strong>Telegram:</strong>
                                            <a href="tg://resolve?domain=bitnexbiz">@bitnexbiz</a>
                                        </p>
                                        <p>
                                            <strong>Support</strong> <a href="mailto:support@bitnex.biz">support@bitnex.biz</a>
                                        </p>
                                        <a class="btn-question" href="/?p=comment">�������� �����</a>
                                    </div>
                                </div>
                            

                        </div>