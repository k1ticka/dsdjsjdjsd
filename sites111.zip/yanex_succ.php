<?php
error_reporting(0);
// error_reporting(E_ALL);

ini_set('session.use_cookies', 'On');
ini_set('session.use_trans_sid', 'Off');
ini_set('session.gc_maxlifetime',7200);
ini_set('session.cookie_lifetime',7200);
session_set_cookie_params(7200, '/');

session_start();

include('conf.php');

$site=$_SERVER['HTTP_HOST'];

@mysql_query('set character_set_client="cp1251"');
@mysql_query('set character_set_results="cp1251"');
@mysql_query('set collation_connection="cp1251_general_ci"');

// $_POST = unserialize( file_get_contents( 'qqqqqqqqq.txt' ) );
// echo "<pre>";
// print_r($_POST);


/*
Array ( 
		[m_operation_id] => 40010149 
		[m_operation_ps] => 2609 
		[m_operation_date] => 16.01.2015 00:33:54 
		[m_operation_pay_date] => 16.01.2015 00:34:04 
		[m_shop] => 35995144 
		[m_orderid] => 1 
		[m_amount] => 0.01 
		[m_curr] => RUB 
		[m_desc] => VXNlciBOYW1lOiAxMjNfU1VNTTogMC4wMV9Qcm9jZW50OiAxMTAl 
		[m_status] => success 
		[m_sign] => DB446561CE4AEBC0FD3136C5107A69CA5FF68D3BAD84C277304FCB800078D746 
		[lang] => ru 
		[PHPSESSID] => 44c9e8ed5856bc5ab4f5ef7c82420685 )

*/
$m_sign = $_POST['operation_id'];
$Row = mysql_query("SELECT `m_sign` FROM `operations` WHERE `m_sign` = '".$m_sign."'");
$Rows = mysql_fetch_assoc($Row);

$sha1_hash = sha1($_POST['notification_type'].'&'.
$_POST['operation_id'].'&'.
$_POST['amount'].'&'.
$_POST['currency'].'&'.
$_POST['datetime'].'&'.
$_POST['sender'].'&'.
$_POST['codepro'].'&'.
'OTMIjtJ+PdabBZ4x5Eth8j0F'.'&'.
$_POST['label']);

if ($_POST['sha1_hash'] != $sha1_hash or $Rows['m_sign'] == $m_sign or $_POST['codepro'] === true or $_POST['unaccepted'] === true) {
	die('HACKING ATTEMPT!!!<br>Your IP was sent to the administrator for blocking!');
}
		$user_name = trim( $_POST['label'] );

		$desc = "���������� ����� ��������� ������� ������.������ ��� ".$user_name;
		$to_batch = $desc;
		
		$SUMM = $_POST['withdraw_amount'];

		if ($_POST['notification_type'] == 'p2p-incoming') {
			$out_type = "yandex";
		}
		else {
			if ($_POST['notification_type'] == 'card-incoming') {
				$out_type = "card";
			}
		}
		// $SUMM = 103;
		
		$Procent = $procent_yandex;
		
		$proc = $SUMM * ( $Procent / 100 );
		
		$time = time();		
		$time_2 = $time + ( 3600 * $kolvo_chasov );
								## �������� ���� �� � ��� �������
				$sql_qw = "SELECT `ref` FROM `users` WHERE `login` = '" . $user_name . "'";
				$res_qw = mysql_query( $sql_qw );
				$res_qw = mysql_fetch_assoc( $res_qw );
				$res_qw = $res_qw['ref'];
				
				## ���� ���� ���, �������� ��� 5% �� ����� ������
				$send_proc = '0.00';
				if (	trim( $res_qw ) != '' )
					$send_proc = ( $SUMM / 100 ) * $d_ref;
				else
					$res_qw = '';
				
				
		$sql=mysql_query("INSERT INTO 
								`operations` (
												`ologin`,
												`otype`,
												`osum`,
												`osum2`,
												`odate`,
												`odate2`,
												`oplan`,
												`operiod`,
												`oparts`,
												`ohours`,
												`opproc`,
												`oproc`,
												`oprofit`,
												`oref`,												
												`orefrbp`,
												`orefbonus`,
												`orefsum`,
												`orefback`,
												`orefproc`,
												`obatch`,
												`oback`,
												`o_type`,
												`out_type`,
												`m_sign`
								) 
							VALUES (
												'" . $user_name . "',		
														'3',						
														'" . $proc . "',			
														'" . $SUMM . "', 			
														'" . $time_2 ."',			
														'" . $time ."',				
														'1',						
														'" . $kolvo_chasov ."',						
														'1',						
														'" . $kolvo_chasov ."',						
														'" . $Procent ."',			
														'" . $Procent ."',			
														'" . $proc . "',			
														'" . trim( $res_qw ) ."',							
														'0',						
														'0',						
														'" . $send_proc . "',						
														'0.00',						
														'" . $d_ref . "',						
														'" . $m_sign . "',		
														'',							
														'',							
														'".$out_type."',
														'".$m_sign."'						
												
							)"
		) or die( mysql_error());
		mysql_query("UPDATE data SET `plus` = `plus`+".$SUMM);

?>


