<?php
// $_REQUEST = unserialize( file_get_contents( 'test.txt' ) );
// echo "<pre>";
// print_r($_REQUEST);



$array = array();
if ( isset( $_REQUEST['PAYMENT_AMOUNT'] ) && trim( $_REQUEST['PAYMENT_AMOUNT'] ) != '' )
	{
		// $m_shop = '380069659';
		$m_shop = '640421317';
		$m_orderid = '1';
		$m_amount = number_format( trim( $_REQUEST['PAYMENT_AMOUNT'] ) , 2, '.', '');
		$m_curr = 'RUB';
		$m_desc = base64_encode(
								'User Name: ' . trim( $_REQUEST['tmp_users'] ) . "_" . 
								'SUMM: ' . $m_amount . "_" . 
								'Procent: ' . trim( $_REQUEST['desc_plan'] ) . "%"
		
		);
		
		// $m_desc = base64_encode('test_111');
		// $m_key = '635911';
		$m_key = 'dCUlf8787tyFbxgr';
		
		
		
		$arHash = array(
			$m_shop,
			$m_orderid,
			$m_amount,
			$m_curr,
			$m_desc,
			$m_key
		);
		$sign = strtoupper( hash( 'sha256', implode(':', $arHash)));
		
		$array = array(
						'm_shop' => $m_shop,
						'm_orderid' => $m_orderid,
						'm_amount' => $m_amount,
						'm_curr' => $m_curr,
						'm_desc' => $m_desc,
						'm_sign' => $sign
		);
	}

$array = json_encode( $array );
		
echo $array;

