<!DOCTYPE html PUBLIC "" "">
<html lang="ru"><head>
   
   	    <meta http-equiv="content-type" content="text/html; charset=windows-1251" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
	
	    <title>Bitnex.biz � ������ � ������� ���������� �������!</title>
	
	
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
<meta name="description" content="Bitnex.biz: �������� � �������� ������ ��� ������� ��������, ����������� ��� ������!">
	<meta property="og:locale" content="ru_RU"/>
<meta property="og:type" content="article"/>
	<meta content="https://bitnex.biz/images/soc.png">
	<meta name="msapplication-TileImage" content="https://bitnex.biz/images/soc.png">
<meta property="og:title" content="Bitnex.biz - ������ � ������� ���������� �������!"/>
<meta property="og:description" content="��������� � �������� ����� � Bitnex.biz ��� �����-���� �������� � ����� �������! ����������� ������ �� ����� ����� ������!"/>
<meta property="og:image" content="https://bitnex.biz/images/soc.png"/>
<meta property="og:site_name" content="Bitnex.biz - ������ � ������� ���������� �������!"/>
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <meta name="format-detection" content="telephone=no"/>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, shrink-to-fit=no">
   <link rel="shortcut icon" href="/images/favicon.ico" type="image/x-icon" />
    <link href="/cabinet/assets/1df6f1f0/css/bootstrap.css" rel="stylesheet">
<link href="/cabinet/assets/7603687/media/css/jquery.dataTables.css" rel="stylesheet">
<link href="/profile/ico/style.css" rel="stylesheet">
<link href="/cabinet/css/bootstrap.css" rel="stylesheet">
<link href="/cabinet/css/slick.css" rel="stylesheet">
<link href="/cabinet/fonts/style.css" rel="stylesheet">
<link href="/cabinet/css/dropdown.css" rel="stylesheet">
<link href="/cabinet/css/jquery.mCustomScrollbar.min.css" rel="stylesheet">
<link href="/cabinet/css/codemirror.css" rel="stylesheet">
<link href="/cabinet/css/all.css" rel="stylesheet">
<link href="/cabinet/css/custom.css" rel="stylesheet">
<link href="/cabinet/css/font-awesome.css" rel="stylesheet">    <style>
     .logo {
    display: inline-block;
    background: url(../images/logoNew1.png) no-repeat;
    width: 220px;
    height: 70px;
    text-indent: -9999px;
    background-size: 220px;
    overflow: hidden;
    margin: 0 0 0 20px;
    margin-top: 1px;
    -webkit-transition: all 300ms linear;
    -moz-transition: all 300ms linear;
    -ms-transition: all 300ms linear;
    -o-transition: all 300ms linear;
    transition: all 300ms linear;
}
        .link-green2 {
            background: #8bc34a;
            color: #ffffff;
            text-decoration: none;
        }
        .holder-block {
            z-index: 99999;
        }
    </style>
</head>
<body>

    
        <div class="main-wrapper">
    <div id="wrapper">
        <header id="header">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">
                        <div class="header-left">
                            <div class="holder-logo">
                                <strong class="logo"><a href="/">BITNEX</a></strong>
                            </div>
                            <a class="btn-menu" href="#">
                                <i class="icon-menu-left-1-icon"></i>
                                <i class="icon-menu-right-1-icon"></i>
                            </a>
                        </div>
                        <div class="header-right">
                            <span class="notifications">
                                <span class="btn-notifications" href="#">
                                                                        <span class="hide-text">��������</span>
                                </span>
                            </span>
                            <div class="balance">
                                <span class="btn-balance btn-item">
                                    ������:
                                    <a  class="balance-link" href="/?p=add"><?php echo number_format($b_tot,2,'.',','); ?></a>                                    
									<span class="icon-currency"></span>
                                </span>


                            </div>

                            <div class="hild">
                                <span class="btn-hild btn-item">
                                   �� �����:
                                    <a  class="hold-link"><?php echo str_replace('.00','',number_format($b_pended,2,'.',',')); ?></a>                                    <span class="icon-currency"></span>
                                </span>
                            </div>
                                                        <div class="hild item-head">
                                <span class="btn-bonuses btn-item" >�������: <a><?php $deprq=mysql_fetch_row(mysql_query("SELECT COUNT(oid) FROM operations WHERE otype=3 AND odate>$time AND osum>0 AND ologin='$u_login'"));  echo $deprq[0]; ?></a> <i class="icon-arrow-down-1-icon"></i>
								<i class="icon-arrow-up-1-icon"></i></span>
                            </div>
                                                        <div class="account item-head">
                                <span class="mail-account btn-item">
                                    <?php echo $u_login; ?>                                 <i class="icon-arrow-down-1-icon"></i>
                                    <i class="icon-arrow-up-1-icon"></i>
                                </span>
                                <ul class="header-drop">
                                    <li>
                                        <a href="/?p=sett">
                                            <i class="icon-edit-icon"></i>
                                            ������������� �������                                        </a>
                                    </li>
                                    <li>
                                        <a href="/logout.php">
                                            <i class="icon-exit-right-icon"></i>
                                            �����                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <a class="exit-cabinet" href="/logout.php">
                                <i class="icon-exit-right-icon"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </header>











 