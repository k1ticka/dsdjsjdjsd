<?php
if (!defined("ADMIN")) {
	die('HACKING ATTEMPT!!!');
}
if(!empty($_POST['login']) && !empty($_POST['batch']) && $_POST['act']==1){

$to_batch=preg_replace("#[^0-9a-z]+#i",'',$_POST['batch']);
$sum=$_POST['sum'];
$o_type = $_POST['o_type'];
$sum=preg_replace("#[^0-9\.]+#",'',$sum);
$sum=preg_replace("#\.+#",'.',$sum);
$sum=number_format($sum,2,'.','');
if ($o_type=='wm') {
	$sum=$sum*$kurs_dollars;
}
$d_min=number_format($d_min,2,'.','');
$d_max=number_format($d_max,2,'.','');
if($user_name='' || strlen($to_batch)<8){
$p_e='��� ������������ ������ ��� � ���� �������� ������ 8 ��������';
}
else{


if(empty($sum)){ 
	$p_e='����� �����������'; 
}
$sum=number_format($sum,2,'.','');

if(empty($p_e) && ($sum==0 || $sum==0.00)){ 
	$p_e='����� ����� ����'; 
}


// ================================================== ����?�����? / �������?��? ==================================================


if(empty($p_e)){
	$Procent=$procent_yandex;
		$m_sign='AdminPanel';
		$proc = $sum * ( $Procent / 100 );
		
		$time = time();		
		$time_2 = $time + ( 3600 * $kolvo_chasov );
								## �������� ���� �� � ��� �������
				$sql_qw = "SELECT `ref` FROM `users` WHERE `login` = '" . $_POST['login'] . "'";
				$res_qw = mysql_query( $sql_qw );
				$res_qw = mysql_fetch_assoc( $res_qw );
				$res_qw = $res_qw['ref'];
				
				## ���� ���� ���, �������� ��� 5% �� ����� ������
				$send_proc = '0.00';
				if (	trim( $res_qw ) != '' )
					$send_proc = ( $sum / 100 ) * $d_ref;
				else
					$res_qw = '';
///////////////

		mysql_query("INSERT INTO `operations` (
									`ologin`,
									`otype`,
									`osum`,
									`osum2`,
									`odate`,
									`odate2`,
									`oplan`,
									`operiod`,
									`oparts`,
									`ohours`,
									`opproc`,
									`oproc`,
									`oprofit`,
									`oref`,												
									`orefrbp`,
									`orefbonus`,
									`orefsum`,
									`orefback`,
									`orefproc`,
									`obatch`,
									`oback`,
									`out_type`,
									`m_sign`
								) VALUES (
									'" . $_POST['login'] . "',		
									'3',						
									'" . $proc . "',			
									'" . $sum . "', 			
									'" . $time_2 ."',			
									'" . $time ."',				
									'1',						
									'" . $kolvo_chasov ."',						
									'1',						
									'" . $kolvo_chasov ."',						
									'" . $Procent ."',			
									'" . $Procent ."',			
									'" . $proc . "',			
									'" . trim( $res_qw ) ."',							
									'0',						
									'" . $u_refrefbonus . "',						
									'" . $send_proc . "',						
									'" . $orefback ."',						
									'" . $d_ref . "',						
									'" . $to_batch . "',		
									'" . $oback . "',														
									'" . $o_type . "',
									'" . $m_sign . "'												
								)") or die( mysql_error());
///////////

$p_s='������ '.$to_batch.' ������� �������� ��� ������ '.$_POST['login'];

$popscq=mysql_query("SELECT COUNT(DISTINCT(ologin)),SUM(osum2) FROM operations WHERE otype=3 AND osum2>0 AND obatch!='' AND oback=''");
$popscm=mysql_fetch_row($popscq);

$invren='';
if($reinv_inc==1){
$invreq=mysql_query("SELECT ologin,osum2 FROM operations WHERE otype=3 AND osum2>0 AND oback='' ORDER BY odate2 DESC LIMIT 10");
}
else{
$invreq=mysql_query("SELECT ologin,osum2 FROM operations WHERE otype=3 AND osum2>0 AND obatch!='' AND oback='' ORDER BY odate2 DESC LIMIT 10");
}
while($invrem=mysql_fetch_row($invreq)){
$invrez=$invest_s;
$invrez=str_replace('#LOGIN#',$invrem[0],$invrez);
$invrez=str_replace('#SUM#',$invrem[1],$invrez);
$invren.=$invrez;
}

mysql_query("UPDATE data SET activ='$popscm[0]', plus='$popscm[1]', plus_n='$invren'") or die(mysql_error());

}


}
} 


?>










<?php if(!empty($p_e)){ ?><div class="popolnenie_error"><?php echo $p_e; ?></div><?php } ?>
<?php if(!empty($p_s)){ ?><div class="popolnenie_success"><?php echo $p_s; ?></div><?php } ?>









<form id="popolnenie" action="/admin.php?page=deposits" method="POST" style="margin:0;padding:0">

	<input type="text" name="login">

	<input type="text" name="batch">

	<input id="act" type="hidden" name="act" value="1">
	<select name="o_type">
		<option value="qiwi">QIWI Wallet RUB</option>
		<option value="yandex">Yandex RUB</option>
	  	<option value="payeer">Payeer RUB</option>
	  	<option value="card">Card RUB</option>
	  	<option value="wm">PerfectMoney USD</option> 	
	</select>

	<input type="text" name="sum" maxlength="9">
<button>���������</button>


</form>