<?php
if (!defined("ADMIN")) {
	die('HACKING ATTEMPT!!!');
}
if(!empty($_POST['oid']) && !empty($_POST['obatch'])){
$oid=preg_replace("#[^0-9]+#i",'',$_POST['oid']);
$obatch=preg_replace("#[^0-9a-z]+#i",'',$_POST['obatch']);
if($oid>0 && strlen($obatch)>5){

$ssq=mysql_query("SELECT oback FROM operations WHERE oid='$oid'");
$ssm=mysql_fetch_row($ssq);
if($ssm[0]=='1'){
mysql_query("UPDATE operations SET oback=2,obatch='$obatch' WHERE oid='$oid'") or die(mysql_error());
}
else{
mysql_query("UPDATE operations SET odate2='$time',obatch='$obatch' WHERE oid=$oid") or die(mysql_error());
$avq=mysql_query("SELECT SUM(osum) FROM operations WHERE otype=2 AND odate2!=''");
$avm=mysql_fetch_row($avq);
$aviq=mysql_query("SELECT ologin,osum FROM operations WHERE otype=2 AND odate2!='' ORDER BY odate2 DESC LIMIT 10");
$avin='';
while($avim=mysql_fetch_row($aviq)){
$aviz=$with_s;
$aviz=str_replace('#LOGIN#',$avim[0],$aviz);
$aviz=str_replace('#SUM#',$avim[1],$aviz);
$avin.=$aviz;
}
mysql_query("UPDATE data SET `with`='$avm[0]', with_n='$avin'") or die(mysql_error());
}
}
}
?>



<!-- ������� ������� -->

<form id="vyvod" action="/admin.php?page=paidouts" method="POST" style="margin:0;padding:0">
<input id="oid" type="hidden" name="oid">
<input id="obatch" type="hidden" name="obatch">
</form>


<?php
$tovq=mysql_query("SELECT SUM(osum2) FROM operations WHERE oback=1");
$tovm=mysql_fetch_row($tovq);
if($tovm[0]>0){
?>

<div class="admin_vyvod_title">�������� �� �����: <font color="#EC7600"><?php echo $tovm[0]; ?></font> ���</div>

<br>

<table align="center" class="admin_vyvod_stat" cellpadding="0px" cellspacing="0px">
	<tr>
		<td style="width:140px;">����</td>
		<td style="width:110px;">�����</td>
		<td style="width:190px;">������</td>
		<td style="width:100px;">�����</td>		
		<td style="width:120px;">��������</td>
	</tr>
</table>

<table align="center" style="margin-top:6px;" cellpadding="0px" cellspacing="0px">
<?php
$statsq=mysql_query("SELECT odate,ologin,osum2,oid FROM operations WHERE oback=1 ORDER BY odate ASC");
while($statsm=mysql_fetch_row($statsq)){ ?>
<tr>
<td class="admin_vyvod_date"><?php echo date('j '.$mdate[date('n',$statsm[0])-1].' H:i',$statsm[0]); ?></td>
<td class="admin_vyvod_login"><?php echo $statsm[5]; ?><?php echo $statsm[1]; ?></td>
<td class="admin_vyvod_batch"><input id="ic<?php echo $statsm[3]; ?>" type="text" maxlenght="50"></td>
<td class="admin_vyvod_sum"><?php echo str_replace('.00','',$statsm[2]); ?></td>
<td class="admin_vyvod_action"><a href="javascript:admin_vyvod('<?php echo $statsm[3]; ?>')">����������</a></td>
</tr>
<?php } ?>
</table>
<br>
<?php } ?>


<!-- ����� ������� -->


<?php
$tovq = mysql_query("SELECT SUM(osum) FROM operations WHERE otype=2 AND odate2=''");
$tovm = mysql_fetch_row($tovq);

if(!empty($tovm[0])){
?>

<div class="admin_vyvod_title">������� �� �����: <font color="#EC7600"><?php echo $tovm[0]; ?></font> ���</div>

<br>

<table align="center" cellpadding="0px" cellspacing="0px">
<tr style="text-align: center; font-weight: bold;" class="admin_vyvod_stat">
<td style="width:140px;">����</td>
<td style="width:110px;">�����</td>
<td style="width:190px;">��� ������</td>
<td style="width:100px;">�����</td>
<td style="width:100px;">���<br>�������</td>
<td style="width:100px;">�����<br>��������</td>
<td style="width:120px;">��������</td>
</tr>

<?php

$statsq = mysql_query("SELECT odate,ologin,osum,oid,o_type FROM operations WHERE otype=2 AND odate2='' ORDER BY odate ASC");
while( $statsm = mysql_fetch_row( $statsq ) ){ 


	$payment_number_purse = mysql_query( 
										"SELECT 
												`wmr`, `yandex`, `payeer`, `qiwi` 
										FROM 
												`users` 
										WHERE 
											login = '" . $statsm[1] . "'"
	);
	
	$payment_number_purse_value = mysql_fetch_assoc( $payment_number_purse );
	/*
		Array
		(
			[wmr] => R289506805694
			[yandex] => 
			[payeer] => P5754654
			[qiwi] => +79622691594
		)
	*/
	
if( trim( $statsm[4] ) == 'wm' )
	$statsm_data = array( 'number' => $payment_number_purse_value['wmr'], 'type' => 'WebMoney' );
elseif( trim( $statsm[4] ) == 'qiwi' )
	$statsm_data = array( 'number' => $payment_number_purse_value['qiwi'], 'type' => 'Qiwi' );
elseif( trim( $statsm[4] ) == 'yandex' )
	$statsm_data = array( 'number' => $payment_number_purse_value['yandex'], 'type' => 'Yandex' );
elseif( trim( $statsm[4] ) == 'payeer' )
	$statsm_data = array( 'number' => $payment_number_purse_value['payeer'], 'type' => 'Payeer' );
else
	$statsm_data = array( 'number' => '', 'type' => '' );
	
?>
<tr style="text-align: center; padding:5px;" >
<td nowrap style="padding: 5px;" class="admin_vyvod_date"><?php echo date('j '.$mdate[date('n',$statsm[0])-1].' H:i',$statsm[0]); ?></td>
<td nowrap style="padding: 5px;" class="admin_vyvod_login"><?php echo $statsm[1]; ?></td>
<td nowrap style="padding: 5px;" class="admin_vyvod_batch"><input id="ic<?php echo $statsm[3]; ?>" type="text" maxlenght="50"></td>
<td nowrap style="padding: 5px;" class="admin_vyvod_sum"><?php echo str_replace('.00','',$statsm[2]); ?></td>
<td nowrap style="padding: 5px;" class="admin_vyvod_type"><?php echo $statsm_data['type']; ?></td>
<td nowrap style="padding: 5px;" class="admin_vyvod_number"><?php echo $statsm_data['number']; ?></td>
<td nowrap style="padding: 5px;" class="admin_vyvod_action"><a href="javascript:admin_vyvod('<?php echo $statsm[3]; ?>')">���������</a></td>
</tr>
<?php } ?>
</table>
<?php } ?>
