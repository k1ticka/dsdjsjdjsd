<?php
if (!defined("ADMIN")) {
	die('HACKING ATTEMPT!!!');
}
if(isset($_GET['premod']) && $_GET['premod']==0){ mysql_query("UPDATE data SET reviews_mode='0'"); $d_reviews_mode=0; }
if(isset($_GET['premod']) && $_GET['premod']==1){ mysql_query("UPDATE data SET reviews_mode='1'"); $d_reviews_mode=1; }
if(isset($_GET['premod']) && $_GET['premod']==2){ mysql_query("UPDATE data SET reviews_mode='2'"); $d_reviews_mode=2; }



if(!empty($_POST['rid']) && ($_POST['oper']==0 || $_POST['oper']==1)){
$rid=preg_replace('#[^0-9]+#','',$_POST['rid']);
$oper=$_POST['oper'];
if($oper==0){
mysql_query("DELETE FROM reviews WHERE rid=$rid");
}
if($oper==1){
mysql_query("UPDATE reviews SET rcan='0' WHERE rid=$rid");
}
mysql_query("UPDATE data SET reviews_count=(SELECT COUNT(rid) FROM reviews WHERE rcan!=1)");
}
?>

<div class="premod"><font>���������: </font>
<?php
if($d_reviews_mode==0){ echo '<a class="preon" href="/admin.php?page=reviews&premod=1">��� ��������</a>'; }
if($d_reviews_mode==1){ echo '<a class="preon" href="/admin.php?page=reviews&premod=2">� ���������</a>'; }
if($d_reviews_mode==2){ echo '<a class="preoff" href="/admin.php?page=reviews&premod=0">���������</a>'; }
?>
</div>

<div class="reviews_main">

<form id="form_reviews" action="/admin.php?page=reviews" method="POST">
<input id="rid" type="hidden" name="rid">
<input id="oper" type="hidden" name="oper">
</form>

<script type="text/javascript">
function deletes(rid){
document.getElementById('rid').value=rid;
document.getElementById('oper').value=0;
with(document.getElementById('form_reviews')){ submit(); }
}
function adds(rid){
document.getElementById('rid').value=rid;
document.getElementById('oper').value=1;
with(document.getElementById('form_reviews')){ submit(); }
}
</script>

<table align="center" cellpadding="0px" cellspacing="0px">
<tr>
<td>


<?php
$reviewsq=mysql_query("SELECT rlogin,rdate,rpost,rid FROM reviews WHERE rcan=1 ORDER BY rdate DESC LIMIT 30");
while($reviewsm=mysql_fetch_row($reviewsq)){ ?>
<table class="reviews_top" cellpadding="0px" cellspacing="0px">
<tr>
<td class="reviews_login"><?php echo $reviewsm[0]; ?></td>
<td class="reviews_date"><?php echo date('j ',$reviewsm[1]).$mdate[date('n',$reviewsm[1])-1].date(' H:i',$reviewsm[1]); ?>&nbsp;&nbsp;<a class="delete" href="javascript:deletes('<?php echo $reviewsm[3]; ?>');">�������</a>&nbsp; | &nbsp;<a class="add" href="javascript:adds('<?php echo $reviewsm[3]; ?>');">��������</a></td>
</tr>
<tr>
<td class="reviews_review" colspan="2">
<?php
$rew=$reviewsm[2];
$rew=wordwrap($rew,100,' ',1);
for($n=1;$n<$reviews_s+1;$n++){
$rew=str_replace('*'.$n.'*','<img src="images/smiles/'.$n.'.gif">',$rew);
}
echo $rew;
?>
</td></tr>
</table>
<div class="reviews_bottom"></div>
<?php } ?>

<?php
$reviewsq=mysql_query("SELECT rlogin,rdate,rpost,rid FROM reviews WHERE rcan='0' ORDER BY rdate DESC LIMIT 30");
while($reviewsm=mysql_fetch_row($reviewsq)){ ?>
<table class="reviews_top" cellpadding="0px" cellspacing="0px">
<tr>
<td class="reviews_login"><?php echo $reviewsm[0]; ?></td>
<td class="reviews_date"><?php echo date('j ',$reviewsm[1]).$mdate[date('n',$reviewsm[1])-1].date(' H:i',$reviewsm[1]); ?>&nbsp;&nbsp;<a class="delete" href="javascript:deletes('<?php echo $reviewsm[3]; ?>');">�������</a></td>
</tr>
<tr>
<td class="reviews_review" colspan="2">
<?php
$rew=$reviewsm[2];
$rew=wordwrap($rew,100,' ',1);
for($n=1;$n<$reviews_s+1;$n++){
$rew=str_replace('*'.$n.'*','<img src="images/smiles/'.$n.'.gif" style="width:20px;">',$rew);
}
echo $rew;
?>
</td></tr>
</table>
<div class="reviews_bottom"></div>
<?php } ?>




</td>
</tr>
</table>
