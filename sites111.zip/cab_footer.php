 <footer id="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-xs-12">
                        <span class="copyright">� Bitnex.biz - ����� ��� �������������� � ��������������� �������. ��� ����� �������� 2019 �.</span>
                    </div>
                </div>
            </div>
        </footer>
    </div>
</div>

	<div id="clientBehaviorStorageBinder"></div>

        <?php echo "<div class='deposits_error' style='
    width: 400px;
    right: 0;
    float: right;
    bottom: 0;
    position: fixed;
'>".$error."</div>"; ?>
        </div>
		
		<div class="modal fade modal-one in" id="withdrawal_modals" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="false" style="top: 10%; padding-right: 17px;">
	 

<div class="withdrawal_modal" > <br><br>
</div></div> 
 <script type="text/javascript">

            function send(id){
                $.ajax({
                    url:'/cl_payments.php',
                    type:'POST',
                    dataType:'html',
                    data:$('#'+id).serializeArray(),      
                    success:function(data){
                        $('.withdrawal_modal').html(data);
                        $('#withdrawal_modals').modal('show');

                    },
                    error:function(data){
                        $('.withdrawal_modal').html(data);
                    },
                });
            };
        </script>
<script src="/cabinet/assets/16a0061d/jquery.js"></script>
<script src="/js/function.js"></script>

<script src="/cabinet/assets/8c9caea8/yii.js"></script>
<script src="/cabinet/assets/7603687/media/js/jquery.dataTables.js"></script>
<script src="/cabinet/jss/libs/jquery-ui.1.10.3.min.js"></script>
<script src="/cabinet/jss/libs/jquery.ui.datepicker-ru.js"></script>
<script src="/cabinet/jss/bootstrap.js"></script>
<script src="/cabinet/jss/libs/slick.min.js"></script>
<script src="/cabinet/jss/libs/Chart.bundle.min.js"></script>
<script src="/cabinet/jss/libs/core.js"></script>
 
<script src="/cabinet/jss/libs/dropdown.js"></script>
<script src="/cabinet/jss/codemirror.js"></script>
<script src="/cabinet/jss/jquery.matchHeight.js"></script>

<script src="/cabinet/jss/jquery.mCustomScrollbar.min.js"></script>
<script src="http://cdnjs.cloudflare.com/ajax/libs/jquery-mousewheel/3.1.13/jquery.mousewheel.min.js"></script>
<script src="/cabinet/jss/jquery.main.js"></script>
<script src="/cabinet/jss/custom.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.js"></script>
<script type="text/javascript">var weekDatesParray = [];

var i = 0;
var weekDatesArray = new Array();
while (i < 7) {
var date = new Date(weekDatesParray[i]);
  weekDatesArray[i] = getWeekDay(date);
  i++;
}

function getWeekDay(date) {
  var days = ['��', '��', '��', '��', '��', '��', '��'];

  return days[date.getDay()];
}

// ������� �� �������
if($('#chart1').length){
    initCharts ();
}

    function initCharts (){
        window.chartColors = {
            red: 'rgb(237, 22, 81)',
            orange: 'rgb(205, 164, 97)',
            yellow: 'rgb(190, 215, 48)',
            green: 'rgb(138, 195, 74)',
            blue: 'rgb(0, 134, 167)',
            purple: 'rgb(153, 102, 255)',
            grey: 'rgb(231,233,237)'
        };
        window.randomScalingFactor = function() {
            return (Math.random() > 0.5 ? 1.0 : -1.0) * Math.round(Math.random() * 10);
        }
        var YEAR = ["������", "�������", "����", "������", "���", "����", "����", "������", "�������", "������", "�����", "?������"];
        var MONTH = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31"];
        // var WEEK = ["��", "��", "��", "��", "��", "��", "��"];
        var WEEK = weekDatesArray;
        var DAY = ["0�.", "1�.", "2�.", "3�.", "4�.", "5�.", "6�.", "7�.", "8�.", "9�.", "10�.", "11�.", "12�.", "13�.", "14�.", "15�.", "16�.", "17�.", "18�.", "19�.", "20�.", "21�.", "22�.", "23�."];

        var config1 = {
            type: 'line',
            data: {
                labels: WEEK,
                datasets: [{
                    label: "# of Votes",
                    data: [],
                    fill: false,
                }]
            },
            options: {
                maintainAspectRatio : false,
                responsive: true,
                title:{
                    display:false
                },
                scales: {
                    xAxes: [{
                            display: true,
                            scaleLabel: {
                                display: true,
                            }
                        }],
                    yAxes: [{
                            display: true,
                            ticks: {
                                beginAtZero: true,
                            }
                        }]
                },
                elements: {
                    point: {
                        hoverRadius: 6,
                        borderWidth: 4,
                        radius: 6,
                        borderColor: 'rgb(138, 195, 74)',
                        backgroundColor: 'rgb(255,255,255)'
                    },
                    line: {
                        borderWidth: 2,
                        borderColor: 'rgb(205, 164, 97)'
                        // backgroundColor: 'rgba(0,0,0,0.1)'
                    }
                },
                legend: {
                    display:false
                },
                tooltips: {
                    enabled: false,
                    mode: 'index',
                    intersect: false,
                },
                hover: {
                    mode: 'nearest',
                    intersect: true
                }
            }
        };

        $('.text-filter a, .show-filter a').click(function(){
            $(this).closest('li').addClass('active').siblings().removeClass('active');
        });
        window.onload = function() {

            var ctx = document.getElementById("chart1").getContext("2d");
            window.myLine1 = new Chart(ctx, config1);

        };
        function clearData () {
            config1.data.datasets.splice(0, 1);
            config1.data.labels = [];
        }
        function updateData () {
            window.myLine1.update();
        }
        $('.showToday').click(function() {
            clearData ();
            // first chart
            var newDataset = {
                label: [1, 2, 3, 4, 5, 6, 7],
                data: [],
                fill: false
            };
            var _date = new Date ();
            config1.options.scales.xAxes[0].scaleLabel.labelString = _date.getDate() + '.'+(_date.getMonth()+1)+ '.'+_date.getFullYear()+' �.'
            for (var i = 0; i < DAY.length; i++) {
                config1.data.labels.push(DAY[i]);
            }
            // for (var index = 0; index < config1.data.labels.length; ++index) {
            //     newDataset.data.push(randomScalingFactor());
            // }

            config1.data.datasets.push(newDataset);
            // config1.data.datasets.forEach(function(dataset) {
            //     dataset.data.push(randomScalingFactor());
            // });
            updateData ();
            return false;
        });
        $('.showWeek').click(function() {
            clearData ();
            // first chart
            var newDataset = {
                label: [1, 2, 3, 4, 5, 6, 7],
                data: [],
                fill: false
            };
            config1.options.scales.xAxes[0].scaleLabel.labelString = '20 - 26 ����� 2017 �.';
            for (var i = 0; i < WEEK.length; i++) {
                config1.data.labels.push(WEEK[i]);
            }
            // for (var index = 0; index < config1.data.labels.length; ++index) {
            //     newDataset.data.push(randomScalingFactor());
            // }
            config1.data.datasets.push(newDataset);
            // config1.data.datasets.forEach(function(dataset) {
            //     dataset.data.push(randomScalingFactor());
            // });
            updateData ();
            return false;
        }); 
    }



    function initTabs(){
        $('.statistics ul.tab-control li a').on('click', function(){
            var thisHold = $(this).closest(".statistics");
            var _ind = $(this).closest('li').index();
            thisHold.children('.tab-body').children(".tab").removeClass('active');
            thisHold.children('.tab-body').children("div.tab:eq("+_ind+")").addClass('active');
            $(this).closest("ul").find(".active").removeClass("active");
            $(this).parent().addClass("active");
            return false;
        });
    };
        jQuery(document).ready(function () {
            $('.currency-check6').click(function(){
                $.ajax({
                    "url" : "/webmaster/site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=6"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check5').click(function(){
                $.ajax({
                    "url" : "/webmaster/site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=5"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check1').click(function(){
                $.ajax({
                    "url" : "/webmaster/site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=1"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check4').click(function(){
                $.ajax({
                    "url" : "/webmaster/site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=4"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check7').click(function(){
                $.ajax({
                    "url" : "/webmaster/site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=7"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });        jQuery(document).ready(function () {
            $('.currency-check2').click(function(){
                $.ajax({
                    "url" : "/webmaster/site/set-default-currency",
                    "method" : "GET",
                    "data" : "currency=2"
                });
                $('#balance').html('0');
                $('#hold').html('0');
                $('.icon-currency').html('<i class="fa fa-rouble"></i>');
            });
        });    jQuery(document).ready(function () {
        $('.lang-change').click(function(){
            t = $(this);
            $.ajax({
                "url" : "/webmaster/site/set-default-lang",
                "method" : "GET",
                "data" : {
                    lang: t.data("lang")
                },
                "success" : function(data) {
                  location.reload();
                }
            });
        });
    });</script>
<script type="text/javascript">jQuery(function ($) {
   $('.d-news-box:first').addClass('opened');
        $('.d-accordion__content:first').css('display','block');

});</script>
<script>
    $.widget.bridge('uibutton', $.ui.button);
    $.widget.bridge('uitooltip', $.ui.tooltip);
</script>

<!-- ajax check messages -->
<script>
    // check new ticket messages
    function ajaxMessages() {
        $.ajax({
            // actionAjax in TicketsController
            url: '/webmaster/tickets/ajax',
            success: function(data){
                // if admin answers & class "notice" exists add "new" class for animation and insert answers count
                // else create "notice" class element with "new" class and answers count
                if (data > 0 && $(".notice").length > 0) {
                    $(".notice").addClass('new').text(data);
                } else if (data > 0 && $("span").is('.notice') === false) {
                    $(".btn-notifications").append('<span class="notice new">' + data + '</span>');
                    $(".ticket-item").append('<span class="notice new">' + data + '</span>');
                    $(".support").append('<span class="notice new">' + data + '</span>');
                }
            }
        });
    }

    // delete class "new" for animate "notice" class again
    function animate() {
        $(".new").removeClass().addClass("notice");
    }

    setInterval(ajaxMessages, 30000); // 30 sec
    setInterval(animate, 35000); // 35 sec
</script>

</body>
    <script>
        $(document).ready(function () {
            $('#balance').html('0')

            $('#hold').html('0');
            $('.icon-currency').html('<i class="fa fa-rouble"></i>');
        });
    </script>

</html>

