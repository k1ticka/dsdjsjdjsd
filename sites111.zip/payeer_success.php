<?php
error_reporting(0);
// error_reporting(E_ALL);

ini_set('session.use_cookies', 'On');
ini_set('session.use_trans_sid', 'Off');
ini_set('session.gc_maxlifetime',7200);
ini_set('session.cookie_lifetime',7200);
session_set_cookie_params(7200, '/');

session_start();

include('conf.php');

$site=$_SERVER['HTTP_HOST'];

@mysql_query('set character_set_client="cp1251"');
@mysql_query('set character_set_results="cp1251"');
@mysql_query('set collation_connection="cp1251_general_ci"');

// $_REQUEST = unserialize( file_get_contents( 'qqqqqqqqq.txt' ) );
// echo "<pre>";
// print_r($_REQUEST);


/*
Array ( 
		[m_operation_id] => 40010149 
		[m_operation_ps] => 2609 
		[m_operation_date] => 16.01.2015 00:33:54 
		[m_operation_pay_date] => 16.01.2015 00:34:04 
		[m_shop] => 35995144 
		[m_orderid] => 1 
		[m_amount] => 0.01 
		[m_curr] => RUB 
		[m_desc] => VXNlciBOYW1lOiAxMjNfU1VNTTogMC4wMV9Qcm9jZW50OiAxMTAl 
		[m_status] => success 
		[m_sign] => DB446561CE4AEBC0FD3136C5107A69CA5FF68D3BAD84C277304FCB800078D746 
		[lang] => ru 
		[PHPSESSID] => 44c9e8ed5856bc5ab4f5ef7c82420685 )

*/
$m_sign = $_REQUEST['m_sign'];
$Row = mysql_query("SELECT `m_sign` FROM `operations` WHERE `m_sign` = '".$m_sign."'");
$Rows = mysql_fetch_assoc($Row);

if ($Rows['m_sign'] == $m_sign) {
	die('HACKING ATTEMPT!!!<br>Your IP was sent to the administrator for blocking!');
}
if ( $_REQUEST['m_shop'] == $apiId && $_REQUEST['m_status'] == 'success' )
	{
		$to_batch = $m_sign;
		$desc = base64_decode( $_REQUEST['m_desc'] );
		$desc = explode( '_', trim( $desc ) );
		
		$user_name = explode( ': ', trim( $desc[0] ) );
		$user_name = trim( $user_name[1] );
		
		$SUMM = $_REQUEST['m_amount'];
		
		// $SUMM = 103;
		
		$Procent = $procent_yandex;
		
		$proc = $SUMM * ( $Procent / 100 );
		
		$time = time();		
		$time_2 = $time + ( 3600 * $kolvo_chasov );
								## �������� ���� �� � ��� �������
				$sql_qw = "SELECT `ref` FROM `users` WHERE `login` = '" . $user_name . "'";
				$res_qw = mysql_query( $sql_qw );
				$res_qw = mysql_fetch_assoc( $res_qw );
				$res_qw = $res_qw['ref'];
				
				## ���� ���� ���, �������� ��� 5% �� ����� ������
				$send_proc = '0.00';
				if (	trim( $res_qw ) != '' )
					$send_proc = ( $SUMM / 100 ) * $d_ref;
				else
					$res_qw = '';
				
				
		mysql_query("INSERT INTO 
								`operations` (
												`ologin`,
												`otype`,
												`osum`,
												`osum2`,
												`odate`,
												`odate2`,
												`oplan`,
												`operiod`,
												`oparts`,
												`ohours`,
												`opproc`,
												`oproc`,
												`oprofit`,
												`oref`,												
												`orefrbp`,
												`orefbonus`,
												`orefsum`,
												`orefback`,
												`orefproc`,
												`obatch`,
												`oback`,
												`o_type`,
												`out_type`,
												`m_sign`
								) 
							VALUES (
												'" . $user_name . "',		
														'3',						
														'" . $proc . "',			
														'" . $SUMM . "', 			
														'" . $time_2 ."',			
														'" . $time ."',				
														'1',						
														'24',						
														'1',						
														'24',						
														'" . $Procent ."',			
														'" . $Procent ."',			
														'" . $proc . "',			
														'" . trim( $res_qw ) ."',							
														'0',						
														'0',						
														'" . $send_proc . "',						
														'0.00',						
														'10',						
														'" . $to_batch . "',		
														'',							
														'',							
														'payeer',
														'".$m_sign."'						
												
							)"
		) or die( mysql_error());
		mysql_query("UPDATE data SET `plus` = `plus`+".$SUMM);
?>
<script language="JavaScript">
	window.location.href = "<?php echo $domain_data['url'] ?>/success.html"
</script>
<?php
	}
else
	{
?>
<script language="JavaScript">
	alert( '������ �������� ������!, ��������� ������ ��� ��������� � ��������������' );
	window.location.href = "<?php echo $domain_data['url'] ?>/?p=hold"
</script>
<?php
	}

