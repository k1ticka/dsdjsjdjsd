<?php
header('Content-type: text/html; charset=windows-1251');
error_reporting(0);
session_start();
define('ADMIN', 'TRUE');

if($_SESSION['login'] != 'vipsergey1997' && $_SESSION['login'] != 'vipserezhka'){
	die('������� ��� ������� admin �� �����');
}


include('conf.php');

@mysql_query('set character_set_client="cp1251"');
@mysql_query('set character_set_results="cp1251"');
@mysql_query('set collation_connection="cp1251_general_ci"');

$time=time()+$time_move*3600;


$dataq=mysql_query("SELECT * FROM data");
$d=mysql_fetch_row($dataq);


$d_users=$d[0];
$d_activ=$d[1];
$d_vklad=$d[2];
$d_vyvod=$d[3];
$d_screens_mode=$d[4];
$d_screens_count=$d[5];
$d_reviews_mode=$d[6];
$d_reviews_count=$d[7];
$d_plus=$d[8];
$d_with=$d[9];
$d_reinvest=$d[10];
$d_plus_n=$d[11];
$d_with_n=$d[12];
$d_new_u1=$d[13];
$d_new_u2=$d[14];

$free=$d_plus-$d_with-($d_plus*($d_com/100));

if(isset($_GET['vklad']) && ($_GET['vklad']==0 || $_GET['vklad']==1)){ mysql_query("UPDATE data SET vklad='".$_GET['vklad']."'"); $d_vklad=$_GET['vklad']; }
if(isset($_GET['vyvod']) && ($_GET['vyvod']==0 || $_GET['vyvod']==1)){ mysql_query("UPDATE data SET vyvod='".$_GET['vyvod']."'"); $d_vyvod=$_GET['vyvod']; }

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" >
<head>
<meta http-equiv="content-type" content="text/html; charset=windows-1251" />
<link rel="stylesheet" href="css/admin.css" type="text/css" />
<script type="text/javascript" src="js.js"></script>
</head>
<body>


<table align="center" cellpadding="0px" cellspacing="0px" width="780px">
<tr>
<td class="admin_stat">
���������: <font color="#EC7600"><?php echo number_format($d_plus,2,'.',','); ?></font> ���. ������:
<font color="#EC7600"><?php echo number_format($d_with,2,'.',','); ?></font> ���. ������
<font color="#EC7600"><?php echo number_format($free,2,'.',','); ?></font> ���.
</td>
</tr>
<?php
$popq=mysql_query("SELECT oid,ologin,obatch,oplan FROM operations WHERE otype=3 AND obatch!='' AND osum2=0 ORDER BY odate2 ASC");
$popc=mysql_num_rows($popq);

$tovq=mysql_query("SELECT osum FROM operations WHERE oback=1");
$tovm=mysql_num_rows($tovq);

$tovaq=mysql_query("SELECT osum FROM operations WHERE otype=2 AND odate2=''");
$tovam=mysql_num_rows($tovaq);
?>

<tr>
<td class="admin_menu">
<a href="/admin.php?page=screens">������(<?php echo $d_screens_count; ?>)</a>
<a href="/admin.php?page=reviews">������(<?php echo $d_reviews_count; ?>)</a>
<a href="/admin.php?page=deposits">������ (<?php echo $popc; ?>)</a>
<a href="/admin.php?page=paidouts">������� (<?php echo ($tovm+$tovam); ?>)</a>
<a href="/admin.php?page=cancel">������</a>
<?php
if($d_vklad==0){ echo '<a href="/admin.php?vklad=1" style="color:#3EAA30;">�����</a>'; }
else{ echo '<a href="/admin.php?vklad=0" style="color:#f00000;">�����</a>'; }
if($d_vyvod==0){ echo '<a href="/admin.php?vyvod=1" style="color:#3EAA30;">�����</a>'; }
else{ echo '<a href="/admin.php?vyvod=0" style="color:#f00000;">�����</a>'; }
?>
<a href="/admin.php?page=restart" style="border:none;padding:0px;margin:0px;">�������</a>
<tr>
<td style="background:#ffffff">
<br>

<?php
if(!empty($_GET['page'])){
$req=$_GET['page'];
$req=str_replace('/?page=','',$req);
$inc=array('screens','reviews','deposits','paidouts','cancel','restart');
if(in_array($req,$inc)){ $nay=1; include ('admin/'.$req.'.php'); }
}
?>

<br>
<br>
</table>
